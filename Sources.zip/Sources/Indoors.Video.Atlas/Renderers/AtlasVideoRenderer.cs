﻿using System;
using System.Runtime.InteropServices;
using Indoors.Video.Atlas.Adapters;
using Indoors.Video.Atlas.Layers;
using Indoors.Video.Common.Renderers;
using Indoors.Video.Common.Settings;
using Microsoft.Extensions.Logging;
using Rafael.MAAM.Infra.Atlas.Imaging;
using Rafael.MAAM.Infra.Atlas.Presentation.Layering;
using IImage = Indoors.Video.Common.Types.IImage;

namespace Indoors.Video.Atlas.Renderers
{
    public class AtlasVideoRenderer : IImageRenderer
    {
        protected ILogger<AtlasVideoRenderer> Logger { get; }

        public IAtlasVideoLayerProvider LayerProvider { get; }
        public IVideoSettings VideoSettings { get; }
        public IAtlasPixelFormatParser PixelFormatParser { get; }

        public AtlasVideoRenderer(IAtlasVideoLayerProvider layerProvider,
            IVideoSettings videoSettings,
            IAtlasPixelFormatParser pixelFormatParser,
            ILogger<AtlasVideoRenderer> logger)
        {
            LayerProvider = layerProvider;
            VideoSettings = videoSettings;
            PixelFormatParser = pixelFormatParser;
            Logger = logger;

            Logger?.LogInformation($"[Ctor] {GetType().Name} created.");
        }

        public void RenderImage(IImage image)
        {
            if (image?.ImageBuffer == null)
                return;

            var videoLayer = LayerProvider.VideoLayer;

            if (videoLayer == null)
                return;

            var atlasPixelFormat = PixelFormatParser.GetPixelFormat(VideoSettings.PixelFormat);

            RenderImageBuffer(image.ImageBuffer, VideoSettings.FrameWidth, VideoSettings.FrameHeight, atlasPixelFormat,
                videoLayer);
        }

        /// <summary>
        /// Renders a decoded image buffer to the provided VideoLayer.
        /// </summary>
        /// <param name="buffer">The decoded image buffer.</param>
        /// <param name="videoWidth"></param>
        /// <param name="videoHeight"></param>
        /// <param name="atlasPixelFormat"></param>
        /// <param name="videoLayer">The Atlas video layer that will receive the image texture.</param>
        protected virtual void RenderImageBuffer(byte[] buffer, uint videoWidth, uint videoHeight,
            PixelFormat atlasPixelFormat, IVideoLayer videoLayer)
        {
            if (buffer == null)
                return;

            var imageGcHandle = default(GCHandle);

            try
            {
                imageGcHandle = GCHandle.Alloc(buffer, GCHandleType.Pinned);

                RenderImageHandle(buffer, videoWidth, videoHeight, atlasPixelFormat, videoLayer, imageGcHandle);
            }
            catch (Exception ex)
            {
                if (Logger != null)
                {
                    var logDetails = GetLogDetails(buffer, videoWidth, videoHeight, atlasPixelFormat, videoLayer);
                    var errorMessage =
                        $"[{nameof(RenderImageBuffer)}] Failed to create a GCHandle for an image buffer! {logDetails}";
                    Logger.LogWarning(ex, errorMessage);
                }
            }
            finally
            {
                if (imageGcHandle.IsAllocated)
                    imageGcHandle.Free();
            }
        }

        protected void RenderImageHandle(byte[] buffer, uint videoWidth, uint videoHeight, PixelFormat atlasPixelFormat,
            IVideoLayer videoLayer, GCHandle imageGcHandle)
        {
            ITextureBuffer textureBuffer = null;

            try
            {
                var imagePointer = imageGcHandle.AddrOfPinnedObject();

                // Create a texture for the atlas layer to render.
                textureBuffer =
                    TileTextureBuffer.Create((int) videoWidth, (int) videoHeight, atlasPixelFormat, imagePointer, false);

                // Set the texture to the video layer.
                var isUpdated = videoLayer.UpdateFrameData(textureBuffer);

                if (!isUpdated && Logger != null)
                {
                    var logDetails = GetLogDetails(buffer, videoWidth, videoHeight, atlasPixelFormat, videoLayer);
                    var errorMessage = $"[{nameof(RenderImageHandle)}] Failed to update a video frame texture! {logDetails}";
                    Logger.LogWarning(errorMessage);
                }
            }
            catch (Exception ex)
            {
                if (Logger != null)
                {
                    var logDetails = GetLogDetails(buffer, videoWidth, videoHeight, atlasPixelFormat, videoLayer);
                    var errorMessage =
                        $"[{nameof(RenderImageHandle)}] Failed to create a texture buffer, update or render a video frame! {logDetails}";
                    Logger.LogWarning(errorMessage, ex);
                }
            }
            finally
            {
                textureBuffer?.Dispose();
            }
        }

        protected string GetLogDetails(byte[] buffer, uint videoWidth, uint videoHeight,
            PixelFormat atlasPixelFormat, IVideoLayer videoLayer)
        {
            var logString = $"Layer: {videoLayer.Name}, ImageSize: [{videoWidth}, {videoHeight}], PixelFormat: {atlasPixelFormat}, BufferLength: {buffer.Length}";
            return logString;
        }
    }
}