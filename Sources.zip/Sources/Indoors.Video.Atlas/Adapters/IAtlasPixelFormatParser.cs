﻿using Rafael.MAAM.Infra.Atlas.Imaging;

namespace Indoors.Video.Atlas.Adapters
{
    public interface IAtlasPixelFormatParser
    {
        PixelFormat GetPixelFormat(string pixelFormatString);
    }
}