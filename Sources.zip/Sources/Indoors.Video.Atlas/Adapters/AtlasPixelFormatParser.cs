﻿using System;
using Microsoft.Extensions.Logging;
using Rafael.MAAM.Infra.Atlas.Imaging;

namespace Indoors.Video.Atlas.Adapters
{
    public class AtlasPixelFormatParser : IAtlasPixelFormatParser
    {
        private readonly ILogger<AtlasPixelFormatParser> m_logger;

        public AtlasPixelFormatParser(ILogger<AtlasPixelFormatParser> logger = null)
        {
            m_logger = logger;
            m_logger?.LogInformation($"[Ctor] {nameof(AtlasPixelFormatParser)} created.");
        }

        public PixelFormat GetPixelFormat(string pixelFormatString)
        {
            var atlasPixelFormat = PixelFormat.RGB24;

            try
            {
                var isParsed = Enum.TryParse(pixelFormatString, out atlasPixelFormat);

                if (!isParsed)
                {
                    if (m_logger != null)
                    {
                        var errorMessage = $"Failed to parse a pixel format string to an Atlas pixel format! PixelFormatString: {pixelFormatString}";
                        m_logger?.LogWarning(errorMessage);
                    }
                }
            }
            catch (Exception ex)
            {
                if (m_logger != null)
                {
                    var errorMessage = $"Failed to parse a pixel format string to an Atlas pixel format! PixelFormatString: {pixelFormatString}";
                    m_logger?.LogWarning(ex, errorMessage);
                }
            }

            return atlasPixelFormat;
        }
    }
}