﻿using Indoors.Video.Common.Metadata;
using Rafael.MAAM.Infra.Atlas.Presentation.Layering;

namespace Indoors.Video.Atlas.Layers
{
    public class AtlasVideoWithMetadataUpdateLayer<TMetadata> : VideoLayer<TMetadata>, IAtlasVideoLayer<TMetadata>
    {
        protected IMetadataUpdater<TMetadata> MetadataUpdater { get; }

        public AtlasVideoWithMetadataUpdateLayer(string name, VideoFrameDefinition videoFrameDefinition,
            IMetadataUpdater<TMetadata> metadataUpdater, bool isStereo = false)
            : base(name, videoFrameDefinition, isStereo)
        {
            MetadataUpdater = metadataUpdater;
        }

        protected override bool HandleFrameMetadata(ref TMetadata metadata)
        {
            var isHandled = base.HandleFrameMetadata(ref metadata);
            if (metadata != null)
                MetadataUpdater.UpdateMetadata(metadata);

            return isHandled;
        }
    }
}