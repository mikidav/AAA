﻿using Rafael.MAAM.Infra.Atlas.Presentation.Layering;

namespace Indoors.Video.Atlas.Layers
{
    public interface IAtlasVideoLayerProvider
    {
        IVideoLayer VideoLayer { get; }
    }

    public interface IAtlasVideoLayerProvider<TMetadata>
    {
        IVideoLayer<TMetadata> VideoLayer { get; }
    }
}