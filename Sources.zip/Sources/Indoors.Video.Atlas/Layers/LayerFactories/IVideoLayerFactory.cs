﻿using Rafael.MAAM.Infra.Atlas.Presentation.Layering;

namespace Indoors.Video.Atlas.Layers.LayerFactories
{
    public interface IVideoLayerFactory<out TLayer> where TLayer : IVideoLayer
    {
        TLayer Create(string layerName, VideoFrameDefinition videoFrameDefinition);
    }
}