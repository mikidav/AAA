﻿using Rafael.MAAM.Infra.Atlas.Presentation.Layering;

namespace Indoors.Video.Atlas.Layers.LayerFactories
{
    public interface IAtlasVideoLayerFactory : IVideoLayerFactory<IVideoLayer>
    {
    }

    public interface IAtlasVideoLayerFactory<TMetadata> : IVideoLayerFactory<IAtlasVideoLayer<TMetadata>>
    {
    }
}