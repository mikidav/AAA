﻿using Indoors.Video.Common.Metadata;
using Rafael.MAAM.Infra.Atlas.Presentation.Layering;

namespace Indoors.Video.Atlas.Layers.LayerFactories
{
    public class AtlasVideoWithMetadataUpdateLayerFactory<TMetadata> : IAtlasVideoLayerFactory<TMetadata>
    {
        public IMetadataUpdater<TMetadata> MetadataUpdater { get; }

        public AtlasVideoWithMetadataUpdateLayerFactory(IMetadataUpdater<TMetadata> metadataUpdater)
        {
            MetadataUpdater = metadataUpdater;
        }

        public IAtlasVideoLayer<TMetadata> Create(string layerName, VideoFrameDefinition videoFrameDefinition)
        {
            var videoLayer = new AtlasVideoWithMetadataUpdateLayer<TMetadata>(layerName, videoFrameDefinition, MetadataUpdater);
            return videoLayer;
        }
    }
}