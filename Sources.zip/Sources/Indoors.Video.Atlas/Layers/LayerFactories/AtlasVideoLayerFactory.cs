﻿using Rafael.MAAM.Infra.Atlas.Presentation.Layering;

namespace Indoors.Video.Atlas.Layers.LayerFactories
{
    public class AtlasVideoLayerFactory : IAtlasVideoLayerFactory
    {
        public IVideoLayer Create(string layerName, VideoFrameDefinition videoFrameDefinition)
        {
            var videoLayer = new VideoLayer(layerName, videoFrameDefinition);
            return videoLayer;
        }
    }

    public class AtlasVideoLayerFactory<TMetadata> : IAtlasVideoLayerFactory<TMetadata>
    {
        public IAtlasVideoLayer<TMetadata> Create(string layerName, VideoFrameDefinition videoFrameDefinition)
        {
            var videoLayer = new AtlasVideoLayer<TMetadata>(layerName, videoFrameDefinition);
            return videoLayer;
        }
    }
}