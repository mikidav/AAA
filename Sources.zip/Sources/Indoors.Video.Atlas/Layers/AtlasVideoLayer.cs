﻿using Rafael.MAAM.Infra.Atlas.Presentation.Layering;

namespace Indoors.Video.Atlas.Layers
{
    public class AtlasVideoLayer<TMetadata> : VideoLayer<TMetadata>, IAtlasVideoLayer<TMetadata>
    {
        public AtlasVideoLayer(string name, VideoFrameDefinition videoFrameDefinition, bool isStereo = false)
            : base(name, videoFrameDefinition, isStereo)
        {

        }
    }
}