﻿using Rafael.MAAM.Infra.Atlas.Presentation.Layering;

namespace Indoors.Video.Atlas.Layers
{
    public interface IAtlasVideoLayer<TMetadata> : IVideoLayer, IVideoLayer<TMetadata>
    {
        
    }
}