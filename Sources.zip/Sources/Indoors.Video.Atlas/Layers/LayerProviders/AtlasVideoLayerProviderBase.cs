﻿using System;
using Indoors.Video.Atlas.Adapters;
using Indoors.Video.Atlas.Layers.LayerFactories;
using Indoors.Video.Common.Settings;
using Microsoft.Extensions.Logging;
using Rafael.MAAM.Infra.Atlas.Presentation.Layering;

namespace Indoors.Video.Atlas.Layers.LayerProviders
{
    public abstract class AtlasVideoLayerProviderBase<TLayer> : IAtlasVideoLayerProvider where TLayer : IVideoLayer
    {
        protected ILogger<AtlasVideoLayerProviderBase<TLayer>> Logger { get; }

        public IVideoSettings VideoSettings { get; }
        public IAtlasPixelFormatParser PixelFormatParser { get; }
        public IVideoLayerFactory<TLayer> VideoLayerFactory { get; }
        public IVideoLayer VideoLayer { get; protected set; }

        protected abstract void CreateVideoLayer(string layerName, VideoFrameDefinition videoDefinitions);

        protected AtlasVideoLayerProviderBase(IVideoSettings videoSettings,
            IAtlasPixelFormatParser pixelFormatParser,
            IVideoLayerFactory<TLayer> videoLayerFactory,
            ILogger<AtlasVideoLayerProviderBase<TLayer>> logger = null)
        {
            Logger = logger;

            VideoSettings = videoSettings;
            PixelFormatParser = pixelFormatParser;
            VideoLayerFactory = videoLayerFactory;

            const string layerName = "VideoLayer";

            TryInitializeVideoLayer(videoSettings, layerName);

            Logger?.LogInformation($"[Ctor] {nameof(AtlasVideoLayerProviderBase<TLayer>)} created.");
        }

        private void TryInitializeVideoLayer(IVideoSettings videoSettings, string layerName)
        {
            try
            {
                InitializeVideoLayer(layerName);
            }
            catch (Exception ex)
            {
                if (Logger != null)
                {
                    var logDetails = GetLogDetails(videoSettings, layerName);
                    var errorMessage = $"[{nameof(InitializeVideoLayer)}] Failed to create an Atlas video layer! {logDetails}";
                    Logger.LogError(ex, errorMessage);
                }
            }
        }

        private void InitializeVideoLayer(string layerName)
        {
            var atlasPixelFormat = PixelFormatParser.GetPixelFormat(VideoSettings.PixelFormat);

            var videoDefinitions = new VideoFrameDefinition((int) VideoSettings.FrameWidth, (int) VideoSettings.FrameHeight,
                atlasPixelFormat, VideoSettings.IsFlippedInY);

            CreateVideoLayer(layerName, videoDefinitions);

            if (Logger != null)
            {
                var logDetails = GetLogDetails(VideoSettings, layerName);
                var logMessage = $"[{nameof(InitializeVideoLayer)}] Atlas video layer created. {logDetails}";
                Logger.LogInformation(logMessage);
            }
        }

        protected string GetLogDetails(IVideoSettings videoSettings, string layerName)
        {
            var logString = $"LayerName: {layerName}, ImageSize: [{videoSettings.FrameWidth}, {videoSettings.FrameHeight}], PixelFormat: {videoSettings.PixelFormat}, IsFLippedInY: {videoSettings.IsFlippedInY}";
            return logString;
        }
    }
}