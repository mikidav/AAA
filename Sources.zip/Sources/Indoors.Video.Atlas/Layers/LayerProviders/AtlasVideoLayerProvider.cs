using Indoors.Video.Atlas.Adapters;
using Indoors.Video.Atlas.Layers.LayerFactories;
using Indoors.Video.Common.Settings;
using Microsoft.Extensions.Logging;
using Rafael.MAAM.Infra.Atlas.Presentation.Layering;

namespace Indoors.Video.Atlas.Layers.LayerProviders
{
    public class AtlasVideoLayerProvider : AtlasVideoLayerProviderBase<IVideoLayer>
    {
        public AtlasVideoLayerProvider(IVideoSettings videoSettings,
            IAtlasPixelFormatParser pixelFormatParser,
            IVideoLayerFactory<IVideoLayer> videoLayerFactory,
            ILogger<AtlasVideoLayerProviderBase<IVideoLayer>> logger = null) 
            : base(videoSettings, pixelFormatParser, videoLayerFactory, logger)
        {
        }

        protected override void CreateVideoLayer(string layerName, VideoFrameDefinition videoDefinitions)
        {
            VideoLayer = VideoLayerFactory.Create(layerName, videoDefinitions);
        }
    }
}