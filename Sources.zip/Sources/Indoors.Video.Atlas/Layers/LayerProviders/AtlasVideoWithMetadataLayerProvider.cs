﻿using Indoors.Video.Atlas.Adapters;
using Indoors.Video.Atlas.Layers.LayerFactories;
using Indoors.Video.Common.Settings;
using Microsoft.Extensions.Logging;
using Rafael.MAAM.Infra.Atlas.Presentation.Layering;

namespace Indoors.Video.Atlas.Layers.LayerProviders
{
    public class AtlasVideoWithMetadataLayerProvider<TMetadata> :
        AtlasVideoLayerProviderBase<IAtlasVideoLayer<TMetadata>>, IAtlasVideoLayerProvider<TMetadata>
    {
        public new IVideoLayer<TMetadata> VideoLayer { get; protected set; }

        public AtlasVideoWithMetadataLayerProvider(IVideoSettings videoSettings,
            IAtlasPixelFormatParser pixelFormatParser,
            IAtlasVideoLayerFactory<TMetadata> videoLayerFactory,
            ILogger<AtlasVideoWithMetadataLayerProvider<TMetadata>> logger = null)
            : base(videoSettings, pixelFormatParser, videoLayerFactory, logger)
        {
        }

        protected override void CreateVideoLayer(string layerName, VideoFrameDefinition videoDefinitions)
        {
            var videoLayer = VideoLayerFactory.Create(layerName, videoDefinitions);
            base.VideoLayer = videoLayer;
            VideoLayer = videoLayer;
        }
    }
}