﻿namespace Indoors.Communications.RabbitMQ.Connection
{
    public interface IRabbitMqConnectionStateProvider
    {
        /// <summary>
        /// True if there is an open connection, false if it is not.
        /// </summary>
        bool IsConnected { get; }

        /// <summary>
        /// True if the connection is operative, false if it is not.
        /// </summary>
        bool IsOperative { get; }
    }
}