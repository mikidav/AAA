﻿using System;
using EasyNetQ;
using Indoors.Communications.RabbitMQ.Configuration;

namespace Indoors.Communications.RabbitMQ.Connection
{
    /// <summary>
    /// Implementors are used to create and use a connection with a RabbitMq broker.
    /// </summary>
    public interface IRabbitMqConnection : IRabbitMqConnectionStateProvider
    {
        /// <summary>
        /// Configuration of connection to RabbitMQ.
        /// </summary>
        IRabbitMqConfiguration RabbitMqConfiguration { get; }

        /// <summary>
        /// Provides a simple Publish/Subscribe and Request/Response API for a message bus.
        /// </summary>
        IBus Bus { get; }

        /// <summary>
        /// Event fires when reconnected after involuntary disconnection from RabbitMQ broker.
        /// Notify when reconnected after involuntary disconnection.
        /// </summary>
        event Action Reconnected;

        /// <summary>
        /// Event fires when the bus has involuntary disconnected from a RabbitMQ broker.
        /// </summary>
        event Action Disconnected;

        /// <summary>
        /// Event fires when a mandatory or immediate message is returned as un-routable.
        /// </summary>
        event Action MessageReturned;

        /// <summary>
        /// Event fires when the bus gets blocked due to the broker running low on resources.
        /// </summary>
        event Action Blocked;

        /// <summary>
        /// Event fires when the bus is unblocked.
        /// </summary>
        event Action Unblocked;
    }
}