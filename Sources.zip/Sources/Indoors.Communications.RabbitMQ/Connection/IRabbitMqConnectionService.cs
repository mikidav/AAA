﻿using Indoors.Services.Common;

namespace Indoors.Communications.RabbitMQ.Connection
{
    public interface IRabbitMqConnectionService : IRabbitMqConnection, IService
    {

    }
}