﻿using EasyNetQ.Logging;

namespace Indoors.Communications.RabbitMQ.Logger
{
    public interface IEasyNetQLogger : ILog
    {
    }
}