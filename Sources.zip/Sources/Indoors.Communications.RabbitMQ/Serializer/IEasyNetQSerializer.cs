using EasyNetQ;

namespace Indoors.Communications.RabbitMQ.Serializer
{
    public interface IEasyNetQSerializer : ISerializer
    {
    }
}