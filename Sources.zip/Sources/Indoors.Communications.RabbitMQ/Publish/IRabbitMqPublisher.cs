﻿using Indoors.Communications.Common.Publishers;

namespace Indoors.Communications.RabbitMQ.Publish
{
    public interface IRabbitMqPublisher : IPublisher
    {
    }
}