﻿using System;
using Indoors.Communications.Common.Correlation;
using Indoors.Communications.Common.Publishers;
using Indoors.Communications.RabbitMQ.Configuration;
using Indoors.Communications.RabbitMQ.Connection;
using Microsoft.Extensions.Logging;

namespace Indoors.Communications.RabbitMQ.Publish
{
    /// <summary>
    /// Publisher of <see cref="TMessage" /> messages.
    /// Used to publish synchronously or asynchronously.
    /// </summary>
    /// <typeparam name="TMessage">Published messages type.</typeparam>
    /// <see cref="ITypedObjectPublisher{TData}" />
    /// <seealso cref="BasePublisher" />
    public class TypedPublisher<TMessage> : BasePublisher, ITypedObjectPublisher<TMessage> where TMessage : class
    {
        private ICorrelationIdGenerator m_correlationIdGenerator;

        private IPublisherConfiguration m_configuration;

        /// <summary>
        /// Creates a new instance of <see cref="TypedPublisher{TMessage}" /> for messages of type <see cref="TMessage" />
        /// </summary>
        /// <param name="connection">A connection to the RabbitMQ system.</param>
        /// <param name="configuration">Type specific configurations of the publisher</param>
        /// <param name="correlationIdGenerator">Operation correlation id generator</param>
        /// <param name="logger">Service logger.</param>
        /// <param name="id">The id of the publisher service.</param>
        public TypedPublisher(
            IRabbitMqConnection connection,
            IPublisherConfiguration<TMessage> configuration,
            ICorrelationIdGenerator correlationIdGenerator = null,
            ILogger<TypedPublisher<TMessage>> logger = null,
            string id = null) : this(connection, (IPublisherConfiguration)configuration, correlationIdGenerator, logger, id)
        {
        }

        /// <summary>
        /// Creates a new instance of <see cref="TypedPublisher{TMessage}" /> for messages of type <see cref="TMessage" />
        /// </summary>
        /// <param name="connection">A connection to the RabbitMQ system.</param>
        /// <param name="configuration">Configurations of the publisher</param>
        /// <param name="correlationIdGenerator">Operation correlation id generator</param>
        /// <param name="logger">Service logger.</param>
        /// <param name="id">The id of the publisher service.</param>
        public TypedPublisher(
            IRabbitMqConnection connection,
            IPublisherConfiguration configuration,
            ICorrelationIdGenerator correlationIdGenerator = null,
            ILogger<TypedPublisher<TMessage>> logger = null,
            string id = null) : base(connection, logger, id)
        {
            m_correlationIdGenerator = correlationIdGenerator;
            m_configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        /// <summary>
        /// Publishes a message of type <see cref="TMessage" /> according to the settings specified in <see cref="m_configuration" />.
        /// <para>See 'Remarks' for exception and events information.</para>
        /// </summary>
        /// <remarks>
        /// Exceptions are logged and swallowed. To handle exceptions, register to <see cref="IPublisher.PublishFailed" /> event.
        /// <br />
        /// For notifications about completed message publishing, register to <see cref="IPublisher.PublishCompleted" /> event.
        /// </remarks>
        /// <param name="data">The message to publish.</param>
        public string Publish(in TMessage data)
        {
            var operationId = m_correlationIdGenerator?.Generate()
                              ?? Guid.NewGuid().ToString();

            Publish(operationId, data);

            return operationId;
        }

        /// <summary>
        /// Publishes a message of type <see cref="TMessage" /> according to the settings specified in <see cref="m_configuration" />.
        /// <para>See 'Remarks' for exception and events information.</para>
        /// </summary>
        /// <remarks>
        /// Exceptions are logged and swallowed. To handle exceptions, register to <see cref="IPublisher.PublishFailed" /> event.
        /// <br />
        /// For notifications about completed message publishing, register to <see cref="IPublisher.PublishCompleted" /> event.
        /// </remarks>
        /// <param name="publishId"></param>
        /// <param name="data">The message to publish.</param>
        public void Publish(string publishId, in TMessage data)
        {
            var message = data;
            var publishTask = Publish(m_configuration, publishId, message);
            if (!(publishTask.IsCompleted || publishTask.IsCanceled || publishTask.IsFaulted))
                publishTask.GetAwaiter().GetResult();
        }

        protected override void InternalInitialize()
        {
            // no internal logic
        }

        protected override void InternalStart()
        {
            // no internal logic
        }

        protected override void InternalStop()
        {
            // no internal logic
        }

        protected override void InnerNullifyReferencesDispose()
        {
            m_configuration = null;
            m_correlationIdGenerator = null;

            base.InnerNullifyReferencesDispose();
        }
    }
}