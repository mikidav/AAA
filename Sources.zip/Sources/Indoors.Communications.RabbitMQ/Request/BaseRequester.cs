﻿using System;
using System.Reactive.Subjects;
using System.Threading;
using System.Threading.Tasks;
using EasyNetQ;
using Indoors.Communications.Common.Requesters;
using Indoors.Communications.Common.Types;
using Indoors.Communications.RabbitMQ.Configuration;
using Indoors.Communications.RabbitMQ.Connection;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Communications.RabbitMQ.Request
{
    /// <summary>
    /// Base class for easy working with <see cref="IRequester"/>,
    /// using <see cref="IRabbitMqConnection"/> interface.
    /// </summary>
    /// <seealso cref="IRequester"/>
    public abstract class BaseRequester : ServiceBase, IRabbitMqRequester
    {
        private readonly ISubject<OperationCompletedData> m_requestCompleted;
        private readonly ISubject<OperationFailedData> m_requestFailed;

        protected BaseRequester(IRabbitMqConnection connection, ILogger logger = null, string id = null) : base(logger, id)
        {
            Connection = connection ?? throw new ArgumentNullException(nameof(connection));

            m_requestCompleted = new Subject<OperationCompletedData>();
            m_requestFailed = new Subject<OperationFailedData>();
        }
        protected IRabbitMqConnection Connection { get; private set; }

        public IObservable<OperationCompletedData> RequestCompleted => m_requestCompleted;

        public IObservable<OperationFailedData> RequestFailed => m_requestFailed;

        protected TRespond SyncRequest<TRequest, TRespond>(string operationId,
            TRequest requestData,
            IRequesterConfiguration configuration = null)
            where TRequest : class
            where TRespond : class
        {
            ThrowIfCanNotRequest<TRequest, TRespond>(operationId, requestData);

            TRespond replyData;

            try
            {
                replyData = Connection.Bus.Rpc.Request<TRequest, TRespond>(requestData,
                                rabbitMqRequestConfiguration => ConfigureRequesting(rabbitMqRequestConfiguration, configuration));
            }
            catch (Exception ex)
            {
                var msg =
                    $"Failed to sync publish a message! OperationId: {operationId}, RequestType: {typeof(TRequest).Name}, ReplyType: {typeof(TRespond).Name}, RequestData: {requestData}, Configuration: {configuration?.ToString() ?? "Null"}, {ServiceDescriptionString}";

                Logger.LogError(ex, msg);

                m_requestFailed.OnNext(new OperationFailedData(operationId, ex));

                throw new Exception(msg, ex);
            }

            return replyData;
        }

        protected async Task<TRespond> AsyncRequest<TRequest, TRespond>(string operationId,
            TRequest requestData,
            IRequesterConfiguration configuration = null,
            CancellationToken cancellationToken = default)
            where TRequest : class
            where TRespond : class
        {
            ThrowIfCanNotRequest<TRequest, TRespond>(operationId, requestData);

            TRespond replyData;

            try
            {
                replyData = await Connection.Bus.Rpc.RequestAsync<TRequest, TRespond>(requestData,
                    rabbitMqRequestConfiguration => ConfigureRequesting(rabbitMqRequestConfiguration, configuration),
                    cancellationToken);
            }
            catch (Exception ex)
            {
                var msg =
                    $"Failed to sync publish a message! OperationId: {operationId}, RequestType: {typeof(TRequest).Name}, ReplyType: {typeof(TRespond).Name}, RequestData: {requestData}, Configuration: {configuration?.ToString() ?? "Null"}, {ServiceDescriptionString}";

                Logger.LogError(ex, msg);

                m_requestFailed.OnNext(new OperationFailedData(operationId, ex));

                throw new Exception(msg, ex);
            }

            return replyData;
        }

        private static void ConfigureRequesting(EasyNetQ.IRequestConfiguration rabbitMqRequestConfiguration, IRequesterConfiguration requesterConfiguration)
        {
            if (!string.IsNullOrWhiteSpace(requesterConfiguration.WithQueueName))
                rabbitMqRequestConfiguration.WithQueueName(requesterConfiguration.WithQueueName);
            if (requesterConfiguration.WithExpiresMilliseconds.HasValue)
                rabbitMqRequestConfiguration.WithExpiration(TimeSpan.FromMilliseconds(requesterConfiguration.WithExpiresMilliseconds.Value));
            if (requesterConfiguration.WithPriority.HasValue)
                rabbitMqRequestConfiguration.WithPriority(requesterConfiguration.WithPriority.Value);
        }

        /// <summary>
        /// Checks if all conditions exist for requesting a reply using the given requester.
        /// </summary>
        /// <typeparam name="TRequest">Checked message type.</typeparam>
        /// <typeparam name="TRespond">Checked reply message type</typeparam>
        /// <param name="operationId">Request operation ID.</param>
        /// <param name="requestData">Checked message.</param>
        /// <returns>True if the checked message can be requested using the given requester, False otherwise.</returns>
        protected virtual bool CanRequest<TRequest, TRespond>(string operationId,
            TRequest requestData)
            where TRequest : class
            where TRespond : class
        {
            var canRequest = true;

            if (!IsRunning)
            {
                canRequest = false;
                Logger.LogWarning($"CanRequest check failed - Service is not running. OperationId: {operationId}, RequestType: {typeof(TRequest).Name}, ReplyType: {typeof(TRespond).Name}, RequestData: {requestData}, {ServiceDescriptionString}");
            }

            if (string.IsNullOrWhiteSpace(operationId))
            {
                var error = $"CanRequest check failed - Operation ID is null. RequestType: {typeof(TRequest).Name}, ReplyType: {typeof(TRespond).Name}, {ServiceDescriptionString}";
                Logger.LogWarning(error);
            }

            if (requestData == null)
            {
                canRequest = false;
                Logger.LogWarning($"CanRequest check failed - Request data is null. OperationId: {operationId}, RequestType: {typeof(TRequest).Name}, ReplyType: {typeof(TRespond).Name}, {ServiceDescriptionString}");
            }

            if (!Connection.IsOperative)
            {
                canRequest = false;
                Logger.LogWarning($"CanRequest check failed - Not operative. OperationId: {operationId}, MessageType: {typeof(TRequest).Name}, RequestData: {requestData?.ToString() ?? string.Empty}, {ServiceDescriptionString}");
            }

            return canRequest;
        }

        /// <summary>
        /// Throws an exception if not all conditions exist for requesting a reply using the given requester.
        /// </summary>
        /// <typeparam name="TRequest">Checked request message type.</typeparam>
        /// <typeparam name="TRespond">Checked reply message type</typeparam>
        /// <param name="operationId">Request operation ID.</param>
        /// <param name="requestData">Checked message.</param>
        /// <exception cref="ArgumentNullException">When <see cref="requestData" /> is null.</exception>
        /// <exception cref="Exception">When not connected.</exception>
        protected virtual void ThrowIfCanNotRequest<TRequest, TRespond>(string operationId,
            TRequest requestData)
            where TRequest : class
            where TRespond : class
        {
            ValidateIsRunning($"CanRequest check failed - Service is not running. OperationId: {operationId}, MessageType: {typeof(TRequest).Name}, RequestData: {requestData.ToString() ?? string.Empty}, {ServiceDescriptionString}");

            if (string.IsNullOrWhiteSpace(operationId))
            {
                var error = $"CanRequest check failed - Operation ID is null. RequestType: {typeof(TRequest).Name}, ReplyType: {typeof(TRespond).Name}, {ServiceDescriptionString}";

                Logger.LogWarning(error);
                throw new ArgumentNullException(nameof(operationId), error);
            }

            if (requestData == null)
            {
                var error = $"CanRequest check failed - Request data is null. OperationId: {operationId}, RequestType: {typeof(TRequest).Name}, ReplyType: {typeof(TRespond).Name}, {ServiceDescriptionString}";

                Logger.LogWarning(error);
                throw new ArgumentNullException(nameof(requestData), error);
            }

            if (!Connection.IsOperative)
            {
                var error = $"CanRequest check failed - Not operative. OperationId: {operationId}, RequestType: {typeof(TRequest).Name}, ReplyType: {typeof(TRespond).Name}, RequestData: {requestData}, {ServiceDescriptionString}";

                Logger.LogWarning(error);
                throw new Exception(error);
            }
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Connection = null;
        }
    }
}
