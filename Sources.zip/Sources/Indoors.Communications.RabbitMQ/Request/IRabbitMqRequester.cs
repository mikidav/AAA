﻿using Indoors.Communications.Common.Requesters;

namespace Indoors.Communications.RabbitMQ.Request
{
    public interface IRabbitMqRequester : IRequester
    {

    }
}