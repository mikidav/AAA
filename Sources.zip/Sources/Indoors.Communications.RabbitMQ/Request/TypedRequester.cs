﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Indoors.Communications.Common.Correlation;
using Indoors.Communications.Common.Requesters;
using Indoors.Communications.RabbitMQ.Configuration;
using Indoors.Communications.RabbitMQ.Connection;
using Microsoft.Extensions.Logging;

namespace Indoors.Communications.RabbitMQ.Request
{
    /// <summary>
    /// Synchronous or asynchronous requester of <see cref="TRequest"/> type message,
    /// and get responds of <see cref="TRespond"/> type message.
    /// </summary>
    /// <typeparam name="TRequest">Requesting message type</typeparam>
    /// <typeparam name="TRespond">Responding message type</typeparam>
    /// <see cref="ITypedObjectRequester{TRequestData,TReplyData}"/>
    /// <seealso cref="BaseRequester"/>
    public class TypedRequester<TRequest, TRespond> : BaseRequester, ITypedObjectRequester<TRequest, TRespond>
        where TRequest : class
        where TRespond : class
    {
        private ICorrelationIdGenerator m_correlationIdGenerator;

        private IRequesterConfiguration m_configuration;

        /// <summary>
        /// Creates a new instance of <see cref="TypedRequester{TRequestData,TReplyData}" /> for requests of type <see cref="TRequest"/> and replies of <see cref="TRespond"/>./>
        /// </summary>
        /// <param name="connection">A connection to the RabbitMQ system.</param>
        /// <param name="configuration">Type specific configurations of the requester</param>
        /// <param name="correlationIdGenerator">Operation correlation id generator</param>
        /// <param name="logger">Service logger.</param>
        /// <param name="id">The id of the publisher service.</param>
        public TypedRequester(
            IRabbitMqConnection connection,
            IRequesterConfiguration<TRequest, TRespond> configuration,
            ICorrelationIdGenerator correlationIdGenerator = null,
            ILogger<TypedRequester<TRequest, TRespond>> logger = null,
            string id = null) : this(connection, (IRequesterConfiguration)configuration, correlationIdGenerator, logger, id)
        {

        }

        /// <summary>
        /// Creates a new instance of <see cref="TypedRequester{TRequestData,TReplyData}" /> for requests of type <see cref="TRequest"/> and replies of <see cref="TRespond"/>./>
        /// </summary>
        /// <param name="connection">A connection to the RabbitMQ system.</param>
        /// <param name="configuration">Configurations of the requester</param>
        /// <param name="correlationIdGenerator">Operation correlation id generator</param>
        /// <param name="logger">Service logger.</param>
        /// <param name="id">The id of the publisher service.</param>
        public TypedRequester(
            IRabbitMqConnection connection,
            IRequesterConfiguration configuration,
            ICorrelationIdGenerator correlationIdGenerator = null,
            ILogger<TypedRequester<TRequest, TRespond>> logger = null,
            string id = null) : base(connection, logger, id)
        {
            m_correlationIdGenerator = correlationIdGenerator;
            m_configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }


        public (string requestId, TRespond reply) Request(TRequest requestData)
        {
            var requestId = m_correlationIdGenerator?.Generate()
                              ?? Guid.NewGuid().ToString();

            var result = Request(requestId, requestData);

            return (requestId, result);
        }

        public TRespond Request(string requestId, TRequest requestData)
        {
            var respond = SyncRequest<TRequest, TRespond>(requestId, requestData, m_configuration);
            return respond;
        }

        public async Task<(string requestId, TRespond reply)> RequestAsync(TRequest requestData, CancellationToken cancellationToken = default)
        {
            var requestId = m_correlationIdGenerator?.Generate()
                              ?? Guid.NewGuid().ToString();

            var result = await RequestAsync(requestId, requestData, cancellationToken);

            return (requestId, result);
        }

        public Task<TRespond> RequestAsync(string requestId, TRequest requestData, CancellationToken cancellationToken = default)
        {
            return AsyncRequest<TRequest, TRespond>(requestId, requestData, m_configuration, cancellationToken);
        }
        
        protected override void InternalInitialize()
        {
            // no internal logic
        }

        protected override void InternalStart()
        {
            // no internal logic
        }

        protected override void InternalStop()
        {
            // no internal logic
        }

        protected override void InnerNullifyReferencesDispose()
        {
            m_configuration = null;
            m_correlationIdGenerator = null;

            base.InnerNullifyReferencesDispose();
        }
    }
}