﻿using System;
using System.Reactive.Subjects;
using System.Threading.Tasks;
using EasyNetQ;
using Indoors.Communications.Common.Subscribers;
using Indoors.Communications.RabbitMQ.Configuration;
using Indoors.Communications.RabbitMQ.Connection;
using Microsoft.Extensions.Logging;

namespace Indoors.Communications.RabbitMQ.Subscribe
{
    /// <summary>
    /// Subscribes to <see cref="TMessage" /> type messages with synchronous or asynchronous handlers.
    /// </summary>
    /// <typeparam name="TMessage">Message type to subscribe to.</typeparam>
    public class TypedSubscriber<TMessage> : BaseSubscriber, ITypedObjectSubscriber<TMessage> where TMessage : class
    {
        private readonly ISubject<TMessage> m_messageSubscribedSubject = new Subject<TMessage>();

        private readonly ISubscriberConfiguration m_configuration;

        private ISubscriptionResult m_subscriptionResult;

        /// <summary>
        /// Creates new instances of <see cref="TypedSubscriber{TMessage}" />
        /// </summary>
        /// <param name="connection">Connection to RabbitMQ.</param>
        /// <param name="configuration">Type specific configuration of the subscriber.</param>
        /// <param name="logger">An optional logger</param>
        /// <param name="id">
        /// An optional service id for the subscriber, as used in queue names, logging and more.
        /// Default created when null.
        /// </param>
        public TypedSubscriber(
            IRabbitMqConnection connection,
            ISubscriberConfiguration<TMessage> configuration,
            ILogger logger = null,
            string id = null)
            : this(connection, (ISubscriberConfiguration) configuration,  logger, id)
        {
        }

        /// <summary>
        /// Creates new instances of <see cref="TypedSubscriber{TMessage}" />
        /// </summary>
        /// <param name="connection">Connection to RabbitMQ.</param>
        /// <param name="configuration">Configuration of the subscriber.</param>
        /// <param name="logger">An optional logger</param>
        /// <param name="id">
        /// An optional service id for the subscriber, as used in queue names, logging and more.
        /// Default created when null.
        /// </param>
        public TypedSubscriber(
            IRabbitMqConnection connection,
            ISubscriberConfiguration configuration,
            ILogger logger = null,
            string id = null)
            : base(connection, logger, id)
        {
            m_configuration = configuration;
            m_subscriptionResult = null;
        }

        public bool IsSubscribed => IsRunning && m_subscriptionResult != null;

        public IObservable<TMessage> DataReceived => m_messageSubscribedSubject;

        protected override void InternalInitialize()
        {
            // No internal logic
        }

        protected override void InternalStart()
        {
            if (m_configuration == null)
            {
                var error = $"Null configuration. MessageType: {typeof(TMessage).Name}, {ServiceDescriptionString}";
                Logger.LogWarning(error);
                throw new Exception(error);
            }

            m_subscriptionResult = SyncSubscribe<TMessage>(MessageHandler, m_configuration);
        }

        protected override void InternalStop()
        {
            Unsubscribe(m_subscriptionResult);
            m_subscriptionResult = null;
        }

        private void MessageHandler(TMessage message)
        {
            if (m_configuration.AsAsync.HasValue && m_configuration.AsAsync.Value)
                AsyncMessageHandler(message);
            else
                SyncMessageHandler(message);
        }


        private void AsyncMessageHandler(TMessage message)
        {
            var task = Task.Run(() => SyncMessageHandler(message));

            task.ContinueWith(handlerTask => HandleMessageHandlerException(handlerTask.Exception),
                TaskContinuationOptions.OnlyOnFaulted);
        }

        private void SyncMessageHandler(TMessage message)
        {
            try
            {
                m_messageSubscribedSubject.OnNext(message);
            }
            catch (Exception ex)
            {
                HandleMessageHandlerException(ex);
            }
        }

        /// <summary>
        /// Handles exceptions that are raised from message handlers by logging them and rethrowing as EasyNetQ exceptions.
        /// The EasyNetQ infrastructure treats <see cref="EasyNetQException" /> exceptions by placing the handled message in the
        /// error queue.
        /// </summary>
        /// <param name="ex">The exception raised from the message handler.</param>
        private void HandleMessageHandlerException(Exception ex)
        {
            var error =
                $"Error while handling a received message! Message should appear in the error queue. Message: {typeof(TMessage)}, {ServiceDescriptionString}";

            Logger.LogDebug(ex, error);
            throw new EasyNetQException(error, ex);
        }
    }
}