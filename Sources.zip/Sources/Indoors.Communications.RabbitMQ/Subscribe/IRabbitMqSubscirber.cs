﻿using Indoors.Communications.Common.Subscribers;

namespace Indoors.Communications.RabbitMQ.Subscribe
{
    public interface IRabbitMqSubscriber : ISubscriber
    {

    }
}