﻿namespace Indoors.Communications.RabbitMQ.Configuration
{
    public interface IPublisherConfiguration<TMessage> : IPublisherConfiguration 
        where TMessage : class
    {

    }

    public interface IPublisherConfiguration
    {
        /// <summary>
        /// True for asynchronous publishing, and false for synchronous.
        /// </summary>
        bool? AsAsync { get; }

        /// <summary>
        /// The topic of the publishing.
        /// Set null or <see cref="string.Empty"/> or null value for default topic.
        /// </summary>
        string WithTopic { get; }

        /// <summary>
        /// How long in milliseconds a published message should remain unsubscribed in the queue before it is automatically deleted.<br/>
        /// This also known as message TTL (Time to live).<br/>
        /// Set null for default value.
        /// </summary>
        int? WithExpiresMilliseconds { get; }

        /// <summary>
        /// Determine the published message priority.<br/>
        /// Set null for default value.
        /// </summary>
        byte? WithPriority { get; }
    }
}