﻿namespace Indoors.Communications.RabbitMQ.Configuration
{
    public interface IReplierConfiguration<TRequest, TRespond> : IReplierConfiguration
        where TRequest : class
        where TRespond : class
    {
    }

    public interface IReplierConfiguration
    {
        /// <summary>
        /// True for asynchronous subscription, and false or null for synchronous.
        /// </summary>
        bool? AsAsync { get; }

        /// <summary>
        /// The queue name.
        /// Set <see cref="string.Empty"/> or null value for default queue name.
        /// </summary>
        string WithQueueName { get; }

        /// <summary>
        /// True for queue that can survive a server restart,<br/>
        /// and false for queue that will be deleted when the server restarts.<br/>
        /// Set null for default value.
        /// </summary>
        bool? WithDurable { get; }

        /// <summary>
        /// <para>
        /// The number of messages to prefetch when consuming messages form the broker.
        /// Bottom-line, the property set limit of the number of unacknowledged message on a channel (or connection) when consuming.
        /// </para>
        /// <para>
        /// Finding a suitable prefetch value is a matter of trial and error and will vary from workload to workload.
        /// Values in the 100 through 300 range usually offer optimal throughput and do not run significant risk of overwhelming consumers.
        /// Prefetch value of 1 is the most conservative. It will significantly reduce throughput,in particular environments where consumer connection latency is high.
        /// For Many applications, a higher value would be appropriate and optimal.
        /// Set to zero for unlimited prefetch (NOT RECOMMENDED) or null for default value.
        /// </para>
        /// <para>
        /// Because messages are sent (pushed) to clients asynchronously, there is more then one message "in flight" on a channel at any given moment.
        /// In addition, manual acknowledgments from clients are also inherently asynchronous in nature. So there's a sliding windows of delivery tags that are unacknowledged.
        /// Developers would often prefer to cap the size of this window to avoid the unbounded buffer problem on the consumer end.
        /// </para>
        /// </summary>
        ushort? WithPrefetchCount { get; }

        /// <summary>
        /// <para>
        /// Expiry time can be set for a given queue by setting the x-expires argument to queue.declare, or by setting the expires policy.
        /// This controls for how long a queue can be unused before it is automatically deleted.
        /// Unused means the queue has no consumers, the queue has not been re-declared, and basic.get has not been invoked for a duration of at least the expiration period.
        /// This can be used, for example, for RPC-style reply queues, where many queues can be created which may never be drained.
        /// The server guarantees that the queue will be deleted, if unused for at least the expiration period.
        /// No guarantee is given as to how promptly the queue will be removed after the expiration period has elapsed.
        /// Leases of durable queues restart when the server restarts.
        /// </para>
        /// Set null for default value.
        /// </summary>
        int? WithExpiresMilliseconds { get; }

        /// <summary>
        /// Determines the maximum message priority that the queue should support.<br/>
        /// Set null for default value.
        /// </summary>
        byte? WithMaxPriority { get; }
    }
}