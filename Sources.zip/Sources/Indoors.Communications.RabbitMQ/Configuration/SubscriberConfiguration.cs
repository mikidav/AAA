﻿using System;

namespace Indoors.Communications.RabbitMQ.Configuration
{
    public class SubscriberConfiguration : ISubscriberConfiguration
    {
        /// <inheritdoc cref="ISubscriberConfiguration.AsAsync"/>
        public bool? AsAsync { get; set; }

        /// <inheritdoc cref="ISubscriberConfiguration.WithTopic"/>
        public string WithTopic { get; set; }

        /// <inheritdoc cref="ISubscriberConfiguration.WithQueueName"/>
        public string WithQueueName { get; set; }

        /// <inheritdoc cref="ISubscriberConfiguration.WithAutoDelete"/>
        public bool? WithAutoDelete { get; set; }

        /// <inheritdoc cref="ISubscriberConfiguration.WithDurable"/>
        public bool? WithDurable { get; set; }

        /// <inheritdoc cref="ISubscriberConfiguration.WithPrefetchCount"/>
        public ushort? WithPrefetchCount { get; set; }

        /// <inheritdoc cref="ISubscriberConfiguration.WithPriority"/>
        public int? WithPriority { get; set; }

        /// <inheritdoc cref="ISubscriberConfiguration.WithExpiresMilliseconds"/>
        public int? WithExpiresMilliseconds { get; set; }

        /// <inheritdoc cref="ISubscriberConfiguration.AsExclusive"/>
        public bool? AsExclusive { get; set; }

        /// <inheritdoc cref="ISubscriberConfiguration.WithMaxPriority"/>
        public byte? WithMaxPriority { get; set; }

        /// <inheritdoc cref="ISubscriberConfiguration.WithMaxLength"/>
        public int? WithMaxLength { get; set; }

        /// <inheritdoc cref="ISubscriberConfiguration.WithMaxLengthBytes"/>
        public int? WithMaxLengthBytes { get; set; }

        /// <inheritdoc cref="ISubscriberConfiguration.AsLazyQueueMode"/>
        public bool? AsLazyQueueMode { get; set; }


        public override string ToString()
        {
            return $"{nameof(AsAsync)}: {AsAsync}, {nameof(WithTopic)}: {WithTopic}, {nameof(WithAutoDelete)}: {WithAutoDelete}, {nameof(WithDurable)}: {WithDurable}, {nameof(WithPrefetchCount)}: {WithPrefetchCount}, {nameof(WithPriority)}: {WithPriority}, {nameof(WithExpiresMilliseconds)}: {WithExpiresMilliseconds}, {nameof(AsExclusive)}: {AsExclusive}, {nameof(WithMaxPriority)}: {WithMaxPriority}, {nameof(WithMaxLength)}: {WithMaxLength}, {nameof(WithMaxLengthBytes)}: {WithMaxLengthBytes}, {nameof(AsLazyQueueMode)}: {AsLazyQueueMode}";
        }
    }

    public class SubscriberConfiguration<TMessage> : SubscriberConfiguration, ISubscriberConfiguration<TMessage>
        where TMessage : class
    {
    }

    public class SubscriberConfigurationTypedWrapper<TMessage> : ISubscriberConfiguration<TMessage>
        where TMessage : class
    {
        public ISubscriberConfiguration Configuration { get; }

        public SubscriberConfigurationTypedWrapper(ISubscriberConfiguration configuration)
        {
            Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public bool? AsAsync => Configuration.AsAsync;

        public string WithTopic => Configuration.WithTopic;

        public string WithQueueName => Configuration.WithQueueName;

        public bool? WithAutoDelete => Configuration.WithAutoDelete;

        public bool? WithDurable => Configuration.WithDurable;

        public ushort? WithPrefetchCount => Configuration.WithPrefetchCount;

        public int? WithPriority => Configuration.WithPriority;

        public int? WithExpiresMilliseconds => Configuration.WithExpiresMilliseconds;

        public bool? AsExclusive => Configuration.AsExclusive;

        public byte? WithMaxPriority => Configuration.WithMaxPriority;

        public int? WithMaxLength => Configuration.WithMaxLength;

        public int? WithMaxLengthBytes => Configuration.WithMaxLengthBytes;

        public bool? AsLazyQueueMode => Configuration.AsLazyQueueMode;

        public override string ToString()
        {
            return Configuration.ToString();
        }
    }
}
