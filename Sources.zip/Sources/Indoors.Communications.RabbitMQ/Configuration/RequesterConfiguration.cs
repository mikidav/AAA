﻿using System;

namespace Indoors.Communications.RabbitMQ.Configuration
{
    public class RequesterConfiguration : IRequesterConfiguration
    {
        /// <inheritdoc cref="IRequesterConfiguration.WithExpiresMilliseconds"/>
        public int? WithExpiresMilliseconds { get; set; }

        /// <inheritdoc cref="IRequesterConfiguration.WithPriority"/>
        public byte? WithPriority { get; set; }

        /// <inheritdoc cref="IRequesterConfiguration.WithQueueName"/>
        public string WithQueueName { get; set; }

        public override string ToString()
        {
            return $"{nameof(WithExpiresMilliseconds)}: {WithExpiresMilliseconds}, {nameof(WithPriority)}: {WithPriority}, {nameof(WithQueueName)}: {WithQueueName}";
        }
    }

    public class RequesterConfiguration<TRequest, TRespond> : RequesterConfiguration, IRequesterConfiguration<TRequest, TRespond>
        where TRequest : class
        where TRespond : class
    {

    }
    
    public class RequesterConfigurationTypedWrapper<TRequest, TRespond> : IRequesterConfiguration<TRequest, TRespond>
        where TRequest : class
        where TRespond : class
    {
        public IRequesterConfiguration Configuration { get; }

        public RequesterConfigurationTypedWrapper(IRequesterConfiguration configuration)
        {
            Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public int? WithExpiresMilliseconds => Configuration.WithExpiresMilliseconds;

        public byte? WithPriority => Configuration.WithPriority;

        public string WithQueueName => Configuration.WithQueueName;

        public override string ToString()
        {
            return Configuration.ToString();
        }
    }

}