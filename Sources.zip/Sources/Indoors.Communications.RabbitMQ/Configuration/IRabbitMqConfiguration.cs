using EasyNetQ;

namespace Indoors.Communications.RabbitMQ.Configuration
{
    /// <summary>
    /// Connection configuration to RabbitMQ broker.
    /// </summary>
    public interface IRabbitMqConfiguration
    {
        /// <summary>
        /// This property is required!
        /// </summary>
        string Host { get; }

        /// <summary>
        /// This property specify the port of the connection to the host.<br/>
        /// Set null for default value.
        /// </summary>
        ushort? Port { get; }

        /// <summary>
        /// Set null for default value.
        /// </summary>
        string VirtualHost { get; }

        /// <summary>
        /// Set null for default value.
        /// </summary>
        string UserName { get; }

        /// <summary>
        /// Set null for default value.
        /// </summary>
        string Password { get; }

        /// <summary>
        /// This determines how the delivery_mode in basic.properties is set when a message is published.<br/>
        /// When set to true, messages will be persisted to disk by RabbitMQ and survive a server restart.<br/>
        /// Performance gains can be expected when set to false.<br/>
        /// Set null for default value.
        /// </summary>
        bool? PersistentMessages { get; }

        /// <summary>
        /// True for receive callback when your message has been successfully received by the broker.<br/><br/>
        /// What does 'successfully received' mean? It depends...<br/>
        /// <list type="bullet">
        /// <item> A transient message is confirmed the moment it is en-queued.</item>
        /// <item> A persistent message is confirmed as soon as it is persisted to disk, or when it is consumed on every queue.</item>
        /// <item> An un-routable transient message is confirmed directly it is published.</item>
        /// </list>
        /// Set null for default value.
        /// </summary>
        bool? PublisherConfirms { get; }

        /// <summary>
        /// <para>
        /// The number of messages to prefetch when consuming messages form the broker.
        /// Bottom-line, the property set limit of the number of unacknowledged message on a channel (or connection) when consuming.
        /// </para>
        /// <para>
        /// Finding a suitable prefetch value is a matter of trial and error and will vary from workload to workload.
        /// Values in the 100 through 300 range usually offer optimal throughput and do not run significant risk of overwhelming consumers.
        /// Prefetch value of 1 is the most conservative. It will significantly reduce throughput,in particular environments where consumer connection latency is high.
        /// For Many applications, a higher value would be appropriate and optimal.
        /// Set to zero for unlimited prefetch (NOT RECOMMENDED) or null for default value.
        /// </para>
        /// <para>
        /// Because messages are sent (pushed) to clients asynchronously, there is more then one message "in flight" on a channel at any given moment.
        /// In addition, manual acknowledgments from clients are also inherently asynchronous in nature. So there's a sliding windows of delivery tags that are unacknowledged.
        /// Developers would often prefer to cap the size of this window to avoid the unbounded buffer problem on the consumer end.
        /// </para>
        /// </summary>
        ushort? ConsumerPrefetchCount { get; set; }

        /// <summary>
        /// <para>
        /// The value defines after what period of time the peer tcp connection should be considered unreachable (down) by RabbitMQ and client libraries.
        /// The value is negotiated between the client and rabbitMQ service at the time of connections.
        /// Bottom-line, this is a timeout from the broker.
        /// </para>
        /// <para>
        /// Values lower than 6 can produce false positives and are not recommended.
        /// Set to zero for no heartbeat or null for default value.
        /// </para>
        /// <para>
        /// Note! Currently, for RabbitMQ 3.8.1 version, heartbeat=0 is negotiated but not actually respected by the server.<br/>
        /// There are two options:
        /// <list type="bullet">
        /// <item> Configure the server to negotiate with the value of 0.</item>
        /// <item> Use a very high value (e.g. 30 minutes) which effectively disables heartbeats.</item>
        /// </list>
        /// </para>
        /// </summary>
        ushort? RequestedHeartbeatSeconds { get; }

        /// <summary>
        /// The connection timeout in seconds.<br/>
        /// Set to zero for infinite timeout or null for default value.
        /// </summary>
        ushort? TimeoutSeconds { get; }

        /// <summary>
        /// Interval between reconnection attempts. (default is 5s).
        /// </summary>
        ushort? ConnectIntervalAttemptSeconds { get; }

        /// <summary>
        /// The connection created only of first use by default.<br/>
        /// To avoid this behaviour (a dummy queue will be created) set true.
        /// </summary>
        bool? AvoidConnectionLazyLoading { get; }

        /// <summary>
        /// Creates the necessary connection configuration instance,
        /// which suitable to RabbitMQ rules.
        /// </summary>
        /// <returns>RabbitMQ connection configuration.</returns>
        ConnectionConfiguration GetConnectionConfiguration();
    }
}