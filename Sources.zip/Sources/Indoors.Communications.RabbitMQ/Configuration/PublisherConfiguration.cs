﻿using System;

namespace Indoors.Communications.RabbitMQ.Configuration
{
    public class PublisherConfiguration : IPublisherConfiguration
    {
        /// <inheritdoc cref="IPublisherConfiguration.AsAsync"/>
        public bool? AsAsync { get; set; }

        /// <inheritdoc cref="IPublisherConfiguration.WithTopic"/>
        public string WithTopic { get; set; }

        /// <inheritdoc cref="IPublisherConfiguration.WithExpiresMilliseconds"/>
        public int? WithExpiresMilliseconds { get; set; }

        /// <inheritdoc cref="IPublisherConfiguration.WithPriority"/>
        public byte? WithPriority { get; set; }

        public override string ToString()
        {
            return $"[{nameof(AsAsync)}: {AsAsync}, {nameof(WithTopic)}: {WithTopic}, {nameof(WithExpiresMilliseconds)}: {WithExpiresMilliseconds}, {nameof(WithPriority)}: {WithPriority}]";
        }
    }

    public class PublisherConfiguration<TMessage> : PublisherConfiguration, IPublisherConfiguration<TMessage>
        where TMessage : class
    {

    }

    public class PublisherConfigurationTypedWrapper<TMessage> : IPublisherConfiguration<TMessage>
        where TMessage : class
    {
        public IPublisherConfiguration Configuration { get; }

        public PublisherConfigurationTypedWrapper(IPublisherConfiguration configuration)
        {
            Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }


        public bool? AsAsync => Configuration.AsAsync;
        public string WithTopic => Configuration.WithTopic;
        public int? WithExpiresMilliseconds => Configuration.WithExpiresMilliseconds;
        public byte? WithPriority => Configuration.WithPriority;

        public override string ToString()
        {
            return Configuration.ToString();
        }
    }
}
