﻿using System;

namespace Indoors.Communications.RabbitMQ.Configuration
{
    public class ReplierConfiguration : IReplierConfiguration
    {
        /// <inheritdoc cref="IReplierConfiguration.AsAsync"/>
        public bool? AsAsync { get; set; }

        /// <inheritdoc cref="IReplierConfiguration.WithQueueName"/>
        public string WithQueueName { get; set; }

        /// <inheritdoc cref="IReplierConfiguration.WithDurable"/>
        public bool? WithDurable { get; set; }

        /// <inheritdoc cref="IReplierConfiguration.WithPrefetchCount"/>
        public ushort? WithPrefetchCount { get; set; }

        /// <inheritdoc cref="IReplierConfiguration.WithExpiresMilliseconds"/>
        public int? WithExpiresMilliseconds { get; set; }

        /// <inheritdoc cref="IReplierConfiguration.WithMaxPriority"/>
        public byte? WithMaxPriority { get; set; }

        public override string ToString()
        {
            return $"{nameof(AsAsync)}: {AsAsync}, {nameof(WithQueueName)}: {WithQueueName}, {nameof(WithDurable)}: {WithDurable}, {nameof(WithPrefetchCount)}: {WithPrefetchCount}, {nameof(WithExpiresMilliseconds)}: {WithExpiresMilliseconds}, {nameof(WithMaxPriority)}: {WithMaxPriority}";
        }
    }

    public class ReplierConfiguration<TRequest, TRespond> : ReplierConfiguration, IReplierConfiguration<TRequest, TRespond>
        where TRequest : class
        where TRespond : class
    {
    }

    public class ReplierConfigurationTypedWrapper<TRequest, TRespond> :  IReplierConfiguration<TRequest, TRespond>
        where TRequest : class
        where TRespond : class
    {
        public IReplierConfiguration Configuration { get; }

        public ReplierConfigurationTypedWrapper(IReplierConfiguration configuration)
        {
            Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public bool? AsAsync => Configuration.AsAsync;

        public string WithQueueName => Configuration.WithQueueName;

        public bool? WithDurable => Configuration.WithDurable;

        public ushort? WithPrefetchCount => Configuration.WithPrefetchCount;

        public int? WithExpiresMilliseconds => Configuration.WithExpiresMilliseconds;

        public byte? WithMaxPriority => Configuration.WithMaxPriority;

        public override string ToString()
        {
            return Configuration.ToString();
        }
    }
}