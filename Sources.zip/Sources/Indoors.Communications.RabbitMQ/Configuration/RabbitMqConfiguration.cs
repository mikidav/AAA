using System;
using System.Text;
using EasyNetQ;

namespace Indoors.Communications.RabbitMQ.Configuration
{
    public class RabbitMqConfiguration : IRabbitMqConfiguration
    {
        /// <inheritdoc cref="IRabbitMqConfiguration.Host"/>
        public string Host { get; set; }

        /// <inheritdoc cref="IRabbitMqConfiguration.Port"/>
        public ushort? Port { get; set; }

        /// <inheritdoc cref="IRabbitMqConfiguration.VirtualHost"/>
        public string VirtualHost { get; set; }

        /// <inheritdoc cref="IRabbitMqConfiguration.UserName"/>
        public string UserName { get; set; }

        /// <inheritdoc cref="IRabbitMqConfiguration.Password"/>
        public string Password { get; set; }

        /// <inheritdoc cref="IRabbitMqConfiguration.PersistentMessages"/>
        public bool? PersistentMessages { get; set; }

        /// <inheritdoc cref="IRabbitMqConfiguration.PublisherConfirms"/>
        public bool? PublisherConfirms { get; set; }

        /// <inheritdoc cref="IRabbitMqConfiguration.RequestedHeartbeatSeconds"/>
        public ushort? RequestedHeartbeatSeconds { get; set; }

        /// <inheritdoc cref="IRabbitMqConfiguration.TimeoutSeconds"/>
        public ushort? TimeoutSeconds { get; set; }

        /// <inheritdoc cref="IRabbitMqConfiguration.ConsumerPrefetchCount"/>
        public ushort? ConsumerPrefetchCount { get; set; }

        /// <inheritdoc cref="IRabbitMqConfiguration.ConnectIntervalAttemptSeconds"/>
        public ushort? ConnectIntervalAttemptSeconds { get; set; }

        /// <inheritdoc cref="IRabbitMqConfiguration.AvoidConnectionLazyLoading"/>
        public bool? AvoidConnectionLazyLoading { get; set; }

        /// <summary>
        /// RabbitMQ configuration.
        /// </summary>
        public RabbitMqConfiguration()
        {
            Host = "localhost";
        }

        /// <inheritdoc cref="IRabbitMqConfiguration.GetConnectionConfiguration"/>
        public ConnectionConfiguration GetConnectionConfiguration()
        {
            var connectionConfiguration = new ConnectionConfiguration();

            connectionConfiguration.Hosts.Add(new HostConfiguration { Host = Host });

            if (Port.HasValue)
                connectionConfiguration.Port = Port.Value;

            if (!string.IsNullOrWhiteSpace(VirtualHost))
                connectionConfiguration.VirtualHost = VirtualHost;

            if (!string.IsNullOrWhiteSpace(UserName))
                connectionConfiguration.UserName = UserName;

            if (!string.IsNullOrWhiteSpace(Password))
                connectionConfiguration.Password = Password;

            if (RequestedHeartbeatSeconds.HasValue)
                connectionConfiguration.RequestedHeartbeat = TimeSpan.FromSeconds(RequestedHeartbeatSeconds.Value);

            if (TimeoutSeconds.HasValue)
                connectionConfiguration.Timeout = TimeSpan.FromSeconds(TimeoutSeconds.Value);

            if (PublisherConfirms.HasValue)
                connectionConfiguration.PublisherConfirms = PublisherConfirms.Value;

            if (PersistentMessages.HasValue)
                connectionConfiguration.PersistentMessages = PersistentMessages.Value;

            if (ConsumerPrefetchCount.HasValue)
                connectionConfiguration.PrefetchCount = ConsumerPrefetchCount.Value;

            if (ConnectIntervalAttemptSeconds.HasValue)
                connectionConfiguration.ConnectIntervalAttempt = TimeSpan.FromSeconds(ConnectIntervalAttemptSeconds.Value);

            return connectionConfiguration;
        }


        public override string ToString()
        {
            var s = new StringBuilder();

            s.Append(nameof(Host));
            s.Append('=');
            s.Append(Host);

            if (Port.HasValue)
            {
                s.Append(';');
                s.Append(nameof(Port));
                s.Append('=');
                s.Append(Port.Value);
            }

            if (!string.IsNullOrWhiteSpace(VirtualHost))
            {
                s.Append(';');
                s.Append(nameof(VirtualHost));
                s.Append('=');
                s.Append(VirtualHost);
            }

            if (!string.IsNullOrWhiteSpace(UserName))
            {
                s.Append(';');
                s.Append(nameof(UserName));
                s.Append('=');
                s.Append(UserName);
            }

            if (!string.IsNullOrWhiteSpace(Password))
            {
                s.Append(';');
                s.Append(nameof(Password));
                s.Append('=');
                s.Append(Password);
            }

            if (RequestedHeartbeatSeconds.HasValue)
            {
                s.Append(';');
                s.Append(nameof(RequestedHeartbeatSeconds));
                s.Append('=');
                s.Append(RequestedHeartbeatSeconds.Value);
            }

            if (TimeoutSeconds.HasValue)
            {
                s.Append(';');
                s.Append(nameof(TimeoutSeconds));
                s.Append('=');
                s.Append(TimeoutSeconds.Value);
            }

            if (PublisherConfirms.HasValue)
            {
                s.Append(';');
                s.Append(nameof(PublisherConfirms));
                s.Append('=');
                s.Append(PublisherConfirms.Value);
            }

            if (PersistentMessages.HasValue)
            {
                s.Append(';');
                s.Append(nameof(PersistentMessages));
                s.Append('=');
                s.Append(PersistentMessages.Value);
            }

            if (ConsumerPrefetchCount.HasValue)
            {
                s.Append(';');
                s.Append(nameof(ConsumerPrefetchCount));
                s.Append('=');
                s.Append(ConsumerPrefetchCount.Value);
            }
            
            if (ConnectIntervalAttemptSeconds.HasValue)
            {
                s.Append(';');
                s.Append(nameof(ConnectIntervalAttemptSeconds));
                s.Append('=');
                s.Append(ConnectIntervalAttemptSeconds.Value);
            }
            
            if (AvoidConnectionLazyLoading.HasValue)
            {
                s.Append(';');
                s.Append(nameof(AvoidConnectionLazyLoading));
                s.Append('=');
                s.Append(AvoidConnectionLazyLoading.Value);
            }

            return s.ToString();
        }
    }
}