﻿namespace Indoors.Communications.RabbitMQ.Configuration
{
    public interface IRequesterConfiguration<TRequest, TRespond> : IRequesterConfiguration
        where TRequest : class
        where TRespond : class
    {
    }

    public interface IRequesterConfiguration
    {
        /// <summary>
        /// How long in milliseconds the queue should remain unused (without consumers) before it is automatically deleted.<br/>
        /// Set null for default value.
        /// <para>
        /// Expiry time can be set for a given queue by setting the x-expires argument to queue.declare, or by setting the expires policy.
        /// This controls for how long a queue can be unused before it is automatically deleted.
        /// Unused means the queue has no consumers, the queue has not been re-declared, and basic.get has not been invoked for a duration of at least the expiration period.
        /// This can be used, for example, for RPC-style reply queues, where many queues can be created which may never be drained.
        /// The server guarantees that the queue will be deleted, if unused for at least the expiration period.
        /// No guarantee is given as to how promptly the queue will be removed after the expiration period has elapsed.
        /// Leases of durable queues restart when the server restarts.
        /// </para>
        /// </summary>
        int? WithExpiresMilliseconds { get; }

        /// <summary>
        /// Determine the published message priority.<br/>
        /// Set null for default value.
        /// </summary>
        byte? WithPriority { get; }

        /// <summary>
        /// Sets the queue name to publish to.<br/>
        /// Set null for default value.
        /// </summary>
        string WithQueueName { get; }
    }
}