﻿using Indoors.Communications.Common.Repliers;

namespace Indoors.Communications.RabbitMQ.Reply
{
    public interface IRabbitMqReplier : IReplier
    {

    }
}