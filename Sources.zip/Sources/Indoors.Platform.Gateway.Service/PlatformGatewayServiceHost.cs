﻿using System.Collections.Generic;
using System.Linq;
using Indoors.Commands.Handlers.Common;
using Indoors.Commands.Messages.Common;
using Indoors.Gateways.Common;
using Indoors.Gateways.Common.Hosting;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Service
{
    public class PlatformGatewayServiceHost : ServiceBase, IPlatformGatewayServiceHost
    {
        public IGateway Gateway { get; private set; }

        public IList<ICommandHandler> CommandHandlers { get; private set; }

        public IList<ICommandMessageHandler> CommandMessageHandlers { get; private set; }

        public PlatformGatewayServiceHost(IGateway gateway,
            IEnumerable<ICommandHandler> commandHandlers = null,
            IEnumerable<ICommandMessageHandler> commandMessageHandlers = null,
            ILogger<PlatformGatewayServiceHost> logger = null,
            string id = null)
            : base(logger, id)
        {
            Gateway = gateway;
            CommandHandlers = commandHandlers?.ToList() ?? Enumerable.Empty<ICommandHandler>().ToList();
            CommandMessageHandlers = commandMessageHandlers?.ToList() ?? Enumerable.Empty<ICommandMessageHandler>().ToList();
        }

        protected override void InternalInitialize()
        {
            Gateway.Initialize();

            CommandHandlers.InitializeServices();
            CommandMessageHandlers.InitializeServices();
        }

        protected override void InternalStart()
        {
            Gateway.Start();

            CommandHandlers.StartServices();
            CommandMessageHandlers.StartServices();
        }

        protected override void InternalStop()
        {
            Gateway?.Stop();

            CommandMessageHandlers?.StopServices();
            CommandHandlers?.StopServices();
        }

        protected override void InnerManagedDispose()
        {
            Gateway?.TryDisposeService();

            CommandMessageHandlers?.DisposeServices();
            CommandMessageHandlers?.ClearIfIsNotReadyOnly();
            CommandHandlers?.DisposeServices();
            CommandHandlers?.ClearIfIsNotReadyOnly();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Gateway = null;

            CommandMessageHandlers = null;
            CommandHandlers = null;

            base.InnerNullifyReferencesDispose();
        }
    }
}