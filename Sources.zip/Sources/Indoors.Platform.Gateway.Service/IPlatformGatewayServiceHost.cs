﻿using Indoors.Gateways.Common.Hosting;

namespace Indoors.Platform.Gateway.Service
{
    public interface IPlatformGatewayServiceHost : IGatewayHost
    {
    }
}