﻿using System;
using Autofac;
using Autofac.Core;
using Indoors.Commands.Common;
using Indoors.Commands.Handlers.Common;
using Indoors.Commands.Messages.Common;
using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Subscribers;
using Indoors.Communications.Core.Adapters;
using Indoors.Communications.RabbitMQ.DI.Autofac;
using Indoors.Communications.Core.DI.Autofac;
using Indoors.Communications.Core.Publish;
using Indoors.DomainIcd.Platform;
using Indoors.DomainIcd.Platform.Messages;
using Indoors.DomainIcd.Video;
using Indoors.DomainIcd.Video.Messages;
using Indoors.EntityFramework.Entities;
using Indoors.EntityFramework.Entities.Base;
using Indoors.EntityFramework.Proxy.Modules;
using Indoors.Gateways.Common;
using Indoors.Gateways.Common.Builders;
using Indoors.Gateways.Common.DeviceAdapters;
using Indoors.Gateways.Common.Hosting;
using Indoors.Gateways.Common.Settings;
using Indoors.Platform.Gateway.Adapter.Commands;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Common.Commands;
using Indoors.Platform.Gateway.Logic.Commands;
using Indoors.Platform.Gateway.Logic.DeviceAdapters;
using Indoors.Platform.Gateway.Logic.Entities;
using Indoors.Platform.Gateway.Logic.PlatformInterface;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Data;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Entity;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Handlers;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Incoming;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;
using Indoors.Serializations.Protobuf.DI.Autofac;
using Indoors.Services.Hosting;
using Indoors.Video.Adapters;
using Indoors.Video.Common.Distribution;
using Indoors.Video.Common.Settings;
using Indoors.Video.Common.Types;
using Microsoft.Extensions.Hosting;
using Subgiga;
using Subgiga.Messages;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Service.Container
{
    public enum ChannelType
    {
        LowBandwidth,
        HighBandwidth,
        Dual
    }

    public class PlatformGatewayServiceModuleInstaller : Module
    {
        public ChannelType IncomingChannelType { get; }

        public PlatformGatewayServiceModuleInstaller(ChannelType incomingChannelType = ChannelType.LowBandwidth) : base()
        {
            IncomingChannelType = incomingChannelType;
        }

        protected override void Load(ContainerBuilder builder)
        {
            RegisterFileDescriptors(builder);

            RegisterEntities(builder);

            RegisterPlatformInterfaceCommunication(builder, IncomingChannelType);

            RegisterDataHandlers(builder);

            RegisterCommands(builder);

            RegisterDeviceAdapter(builder);

            RegisterGateway(builder);
        }

        private static void RegisterDataHandlers(ContainerBuilder builder)
        {
            RegisterPlatformInterfaceDataHandler<IncomingMessageWrapper, RosPoseStamped, PlatformInterfacePositionDataMessageAdapter>(builder);
            RegisterPlatformInterfaceDataHandler<IncomingMessageWrapper, RosInt16MultiArray, PlatformInterfaceGeneralStatusMessageAdapter>(builder);
            RegisterPlatformInterfaceDataHandler<IncomingMessageWrapper, RosMsgHeader, PlatformInterfaceSystemStateMessageAdapter>(builder);
            builder.RegisterType<PlatformStatusHandler>()
                .As<IPlatformDataHandler>()
                .SingleInstance();

            RegisterPlatformInterfaceDataHandler<IncomingMessageWrapper, RosSensorImage, PlatformInterfaceVideoMessageAdapter>(builder);
            RegisterPlatformInterfaceEntityDataHandler<RosSensorImage, VideoStream, PlatformInterfaceVideoStreamEntityDataAdapter>(builder);

            RegisterPlatformInterfaceVideoDataHandler(builder);

            RegisterPlatformInterfaceDataHandler<IncomingMessageWrapper, RosPointArray, PlatformInterfaceFrontierMessageAdapter>(builder);
            RegisterPlatformInterfaceDataHandler<IncomingMessageWrapper, RosPoseArray, PlatformInterfaceRouteMessageAdapter>(builder);

            builder.RegisterType<NavigationHandler>()
                .As<IPlatformDataHandler>()
                .SingleInstance();
        }

        private static void RegisterPlatformInterfaceVideoDataHandler(ContainerBuilder builder)
        {
            builder.RegisterType<VideoFrameHandler>()
                .As<IPlatformDataHandler>()
                .SingleInstance();

            var defaultVideoDistributionSettings = new VideoDistributionSettings
            {
                DistributionProtocolType = DistributionProtocolType.None
            };

            builder.Register<IVideoDistributionSettings>(_ => defaultVideoDistributionSettings)
                .IfNotRegistered(typeof(IVideoDistributionSettings))
                .SingleInstance();

            var rabbitMqPublisherName = builder.RegisterRabbitMqPublisher<VideoFrameMessage>();
            var udpPublisherName = builder.RegisterUdpPublisher<VideoFrameMessage>("VideoDomainIcdUdpPublisherSettings");

            builder.RegisterType<AdaptingTypedPublisher<IVideoFrame<IVideoFrameMetadata>, VideoFrameMessage>>()
                .AsSelf()
                .As<ITypedObjectPublisher<IVideoFrame<IVideoFrameMetadata>>>()
                .WithParameter(ResolvePublisherByDistributionProtocolType(rabbitMqPublisherName, udpPublisherName))
                .SingleInstance();

            builder.RegisterType<DomainIcdVideoFrameWithMetadataPublishMessageAdapter>()
                .AsSelf()
                .As<IPublishDataMessageAdapter<IVideoFrame<IVideoFrameMetadata>, VideoFrameMessage>>()
                .SingleInstance();
        }

        private static ResolvedParameter ResolvePublisherByDistributionProtocolType(string rabbitMqPublisherName, string udpPublisherName)
        {
            return new(
                (pi, _) => pi.ParameterType == typeof(ITypedObjectPublisher<VideoFrameMessage>),
                (_, ctx) =>
                {
                    var distributionProtocolType = DistributionProtocolType.RabbitMq;
                    var videoDistributionSettings = ctx.ResolveOptional<IVideoDistributionSettings>();
                    if (videoDistributionSettings != null)
                        distributionProtocolType = videoDistributionSettings.DistributionProtocolType;

                    return distributionProtocolType switch
                    {
                        DistributionProtocolType.Udp => ctx.ResolveNamed<ITypedObjectPublisher<VideoFrameMessage>>(udpPublisherName),
                        DistributionProtocolType.RabbitMq => ctx.ResolveNamed<ITypedObjectPublisher<VideoFrameMessage>>(rabbitMqPublisherName),
                        _ => null
                    };
                });
        }

        private static void RegisterPlatformInterfaceEntityDataHandler<TPlatformData, TEntity, TAdapter>(ContainerBuilder builder)
            where TPlatformData : class
            where TEntity : class, IEntity
            where TAdapter : IPlatformInterfaceEntityDataAdapter<TPlatformData, TEntity>
        {
            builder.RegisterType<TAdapter>()
                .As<IPlatformInterfaceEntityDataAdapter<TPlatformData, TEntity>>()
                .SingleInstance();

            builder.RegisterType<EntityHandler<TPlatformData, TEntity>>()
                .As<IPlatformDataHandler>()
                .SingleInstance();
        }

        private static void RegisterPlatformInterfaceDataHandler<TPlatformMessage, TPlatformData, TAdapter>(ContainerBuilder builder)
            where TPlatformMessage : class
            where TPlatformData : class
            where TAdapter : IPlatformInterfaceDataMessageAdapter<TPlatformMessage, TPlatformData>
        {
            builder.RegisterType<PlatformDataHandler<TPlatformMessage, TPlatformData>>()
                .As<IDataNotifier<TPlatformData>, IPlatformDataHandler>()
                .SingleInstance();

            builder.RegisterType<TAdapter>()
                .As<IPlatformInterfaceDataMessageAdapter<TPlatformMessage, TPlatformData>>()
                .SingleInstance();
        }

        private static void RegisterCommands(ContainerBuilder builder)
        {
            RegisterPlatformGeneralCommandHandler<PlatformSystemBootCommandParameters,
                PlatformSystemBootCommandMessage,
                PlatformDomainIcdSystemBootCommandAdapter,
                OutgoingSystemInstructionMessageWrapper,
                PlatformInterfaceSystemBootCommandMessageAdapter>(builder);

            RegisterPlatformGeneralCommandHandler<PlatformRecoverCommandParameters,
                PlatformRecoverCommandMessage,
                PlatformDomainIcdRecoverCommandAdapter,
                OutgoingCommandMessageWrapper,
                PlatformInterfaceRecoverCommandMessageAdapter>(builder);

            RegisterPlatformGeneralCommandHandler<PlatformSetNavigationModeCommandParameters,
                PlatformSetNavigationModeCommandMessage,
                PlatformDomainIcdSetNavigationModeCommandAdapter,
                OutgoingSystemInstructionMessageWrapper,
                PlatformInterfaceSetNavigationModeCommandMessageAdapter>(builder);

            RegisterPlatformGeneralCommandHandler<PlatformLandCommandParameters,
                PlatformLandCommandMessage,
                PlatformDomainIcdLandCommandAdapter,
                OutgoingCommandMessageWrapper,
                PlatformInterfaceLandCommandMessageAdapter>(builder);

            RegisterPlatformGeneralCommandHandler<PlatformTakeOffCommandParameters,
                PlatformTakeoffCommandMessage,
                PlatformDomainIcdTakeOffCommandAdapter,
                OutgoingCommandMessageWrapper,
                PlatformInterfaceTakeOffCommandMessageAdapter>(builder);

            RegisterPlatformGeneralCommandHandler<PlatformMoveCommandParameters,
                PlatformMoveCommandMessage,
                PlatformDomainIcdMoveCommandAdapter,
                OutgoingCommandMessageWrapper,
                PlatformInterfaceMoveCommandMessageAdapter>(builder);

            RegisterPlatformGeneralCommandHandler<PlatformArmCommandParameters,
                PlatformArmCommandMessage,
                PlatformDomainIcdArmCommandAdapter,
                OutgoingCommandMessageWrapper,
                PlatformInterfaceArmCommandMessageAdapter>(builder);

            RegisterPlatformGeneralCommandHandler<PlatformDisarmCommandParameters,
                PlatformDisarmCommandMessage,
                PlatformDomainIcdDisarmCommandAdapter,
                OutgoingCommandMessageWrapper,
                PlatformInterfaceDisarmCommandMessageAdapter>(builder);

            RegisterPlatformGeneralCommandHandler<PlatformSetOperationalModeCommandParameters,
                PlatformSetOperationalModeCommandMessage,
                PlatformDomainIcdSetOperationalModeCommandAdapter,
                OutgoingCommandMessageWrapper,
                PlatformInterfaceSetOperationalModeCommandMessageAdapter>(builder);

            RegisterPlatformGeneralMultiExecuteCommandHandler<PlatformReturnHomeCommandParameters,
                PlatformReturnHomeCommandMessage,
                PlatformDomainIcdReturnHomeCommandAdapter,
                OutgoingCommandMessageWrapper,
                PlatformInterfaceReturnHomeCommandMessageAdapter>(builder, 2);

            RegisterPlatformGeneralCommandHandler<PlatformGoToCommandParameters,
                PlatformGoToCommandMessage,
                PlatformDomainIcdGoToCommandAdapter,
                OutgoingCommandMessageWrapper,
                PlatformInterfaceGoToCommandMessageAdapter>(builder);

            RegisterPlatformGeneralCommandHandler<PlatformGoToMapPixelCommandParameters,
                PlatformGoToMapPixelCommandMessage,
                PlatformDomainIcdGoToMapPixelCommandAdapter,
                OutgoingCommandMessageWrapper,
                PlatformInterfaceGoToMapPixelCommandMessageAdapter>(builder);

            RegisterPlatformGeneralCommandHandler<PlatformGoToVideoPixelCommandParameters,
                PlatformGoToVideoPixelCommandMessage,
                PlatformDomainIcdGoToVideoPixelCommandAdapter,
                OutgoingCommandMessageWrapper,
                PlatformInterfaceGoToVideoPixelCommandMessageAdapter>(builder);
        }

        private static void RegisterFileDescriptors(ContainerBuilder builder)
        {
            builder.RegisterFileDescriptorProvider<PlatformDomainIcdDescriptorProvider>();
            builder.RegisterFileDescriptorProvider<VideoDomainIcdDescriptorProvider>();
            //builder.RegisterFileDescriptorProvider<PlatformIcdFileDescriptorProvider>();
        }

        private static void RegisterEntities(ContainerBuilder builder)
        {
            RegisterEntity<PlatformStatus, PlatformStatusEntityProvider>(builder);
            RegisterEntity<VideoStream, VideoStreamEntityProvider>(builder);
            RegisterEntity<Navigation, NavigationEntityProvider>(builder);
        }

        private static void RegisterGateway(ContainerBuilder builder)
        {
            builder.RegisterType<GatewaySettings>()
                .As<IGatewaySettings>()
                .SingleInstance();

            builder.RegisterType<InjectionBasedGatewayBuilder>()
                .As<ICustomGatewayBuilder>()
                .SingleInstance();

            builder.RegisterType<PlatformGatewayServiceHost>()
                .As<IGatewayHost>()
                .WithParameter(ResolvedTypedParameterByFactory<IGateway, ICustomGatewayBuilder>(gatewayBuilder => gatewayBuilder.BuildGateway()));

            builder.RegisterType<ServicesHostedService<IGatewayHost>>()
                    .As<IHostedService>()
                    .WithParameter(new NamedParameter("id", "PlatformGatewayServiceHost"));
        }

        private static void RegisterDeviceAdapter(ContainerBuilder builder)
        {
            builder.RegisterType<DeviceAdapterIncomingHandler>()
                .As<IDeviceAdapterIncomingHandler>()
                .SingleInstance();

            builder.RegisterType<DeviceAdapterOutgoingHandler>()
                .As<IDeviceAdapterOutgoingHandler>()
                .SingleInstance();

            builder.RegisterType<PlatformGatewayDeviceAdapter>()
                .As<IDeviceAdapter>()
                .SingleInstance();
        }

        private static void RegisterPlatformInterfaceCommunication(ContainerBuilder builder, ChannelType incomingChannelType)
        {
            switch (incomingChannelType)
            {
                case ChannelType.LowBandwidth:
                    {
                        var udpBufferSubscriberName = builder.RegisterUdpBufferSubscriber();

                        builder.RegisterType<PlatformSubscriber>()
                                .As<IPlatformSubscriber, ITypedObjectSubscriber<IncomingMessageWrapper>>()
                                .UsingConstructor(typeof(IBufferSubscriber<byte[]>), typeof(ILogger), typeof(string))
                                .WithParameter(ResolvedParameter.ForNamed<IBufferSubscriber<byte[]>>(udpBufferSubscriberName))
                                .SingleInstance();
                    }
                    break;
                case ChannelType.HighBandwidth:
                    {
                        var secondarySubscriberName = RegisterSecondaryPlatformInterfaceCommunication(builder);

                        builder.RegisterType<PlatformSubscriber>()
                                .As<IPlatformSubscriber, ITypedObjectSubscriber<IncomingMessageWrapper>>()
                                .UsingConstructor(typeof(IBufferSubscriber<byte[]>), typeof(ILogger), typeof(string))
                                .WithParameter(ResolvedParameter.ForNamed<IBufferSubscriber<byte[]>>(secondarySubscriberName))
                                .SingleInstance();
                    }
                    break;
                case ChannelType.Dual:
                    {
                        var udpBufferSubscriberName = builder.RegisterUdpBufferSubscriber();
                        var secondarySubscriberName = RegisterSecondaryPlatformInterfaceCommunication(builder);

                        builder.RegisterType<PlatformSubscriber>()
                                .As<IPlatformSubscriber, ITypedObjectSubscriber<IncomingMessageWrapper>>()
                                .WithParameters(new[] { 
                                    new ResolvedParameter((pi, c) => pi.Name == "subscriber",
                                                          (pi, c) => c.ResolveNamed<IBufferSubscriber<byte[]>>(udpBufferSubscriberName)),
                                    new ResolvedParameter((pi, c) => pi.Name == "secondarySubscriber",
                                                          (pi, c) => c.ResolveNamed<IBufferSubscriber<byte[]>>(secondarySubscriberName))})
                                .SingleInstance();
                    }
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(incomingChannelType), incomingChannelType, "Not Implemented");
            }
            
            var udpBufferPublisherName = builder.RegisterUdpBufferPublisher();
            builder.RegisterType<PlatformPublisher>()
                .As<IPlatformPublisher, ITypedObjectPublisher<OutgoingCommandMessageWrapper>, ITypedObjectPublisher<OutgoingSystemInstructionMessageWrapper>>()
                .WithParameter(ResolvedParameter.ForNamed<IBufferPublisher<byte[]>>(udpBufferPublisherName))
                .SingleInstance();
        }

        private static string RegisterSecondaryPlatformInterfaceCommunication(ContainerBuilder builder)
        {
            const string secondarySubscriberName = "SecondarySubscriber";

            var udpBufferSubscriberName =
                builder.RegisterUdpBufferSubscriber($"{secondarySubscriberName}Settings", secondarySubscriberName);

            return udpBufferSubscriberName;
        }

        private static void RegisterEntity<TEntity, TEntityProvider>(ContainerBuilder builder)
            where TEntity : class, IEntity
            where TEntityProvider : IEntityProvider<TEntity>
        {
            builder.RegisterEntityType<TEntity>();

            builder.RegisterType<TEntityProvider>()
                .As<IEntityProvider<TEntity>>()
                .SingleInstance();
        }

        private static void RegisterPlatformGeneralMultiExecuteCommandHandler
            <TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter, TPlatformInterfaceMessage, TPlatformInterfaceCommandMessageAdapter>(ContainerBuilder builder, uint numberOfExecutions)
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IPlatformCommandParameter
            where TPlatformInterfaceMessage : class
            where TPlatformInterfaceCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<TCommandParameter, TPlatformInterfaceMessage>
        {
            builder.RegisterType<PlatformGeneralMultiExecuteCommand<TCommandParameter, TPlatformInterfaceMessage>>()
                .WithParameter("numberOfExecutions", numberOfExecutions)
                .As<IPlatformGeneralCommand<TCommandParameter>>()
                .SingleInstance();

            RegisterCommandHandler
            <IPlatformGeneralCommand<TCommandParameter>,
                TCommandParameter,
                TCommandDomainMessage,
                TDomainMessageAdapter,
                TPlatformInterfaceMessage,
                TPlatformInterfaceCommandMessageAdapter>(builder);
        }

        private static void RegisterPlatformGeneralCommandHandler
            <TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter, TPlatformInterfaceMessage, TPlatformInterfaceCommandMessageAdapter>(ContainerBuilder builder)
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IPlatformCommandParameter
            where TPlatformInterfaceMessage : class
            where TPlatformInterfaceCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<TCommandParameter, TPlatformInterfaceMessage>
        {
            builder.RegisterType<PlatformGeneralCommand<TCommandParameter, TPlatformInterfaceMessage>>()
                .As<IPlatformGeneralCommand<TCommandParameter>>()
                .SingleInstance();

            RegisterCommandHandler
            <IPlatformGeneralCommand<TCommandParameter>,
                TCommandParameter,
                TCommandDomainMessage,
                TDomainMessageAdapter,
                TPlatformInterfaceMessage,
                TPlatformInterfaceCommandMessageAdapter>(builder);
        }

        private static void RegisterCommandHandler
        <TCommandInterface, TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter, TPlatformInterfaceMessage, TPlatformInterfaceCommandMessageAdapter>(ContainerBuilder builder)
            where TCommandInterface : ICommand<TCommandParameter>
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IPlatformCommandParameter
            where TPlatformInterfaceMessage : class
            where TPlatformInterfaceCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<TCommandParameter, TPlatformInterfaceMessage>
        {

            builder.RegisterRabbitMqSubscriber<TCommandDomainMessage>();

            builder.RegisterType<TDomainMessageAdapter>()
                .As<IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>, ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage>>()
                .SingleInstance();

            builder.RegisterType<CommandMessageHandler<TCommandParameter, TCommandDomainMessage>>()
                .As<ICommandMessageHandler, ICommandNotifier<TCommandParameter>>()
                .SingleInstance();

            builder.RegisterType<CommandHandler<TCommandInterface, TCommandParameter>>()
                .As<ICommandHandler>()
                .SingleInstance();

            builder.RegisterType<TPlatformInterfaceCommandMessageAdapter>()
                .As<IPlatformInterfaceCommandMessageAdapter<TCommandParameter, TPlatformInterfaceMessage>>()
                .IfNotRegistered(typeof(IPlatformInterfaceCommandMessageAdapter<TCommandParameter, TPlatformInterfaceMessage>))
                .SingleInstance();
        }


        private static Parameter ResolvedTypedParameterByFactory<TType, TFactory>(Func<TFactory, TType> factoryInvokeFunc, string name = null) => new ResolvedParameter(
            (pi, _) => pi.ParameterType == typeof(TType),
            (_, ctx) =>
            {
                var factory = string.IsNullOrWhiteSpace(name)
                    ? ctx.Resolve<TFactory>()
                    : ctx.ResolveNamed<TFactory>(name);
                var type = factoryInvokeFunc(factory);
                return type;
            });

    }
}