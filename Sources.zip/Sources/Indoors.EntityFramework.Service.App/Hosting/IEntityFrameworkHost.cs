﻿using Indoors.Services.Common;

namespace Indoors.EntityFramework.Service.App.Hosting
{
    public interface IEntityFrameworkHost : IService
    {
    }
}
