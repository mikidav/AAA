﻿using Indoors.EntityFramework.Service.Hosting;
using Indoors.Services.Common;

namespace Indoors.EntityFramework.Service.App.Hosting
{
    public class EntityFrameworkHost : ServiceBase, IEntityFrameworkHost
    {
        private readonly IEntityFrameworkServiceHost _entityFrameworkServiceHost;

        public EntityFrameworkHost(IEntityFrameworkServiceHost entityFrameworkServiceHost)
        {
            _entityFrameworkServiceHost = entityFrameworkServiceHost;
        }

        protected override void InternalInitialize()
        {
            _entityFrameworkServiceHost.Initialize();
        }

        protected override void InternalStart()
        {
            _entityFrameworkServiceHost.Start();
        }

        protected override void InternalStop()
        {
            _entityFrameworkServiceHost.Stop();
        }
    }
}
