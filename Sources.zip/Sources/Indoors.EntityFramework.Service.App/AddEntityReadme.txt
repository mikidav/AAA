﻿Step for Adding entity into the system:

1. Define the Entity in Indoors.EntityFramework.Entities
2. Define the Proto Entity in Indoors.DomainIcd.Entities.EntitiesStructures
3. Add adapter methods for Entity<->Proto in Indoors.DomainIcd.Entities.Adapters.EntitiesAdapter
4. Add Module registration in Indoors.EntityFramework.Service.EntityFrameworkServiceModuleInstaller
5. AddModule registration in EntityFrameworkRegistrationExtensions
6. Run and pray for good :)