﻿using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Common.Commands;

namespace Indoors.Platform.Gateway.Common
{
    public interface IPlatformFacade
    {
        IPlatformGeneralCommand<PlatformSystemBootCommandParameters> SystemBootCommand { get; }
        IPlatformGeneralCommand<PlatformRecoverCommandParameters> RecoverCommand { get; }
        IPlatformGeneralCommand<PlatformSetNavigationModeCommandParameters> SetNavigationModeCommand { get; }
        IPlatformGeneralCommand<PlatformLandCommandParameters> LandCommand { get; }
        IPlatformGeneralCommand<PlatformTakeOffCommandParameters> TakeOffCommand { get; }
        IPlatformGeneralCommand<PlatformMoveCommandParameters> GoCommand { get; }
        IPlatformGeneralCommand<PlatformArmCommandParameters> ArmCommand { get; }
        IPlatformGeneralCommand<PlatformDisarmCommandParameters> DisarmCommand { get; }
        IPlatformGeneralCommand<PlatformSetOperationalModeCommandParameters> SetOperationalModeCommand { get; }
        IPlatformGeneralCommand<PlatformReturnHomeCommandParameters> ReturnHomeCommand { get; }
        IPlatformGeneralCommand<PlatformGoToCommandParameters> GoToCommand { get; }
        IPlatformGeneralCommand<PlatformGoToMapPixelCommandParameters> GoToMapPixelCommand { get; }
        IPlatformGeneralCommand<PlatformGoToVideoPixelCommandParameters> GoToVideoPixelCommand { get; }
    }
}