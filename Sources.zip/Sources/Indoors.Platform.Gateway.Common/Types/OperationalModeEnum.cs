﻿namespace Indoors.Platform.Gateway.Common.Types
{
    public enum OperationalModeEnum
    {
        ExplorationStart,
        ExplorationStop,
        ManualStart,
        ManualStop
    }
}