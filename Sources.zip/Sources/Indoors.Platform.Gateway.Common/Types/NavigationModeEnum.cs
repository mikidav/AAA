﻿namespace Indoors.Platform.Gateway.Common.Types
{
    public enum NavigationModeEnum
    {
        Unknown,
        Indoors,
        Outdoors
    }
}