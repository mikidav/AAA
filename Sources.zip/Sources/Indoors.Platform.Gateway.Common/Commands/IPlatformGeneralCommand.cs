﻿using Indoors.Commands.Common;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Common.Commands
{
    public interface IPlatformGeneralCommand<TCommandParameter> : ICommand<TCommandParameter>
        where TCommandParameter : IPlatformCommandParameter
    {

    }
}