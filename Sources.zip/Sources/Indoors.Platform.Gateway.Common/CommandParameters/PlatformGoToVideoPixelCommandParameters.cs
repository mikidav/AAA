﻿using Indoors.EntityFramework.Entities.Types;

namespace Indoors.Platform.Gateway.Common.CommandParameters
{
    public class PlatformGoToVideoPixelCommandParameters : PlatformCommandParameter
    {
        public Pixel Location { get; set; }
        public string FrameId { get; set; }

        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(Location)}: {Location}, {nameof(FrameId)}: {FrameId}";
        }
    }
}
