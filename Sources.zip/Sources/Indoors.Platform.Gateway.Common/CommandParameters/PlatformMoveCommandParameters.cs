﻿namespace Indoors.Platform.Gateway.Common.CommandParameters
{
    public class PlatformMoveCommandParameters : PlatformCommandParameter
    {
        public double AngleXYDegrees { get; set; }

        public double DistanceXMeters { get; set; }
        public double DistanceYMeters { get; set; }
        public double DistanceZMeters { get; set; }

        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(AngleXYDegrees)}: {AngleXYDegrees}, {nameof(DistanceXMeters)}: {DistanceXMeters}, {nameof(DistanceYMeters)}: {DistanceYMeters}, {nameof(DistanceZMeters)}: {DistanceZMeters}";
        }
    }
}
