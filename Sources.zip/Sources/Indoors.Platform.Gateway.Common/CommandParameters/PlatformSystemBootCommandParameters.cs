﻿namespace Indoors.Platform.Gateway.Common.CommandParameters
{
    public class PlatformSystemBootCommandParameters : PlatformCommandParameter
    {
    }
}