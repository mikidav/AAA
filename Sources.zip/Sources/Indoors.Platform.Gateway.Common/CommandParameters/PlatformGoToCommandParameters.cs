﻿using Indoors.EntityFramework.Entities.Types;

namespace Indoors.Platform.Gateway.Common.CommandParameters
{
    public class PlatformGoToCommandParameters : PlatformCommandParameter
    {
        public GeoPoint3D Location { get; set; }

        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(Location)}: {Location}";
        }
    }
}
