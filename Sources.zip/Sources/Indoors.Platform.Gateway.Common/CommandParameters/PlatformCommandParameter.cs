﻿using System;

namespace Indoors.Platform.Gateway.Common.CommandParameters
{
    public class PlatformCommandParameter : IPlatformCommandParameter
    {
        public string PlatformId { get; set; }

        public virtual bool IsPlatformIdValid => string.IsNullOrEmpty(PlatformId);

        public override string ToString()
        {
            return $"{nameof(PlatformId)}: {PlatformId}";
        }
    }
}