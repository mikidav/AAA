﻿namespace Indoors.Platform.Gateway.Common.CommandParameters
{
    public class PlatformLandCommandParameters : PlatformCommandParameter
    {
    }
}
