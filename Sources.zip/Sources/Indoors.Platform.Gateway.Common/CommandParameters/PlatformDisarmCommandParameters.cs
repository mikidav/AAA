﻿namespace Indoors.Platform.Gateway.Common.CommandParameters
{
    public class PlatformDisarmCommandParameters : PlatformCommandParameter
    {
    }
}
