﻿using Indoors.Platform.Gateway.Common.Types;

namespace Indoors.Platform.Gateway.Common.CommandParameters
{
    public class PlatformSetOperationalModeCommandParameters : PlatformCommandParameter
    {
        public OperationalModeEnum Mode { get; set; }
    }
}