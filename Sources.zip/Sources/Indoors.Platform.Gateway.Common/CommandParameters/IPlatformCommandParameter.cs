﻿namespace Indoors.Platform.Gateway.Common.CommandParameters
{
    public interface IPlatformCommandParameter
    {
        /// <summary>
        /// A unique value for identifying the platform for which the command is intended.<br />
        /// this field is mandatory
        /// </summary>
        string PlatformId { get; }

        bool IsPlatformIdValid { get; }
    }
}