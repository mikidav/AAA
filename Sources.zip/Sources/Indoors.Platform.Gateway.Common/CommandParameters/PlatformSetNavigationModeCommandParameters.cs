﻿using Indoors.Platform.Gateway.Common.Types;

namespace Indoors.Platform.Gateway.Common.CommandParameters
{
    public class PlatformSetNavigationModeCommandParameters : PlatformCommandParameter
    {
        public NavigationModeEnum Mode { get; set; }
    }
}