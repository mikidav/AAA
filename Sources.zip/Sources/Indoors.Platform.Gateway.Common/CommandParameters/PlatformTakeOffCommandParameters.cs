﻿namespace Indoors.Platform.Gateway.Common.CommandParameters
{
    public class PlatformTakeOffCommandParameters : PlatformLandCommandParameters
    {
        public double HeightMeters { get; set; }

        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(HeightMeters)}: {HeightMeters}";
        }
    }
}