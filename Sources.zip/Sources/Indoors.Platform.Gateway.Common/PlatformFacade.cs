﻿using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Common.Commands;

namespace Indoors.Platform.Gateway.Common
{
    public class PlatformFacade : IPlatformFacade
    {
        public IPlatformGeneralCommand<PlatformSystemBootCommandParameters> SystemBootCommand { get; }
        public IPlatformGeneralCommand<PlatformRecoverCommandParameters> RecoverCommand { get; }
        public IPlatformGeneralCommand<PlatformSetNavigationModeCommandParameters> SetNavigationModeCommand { get; }
        public IPlatformGeneralCommand<PlatformTakeOffCommandParameters> TakeOffCommand { get; }
        public IPlatformGeneralCommand<PlatformMoveCommandParameters> GoCommand { get; }
        public IPlatformGeneralCommand<PlatformLandCommandParameters> LandCommand { get; }
        public IPlatformGeneralCommand<PlatformArmCommandParameters> ArmCommand { get; }
        public IPlatformGeneralCommand<PlatformDisarmCommandParameters> DisarmCommand { get; }
        public IPlatformGeneralCommand<PlatformSetOperationalModeCommandParameters> SetOperationalModeCommand { get; }
        public IPlatformGeneralCommand<PlatformReturnHomeCommandParameters> ReturnHomeCommand { get; }
        public IPlatformGeneralCommand<PlatformGoToCommandParameters> GoToCommand { get; }
        public IPlatformGeneralCommand<PlatformGoToMapPixelCommandParameters> GoToMapPixelCommand { get; }
        public IPlatformGeneralCommand<PlatformGoToVideoPixelCommandParameters> GoToVideoPixelCommand { get; }

        public PlatformFacade(
            IPlatformGeneralCommand<PlatformSystemBootCommandParameters> systemBootCommand,
            IPlatformGeneralCommand<PlatformSetNavigationModeCommandParameters> setNavigationModeCommand,
            IPlatformGeneralCommand<PlatformTakeOffCommandParameters> takeOffCommand,
            IPlatformGeneralCommand<PlatformLandCommandParameters> landCommand,
            IPlatformGeneralCommand<PlatformMoveCommandParameters> goCommand,
            IPlatformGeneralCommand<PlatformArmCommandParameters> armCommand,
            IPlatformGeneralCommand<PlatformDisarmCommandParameters> disarmCommand,
            IPlatformGeneralCommand<PlatformSetOperationalModeCommandParameters> setOperationalModeCommand,
            IPlatformGeneralCommand<PlatformReturnHomeCommandParameters> returnHomeCommand,
            IPlatformGeneralCommand<PlatformGoToCommandParameters> goToCommand,
            IPlatformGeneralCommand<PlatformGoToMapPixelCommandParameters> goToMapPixelCommand,
            IPlatformGeneralCommand<PlatformGoToVideoPixelCommandParameters> goToVideoPixelCommand, 
            IPlatformGeneralCommand<PlatformRecoverCommandParameters> recoverCommand)
        {
            SystemBootCommand = systemBootCommand;
            SetNavigationModeCommand = setNavigationModeCommand;
            TakeOffCommand = takeOffCommand;
            LandCommand = landCommand;
            GoCommand = goCommand;
            ArmCommand = armCommand;
            DisarmCommand = disarmCommand;
            SetOperationalModeCommand = setOperationalModeCommand;
            ReturnHomeCommand = returnHomeCommand;
            GoToCommand = goToCommand;
            GoToMapPixelCommand = goToMapPixelCommand;
            GoToVideoPixelCommand = goToVideoPixelCommand;
            RecoverCommand = recoverCommand;
        }
    }
}