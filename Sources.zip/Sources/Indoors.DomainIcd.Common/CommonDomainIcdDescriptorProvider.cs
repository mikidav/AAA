﻿using System.Collections.Generic;
using Google.Protobuf.Reflection;
using Indoors.Serializations.Protobuf;

namespace Indoors.DomainIcd.Common
{
    public class CommonDomainIcdDescriptorProvider : IFileDescriptorProvider
    {
        public IEnumerable<FileDescriptor> Descriptors => new[] { CommonMessagesReflection.Descriptor };
    }
}
