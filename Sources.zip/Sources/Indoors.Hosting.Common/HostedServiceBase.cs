﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Indoors.Hosting.Common
{
    /// <summary>
    /// A base hosting implementation for hosted service.
    /// </summary>
    public abstract class HostedServiceBase : IHostedService, IDisposable
    {
        private bool m_disposed;

        protected ILogger Logger { get; }

        public string Id { get; }
        public bool IsRunning { get; private set; }

        protected HostedServiceBase(ILogger logger = null, string id = null)
        {
            Logger = logger;
            Id = GenerateId(id);

            m_disposed = false;
            IsRunning = false;
        }

        private string GenerateId(string id)
        {
            if (!string.IsNullOrWhiteSpace(id))
                return id;

            var name = GetType().Name;
            var guid = Guid.NewGuid().ToString();
            var generatedId = $"{name}-{guid}";
            return generatedId;
        }

        /// <summary>
        /// Triggered when the application host is ready to start the service.
        /// </summary>
        /// <param name="cancellationToken">Indicates that the start process has been aborted.</param>
        public virtual Task StartAsync(CancellationToken cancellationToken)
        {
            if (IsRunning)
            {
                // The service already running
                Logger?.LogInformation($"The service start operation called when the service already running. Id: {Id}");
                return Task.CompletedTask;
            }

            Task startingTask;
            try
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    // The starting task already aborted..
                    // This will bubble cancellation to the caller
                    Logger?.LogInformation($"The service start operation has been aborted. Id: {Id}");
                    return Task.FromCanceled(cancellationToken);
                }

                Logger?.LogInformation($"Starting service... Id: {Id}");

                startingTask = InnerStartAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                Logger?.LogError(ex, $"Some exception occurred during starting operation! Id: {Id}");

                // This will bubble failure to the caller
                startingTask = Task.FromException(ex);
            }

            if (startingTask.IsCompleted)
            {
                IsRunning = startingTask.Status == TaskStatus.RanToCompletion;
                Logger?.LogInformation($"The service was started synchronously... Id: {Id}, IsRunning: {IsRunning}");
            }
            else
            {
                IsRunning = true;
                Logger?.LogInformation($"The service is starting asynchronously... Id: {Id}, IsRunning: {IsRunning}");
            }

            return startingTask;
        }

        /// <summary>
        /// Triggered when the application host is performing a graceful shutdown.
        /// </summary>
        /// <param name="cancellationToken">Indicates that the shutdown process should no longer be graceful.</param>
        public virtual Task StopAsync(CancellationToken cancellationToken)
        {
            if (!IsRunning)
            {
                // The service already running
                Logger?.LogInformation($"Stop service operation request was received while it was not running. Id: {Id}");
                return Task.CompletedTask;
            }

            Task stoppingTask;
            try
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    // The stopping task already aborted..
                    // This will bubble cancellation to the caller
                    Logger?.LogInformation($"The service start process has been aborted. Id: {Id}");
                    return Task.FromCanceled(cancellationToken);
                }

                Logger?.LogInformation($"Stopping service... Id: {Id}");

                stoppingTask = InnerStopAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                Logger?.LogError(ex, $"Some exception occurred during stopping operation! Id: {Id}");

                // This will bubble failure to the caller
                stoppingTask = Task.FromException(ex);
            }

            if (stoppingTask.IsCompleted)
            {
                IsRunning = stoppingTask.Status != TaskStatus.RanToCompletion;
                Logger?.LogInformation($"The service was stopped synchronously... Id: {Id}, IsRunning: {IsRunning}");
            }
            else
            {
                IsRunning = true;
                Logger?.LogInformation($"The service is stopping asynchronously... Id: {Id}, IsRunning: {IsRunning}");
            }

            return stoppingTask;
        }

        /// <summary>
        /// This method is called when the <see cref="IHostedService"/> stopped.
        /// The implementation should return a task that represents the stop sequence of the service.
        /// The stopping process will happen in synchronously as long as the implementation will continue on the calling task.
        /// </summary>
        /// <param name="cancellationToken">Indicates that the start process has been aborted.</param>
        /// <returns>A <see cref="Task"/> that represents the starting process.</returns>
        protected abstract Task InnerStartAsync(in CancellationToken cancellationToken);


        /// <summary>
        /// This method is called when the <see cref="IHostedService"/> starts.
        /// The implementation should return a task that represents the start sequence of the service.
        /// The starting process will happen in synchronously as long as the implementation will continue on the calling task.
        /// </summary>
        /// <param name="cancellationToken">Indicates that the shutdown process should no longer be graceful.</param>
        /// <returns>A <see cref="Task"/> that represents the stopping sequence.</returns>
        protected abstract Task InnerStopAsync(in CancellationToken cancellationToken);

        #region IDisposable Pattern Support

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // IMPORTANT!! override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
        // ~HostedServiceBase()
        // {
        //     // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
        //     Dispose(disposing: false);
        // }

        protected virtual void Dispose(bool disposing)
        {
            if (!m_disposed)
            {
                if (disposing)
                {
                    if (IsRunning)
                        Logger?.LogWarning($"Dispose called while the service is running! Please stop the service before dispose it. Id: {Id}");

                    InnerManagedDispose();
                }

                InnerUnmanagedDispose();

                InnerNullifyReferencesDispose();

                m_disposed = true;
            }
        }

        protected virtual void InnerUnmanagedDispose()
        {
        }

        protected virtual void InnerManagedDispose()
        {
        }

        protected virtual void InnerNullifyReferencesDispose()
        {
        }

        #endregion
    }
}
