﻿using Google.Protobuf;
using Indoors.DomainIcd.Entities.Messages;
using Indoors.EntityFramework.Entities.Types;
using System;
using System.Linq;
using RouteStep = Indoors.EntityFramework.Entities.Types.RouteStep;

namespace Indoors.DomainIcd.Entities.Adapters
{
    public static class TypesAdapter
    {
        public static Header GetHeader(this IMessage message)
        {
            var header = new Header
            {
                Id = Guid.NewGuid().ToString(),
                SourceName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name,
                EntryName = System.Reflection.Assembly.GetEntryAssembly()?.GetName().Name ?? string.Empty
            };

            return header;
        }

        public static Type ToType(this TypeDescription message)
        {
            if (message == null)
                return null;
            var typeName = $"{message.Namespace}.{message.Name}, {message.Assembly}";
            var type = Type.GetType(typeName);
            return type;
        }

        public static TypeDescription ToMessage(this Type type)
        {
            if (type == null)
                return null;

            TypeDescription typeDescription = new()
            {
                Namespace = type.Namespace,
                Name = type.Name,
                Assembly = type.Assembly.FullName
            };
            return typeDescription;
        }

        public static GeoPoint3D ToType(this GeoPoint3DStruct message)
        {
            if (message == null)
                return null;
            var type = new GeoPoint3D(message.X, message.Y, message.Z);
            return type;
        }

        public static GeoPoint3DStruct ToMessage(this GeoPoint3D type)
        {
            if (type == null)
                return null;
            var (x, y, z) = type;
            var message = new GeoPoint3DStruct
            {
                X = x,
                Y = y,
                Z = z
            };
            return message;
        }

        public static Orientation ToType(this OrientationStruct message)
        {
            if (message == null)
                return null;
            var type = new Orientation(message.X, message.Y, message.Z, message.W);
            return type;
        }

        public static OrientationStruct ToMessage(this Orientation type)
        {
            if (type == null)
                return null;
            var (x, y, z, w) = type;
            var message = new OrientationStruct
            {
                X = x,
                Y = y,
                Z = z,
                W = w
            };
            return message;
        }

        public static RouteStep ToType(this RouteStepStruct message)
        {
            if (message == null)
                return null;
            var messageLocation = message.Location.ToType();
            var messageOrientation = message.Orientation.ToType();
            var type = new RouteStep(messageLocation, messageOrientation);
            return type;
        }


        public static RouteStepStruct ToMessage(this RouteStep type)
        {
            if (type == null)
                return null;

            var location = type.Location.ToMessage();
            var orientation = type.Orientation.ToMessage();
            var message = new RouteStepStruct
            {
                Location = location,
                Orientation = orientation
            };

            return message;
        }

        public static Route ToType(this RouteStruct message)
        {
            if (message == null)
                return null;
            var steps = message.Steps.Select(ToType).ToList();
            var type = new Route(steps);
            return type;
        }


        public static RouteStruct ToMessage(this Route type)
        {
            if (type == null)
                return null;
            var steps = type.Steps.Select(ToMessage).ToList();
            var message = new RouteStruct
            {
                Steps = { steps }
            };
            return message;
        }

        public static Frontier ToType(this FrontierStruct message)
        {
            if (message == null)
                return null;
            var points = message.Points.Select(ToType).ToList();
            var type = new Frontier(points);
            return type;
        }

        public static FrontierStruct ToMessage(this Frontier type)
        {
            if (type == null)
                return null;
            var points = type.Points.Select(ToMessage).ToList();
            var message = new FrontierStruct
            {
                Points = { points }
            };
            return message;
        }

        public static Pixel ToType(this PixelStruct message)
        {
            if (message == null)
                return null;

            var type = new Pixel(message.X, message.Y);
            return type;
        }

        public static PixelStruct ToMessage(this Pixel type)
        {
            if (type == null)
                return null;

            var (x, y) = type;
            var message = new PixelStruct
            {
                X = x,
                Y = y,
            };

            return message;
        }
    }
}
