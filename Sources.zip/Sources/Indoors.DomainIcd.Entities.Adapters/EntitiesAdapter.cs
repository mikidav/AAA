﻿using Indoors.DomainIcd.Entities.Messages;
using Indoors.EntityFramework.Entities;
using Indoors.EntityFramework.Entities.Base;
using System;
using Google.Protobuf.WellKnownTypes;

namespace Indoors.DomainIcd.Entities.Adapters
{
    public static class EntitiesAdapter
    {
        #region EntityId<Guid>

        public static string ToMessage(this EntityId<Guid> entityId)
        {
            return entityId?.ToString() ?? string.Empty;
        }

        public static EntityId<Guid> ToEntity(this string entityIdString)
        {
            var parsed = Guid.TryParse(entityIdString, out var guid);
            if(!parsed)
                guid = Guid.Empty;

            EntityId<Guid> entityId = guid;
            return entityId;
        }
        #endregion

        #region Base

        public static (Guid id, string version, string createdBy, DateTime createdTimeUtc, string updatedBy, DateTime updatedTimeUtc) ToBaseEntity(this EntityBaseStruct baseMessage)
        {
            var id = baseMessage.Id.ToEntity();
            var version = baseMessage.Version;
            var createdTimeUtc = baseMessage.CreatedTime?.ToDateTime() ?? default;
            var createdBy = baseMessage.CreatedBy;
            var updatedTimeUtc = baseMessage.UpdatedTime?.ToDateTime() ?? default;
            var updatedBy = baseMessage.UpdatedBy;
            return (id, version, createdBy, createdTimeUtc, updatedBy, updatedTimeUtc);
        }

        public static EntityBaseStruct ToBaseMessage(this IEntity entity)
        {
            var message = new EntityBaseStruct
            {
                Id = entity.Id.ToMessage(),
                Version = entity.Version,
                CreatedBy = entity.CreatedBy,
                CreatedTime = entity.CreatedTimeUtc.ToTimestamp(),
                UpdatedBy = entity.UpdatedBy,
                UpdatedTime = entity.UpdatedTimeUtc.ToTimestamp()
            };

            return message;
        }

        #endregion

        #region Ooi

        public static OoiStruct ToMessage(this Ooi entity)
        {
            if (entity == null)
                return null;
            
            var message = new OoiStruct
            {
                Base = entity.ToBaseMessage(),
                Type = entity.Type.ToMessageEnum(),
                Location = entity.Location.ToMessage(),
                Name = entity.Name
            };

            return message;
        }

        public static Ooi ToEntity(this OoiStruct message)
        {
            if (message == null)
                return null;
            
            var (id, version, createdBy, createdTimeUtc, updatedBy, updatedTimeUtc) = ToBaseEntity(message.Base);

            var entity = new Ooi(id, version, createdBy, createdTimeUtc)
            {
                UpdatedBy = updatedBy,
                UpdatedTimeUtc = updatedTimeUtc,
                Name = message.Name,
                Type = message.Type.ToEntityType(),
                Location = message.Location.ToType()
            };

            return entity;
        }

        #endregion

        #region PlatformStatus

        public static PlatformStatusStruct ToMessage(this PlatformStatus entity)
        {
            if (entity == null)
                return null;
            
            var message = new PlatformStatusStruct
            {
                Base = entity.ToBaseMessage(),
                
                Location = entity.Location.ToMessage(),
                Orientation = entity.Orientation.ToMessage(),
                State = entity.State.ToMessageEnum(),
                BatteryCapacity = entity.BatteryCapacity,
                NetworkSignalQuality = entity.NetworkSignalQuality,
                SensorQuality = entity.SensorQuality,


                VideoStreamEntityId = entity.VideoStreamEntityId.ToMessage(),
                NavigationEntityId = entity.NavigationEntityId.ToMessage()
            };

            return message;
        }

        public static PlatformStatus ToEntity(this PlatformStatusStruct message)
        {
            if (message == null)
                return null;
            
            var (id, version, createdBy, createdTimeUtc, updatedBy, updatedTimeUtc) = ToBaseEntity(message.Base);

            var entity = new PlatformStatus(id, version, createdBy, createdTimeUtc)
            {
                UpdatedBy = updatedBy,
                UpdatedTimeUtc = updatedTimeUtc,
                
                Location = message.Location.ToType(),
                Orientation = message.Orientation.ToType(),
                State = message.State.ToEntityType(),
                BatteryCapacity = message.BatteryCapacity,
                NetworkSignalQuality = message.NetworkSignalQuality,
                SensorQuality = message.SensorQuality,
                
                VideoStreamEntityId = message.VideoStreamEntityId.ToEntity(),
                NavigationEntityId = message.NavigationEntityId.ToEntity()
            };

            return entity;
        }
        #endregion

        #region VideoStreamStruct

        public static VideoStreamStruct ToMessage(this VideoStream entity)
        {
            if (entity == null)
                return null;
            
            var message = new VideoStreamStruct
            {
                Base = entity.ToBaseMessage(),
                EncodingFormat = entity.EncodingFormat ?? "JPEG",
                Width = entity.Width,
                Height = entity.Height
            };

            return message;
        }

        public static VideoStream ToEntity(this VideoStreamStruct message)
        {
            if (message == null)
                return null;
            
            var (id, version, createdBy, createdTimeUtc, updatedBy, updatedTimeUtc) = ToBaseEntity(message.Base);

            var entity = new VideoStream(id, version, createdBy, createdTimeUtc)
            {
                UpdatedBy = updatedBy,
                UpdatedTimeUtc = updatedTimeUtc,
                EncodingFormat = message.EncodingFormat,
                Width = message.Width,
                Height = message.Height
            };

            return entity;
        }
        #endregion

        #region NavigationStruct

        public static NavigationStruct ToMessage(this Navigation entity)
        {
            if (entity == null)
                return null;
            
            var message = new NavigationStruct
            {
                Base = entity.ToBaseMessage(),
                Route = entity.Route.ToMessage(),
                Frontier = entity.Frontier.ToMessage(),
            };

            return message;
        }

        public static Navigation ToEntity(this NavigationStruct message)
        {
            if (message == null)
                return null;
            
            var (id, version, createdBy, createdTimeUtc, updatedBy, updatedTimeUtc) = ToBaseEntity(message.Base);

            var entity = new Navigation(id, version, createdBy, createdTimeUtc)
            {
                UpdatedBy = updatedBy,
                UpdatedTimeUtc = updatedTimeUtc,
                Frontier = message.Frontier.ToType(),
                Route = message.Route.ToType(),
            };

            return entity;
        }
        #endregion
    }
}
