﻿using System;
using EntityMessageEnums = Indoors.EntityFramework.Common.Data;
using EntityEnums = Indoors.EntityFramework.Entities.Enums;
using MessageEnums = Indoors.DomainIcd.Entities.Messages;

namespace Indoors.DomainIcd.Entities.Adapters
{
    public static class EntitiesEnumsAdapter
    {
        public static EntityMessageEnums.NotificationTypeEnum ToEntityType(this MessageEnums.NotificationTypeEnum notificationType)
        {
            return notificationType switch
            {
                MessageEnums.NotificationTypeEnum.Added => EntityMessageEnums.NotificationTypeEnum.Added,
                MessageEnums.NotificationTypeEnum.Updated => EntityMessageEnums.NotificationTypeEnum.Updated,
                MessageEnums.NotificationTypeEnum.Deleted => EntityMessageEnums.NotificationTypeEnum.Deleted,
                _ => throw new ArgumentOutOfRangeException(nameof(notificationType), notificationType, null)
            };
        }

        public static MessageEnums.NotificationTypeEnum ToMessageEnum(this EntityMessageEnums.NotificationTypeEnum type)
        {
            return type switch
            {
                EntityMessageEnums.NotificationTypeEnum.Added => MessageEnums.NotificationTypeEnum.Added,
                EntityMessageEnums.NotificationTypeEnum.Updated => MessageEnums.NotificationTypeEnum.Updated,
                EntityMessageEnums.NotificationTypeEnum.Deleted => MessageEnums.NotificationTypeEnum.Deleted,
                _ => throw new ArgumentOutOfRangeException(nameof(type), type, null)
            };
        }

        public static EntityEnums.OoiTypeEnum ToEntityType(this MessageEnums.OoiTypeEnum message)
        {
            return message switch
            {
                MessageEnums.OoiTypeEnum.People => EntityEnums.OoiTypeEnum.People,
                MessageEnums.OoiTypeEnum.Weapons => EntityEnums.OoiTypeEnum.Weapons,
                MessageEnums.OoiTypeEnum.Furniture => EntityEnums.OoiTypeEnum.Furniture,
                MessageEnums.OoiTypeEnum.Platform => EntityEnums.OoiTypeEnum.Platform,
                _ => throw new ArgumentOutOfRangeException(nameof(message), message, null)
            };
        }

        public static MessageEnums.OoiTypeEnum ToMessageEnum(this EntityEnums.OoiTypeEnum type)
        {
            return type switch
            {
                EntityEnums.OoiTypeEnum.People => MessageEnums.OoiTypeEnum.People,
                EntityEnums.OoiTypeEnum.Weapons => MessageEnums.OoiTypeEnum.Weapons,
                EntityEnums.OoiTypeEnum.Furniture => MessageEnums.OoiTypeEnum.Furniture,
                EntityEnums.OoiTypeEnum.Platform => MessageEnums.OoiTypeEnum.Platform,
                _ => throw new ArgumentOutOfRangeException(nameof(type), type, null)
            };
        }

        public static EntityEnums.PlatformStateEnum ToEntityType(this MessageEnums.PlatformStateEnum message)
        {
            return message switch
            {
                MessageEnums.PlatformStateEnum.Unknown => EntityEnums.PlatformStateEnum.Unknown,
                MessageEnums.PlatformStateEnum.Unrecognized => EntityEnums.PlatformStateEnum.Unrecognized,
                MessageEnums.PlatformStateEnum.Disarmed => EntityEnums.PlatformStateEnum.Disarmed,
                MessageEnums.PlatformStateEnum.InGround => EntityEnums.PlatformStateEnum.InGround,
                MessageEnums.PlatformStateEnum.TakingOff => EntityEnums.PlatformStateEnum.TakingOff,
                MessageEnums.PlatformStateEnum.HoldingPosition => EntityEnums.PlatformStateEnum.HoldingPosition,
                MessageEnums.PlatformStateEnum.Exploring => EntityEnums.PlatformStateEnum.Exploring,
                MessageEnums.PlatformStateEnum.Manual => EntityEnums.PlatformStateEnum.Manual,
                MessageEnums.PlatformStateEnum.GoToNode => EntityEnums.PlatformStateEnum.GoToNode,
                MessageEnums.PlatformStateEnum.Landing => EntityEnums.PlatformStateEnum.Landing,
                MessageEnums.PlatformStateEnum.Fail => EntityEnums.PlatformStateEnum.Fail,
                _ => throw new ArgumentOutOfRangeException(nameof(message), message, null)
            };
        }

        public static MessageEnums.PlatformStateEnum ToMessageEnum(this EntityEnums.PlatformStateEnum type)
        {
            return type switch
            {
                EntityEnums.PlatformStateEnum.Unknown => MessageEnums.PlatformStateEnum.Unknown,
                EntityEnums.PlatformStateEnum.Unrecognized => MessageEnums.PlatformStateEnum.Unrecognized,
                EntityEnums.PlatformStateEnum.Disarmed => MessageEnums.PlatformStateEnum.Disarmed,
                EntityEnums.PlatformStateEnum.InGround => MessageEnums.PlatformStateEnum.InGround,
                EntityEnums.PlatformStateEnum.TakingOff => MessageEnums.PlatformStateEnum.TakingOff,
                EntityEnums.PlatformStateEnum.HoldingPosition => MessageEnums.PlatformStateEnum.HoldingPosition,
                EntityEnums.PlatformStateEnum.Exploring => MessageEnums.PlatformStateEnum.Exploring,
                EntityEnums.PlatformStateEnum.Manual => MessageEnums.PlatformStateEnum.Manual,
                EntityEnums.PlatformStateEnum.GoToNode => MessageEnums.PlatformStateEnum.GoToNode,
                EntityEnums.PlatformStateEnum.Landing => MessageEnums.PlatformStateEnum.Landing,
                EntityEnums.PlatformStateEnum.Fail => MessageEnums.PlatformStateEnum.Fail,
                _ => throw new ArgumentOutOfRangeException(nameof(type), type, null)
            };
        }
    }
}
