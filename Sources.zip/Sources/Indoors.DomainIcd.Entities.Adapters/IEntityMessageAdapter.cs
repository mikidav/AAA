﻿using Indoors.EntityFramework.Entities.Base;

namespace Indoors.DomainIcd.Entities.Adapters
{
    public interface IEntityMessageAdapter<TEntity, TEntityMessage>
        where TEntity : class, IEntity
        where TEntityMessage : class
    {
        TEntityMessage ToMessage(TEntity entity);
        TEntity ToEntity(TEntityMessage message);
    }
}