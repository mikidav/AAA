﻿namespace Indoors.Commands.Common
{
    public class CommandConfig<TCommandParameters> : CommandConfig, ICommandConfig<TCommandParameters>
    {
    }

    public class CommandConfig : ICommandConfig
    {
        public bool DisableExecutionLog { get; set; }
    }
}