﻿using System;
using Indoors.Commands.Common.Types;

namespace Indoors.Commands.Common
{
    public interface ICommand<TCommandParameter>
    {
        //ONLY for debug propose!!! Set can execute result from outside.
        bool? ForceCanExecute { get; set; }

        // TODO Miki - removed it because command supposed be stateless
        /// <summary>
        /// Raised when the execution conditions changed.
        /// </summary>
        IObservable<bool> CanExecuteChanged { get; }

        /// <summary>
        /// Raised after <see cref="CanExecute"/> is called and finished checking the execution conditions.
        /// </summary>
        IObservable<ICommandCanExecuteResult<TCommandParameter>> CanExecuteChecked { get; }

        /// <summary>
        /// Raised after <see cref="Execute(TCommandParameter)"/> or <see cref="Execute(string,TCommandParameter)"/> is called and finished.
        /// Note that for async, remote or proxy commands, this might not mean that the command execution is finished,
        /// but only that the command has been dispatched.
        /// </summary>
        IObservable<ICommandExecuteResult<TCommandParameter>> CommandExecuted { get; }

        /// <summary>Defines the method that determines whether the command can execute in its current state.</summary>
        /// <returns>true if this command can be executed; otherwise, false.</returns>
        bool CanExecute(TCommandParameter parameter = default(TCommandParameter));

        /// <summary>Defines the method to be called when the command is invoked.</summary>
        string Execute(TCommandParameter parameter = default(TCommandParameter));

        /// <summary>Defines the method to be called when the command is invoked.</summary>
        void Execute(string id, TCommandParameter parameter = default(TCommandParameter));
    }
}
