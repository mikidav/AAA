﻿using System;
using System.Reactive.Subjects;
using Indoors.Commands.Common.Types;
using Microsoft.Extensions.Logging;

namespace Indoors.Commands.Common
{
    public abstract class CommandBase<TCommandParameter> : ICommand<TCommandParameter>
    {
        private readonly ISubject<ICommandCanExecuteResult<TCommandParameter>> m_canExecuteChecked =
            new Subject<ICommandCanExecuteResult<TCommandParameter>>();

        private readonly ISubject<ICommandExecuteResult<TCommandParameter>> m_commandExecuted =
            new Subject<ICommandExecuteResult<TCommandParameter>>();

        private readonly ISubject<bool> m_canExecuteChanged = new Subject<bool>();

        private bool? m_forceCanExecute;

        protected ILogger Logger { get; }

        public bool DisableExecutionLog { get; }

        public Type InstanceType { get; }
        public Type ParameterType { get; }
        public string TypesDescriptionString => $"{nameof(InstanceType)}: {InstanceType}, {nameof(ParameterType)}: {ParameterType}";

        public bool? ForceCanExecute
        {
            get => m_forceCanExecute;
            set
            {
                m_forceCanExecute = value;

                if (value.HasValue)
                    RaiseCommandCanExecuteChanged(value.Value);
            }
        }

        public IObservable<bool> CanExecuteChanged => m_canExecuteChanged;
        public IObservable<ICommandCanExecuteResult<TCommandParameter>> CanExecuteChecked => m_canExecuteChecked;
        public IObservable<ICommandExecuteResult<TCommandParameter>> CommandExecuted => m_commandExecuted;

        protected CommandBase(ICommandConfig<TCommandParameter> commandConfig, ILogger logger = null) 
            : this(commandConfig.DisableExecutionLog, logger)
        {
        }

        protected CommandBase(ICommandConfig commandConfig, ILogger logger = null)
            : this(commandConfig.DisableExecutionLog, logger)
        {
        }

        protected CommandBase(bool disableExecutionLog = true, ILogger logger = null)
        {
            DisableExecutionLog = disableExecutionLog;

            InstanceType = GetType();
            ParameterType = typeof(TCommandParameter);

            Logger = logger;
        }

        public virtual bool CanExecute(TCommandParameter parameter = default)
        {
            if (ForceCanExecute.HasValue)
                return ForceCanExecute.Value;

            var canExecute = InternalCanExecute(parameter);
            RaiseCanExecuteChecked(parameter, canExecute);

            return canExecute;
        }

        public virtual string Execute(TCommandParameter parameter = default)
        {
            var operationId = Guid.NewGuid().ToString();

            Execute(operationId, parameter);

            return operationId;
        }

        public virtual void Execute(string id, TCommandParameter parameter = default)
        {
            if (string.IsNullOrWhiteSpace(id))
                throw new ArgumentNullException(nameof(id));

            if (!DisableExecutionLog)
                Logger.LogInformation($"Command Executing. Id: {id}, ParameterValue: {(parameter != null ? parameter.ToString() : "Null")}, {TypesDescriptionString}");

            try
            {
                InternalExecute(id, parameter);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to execute command! Id: {id}, ParameterValue: {(parameter != null ? parameter.ToString() : "Null")}, {TypesDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }
            
            RaiseCommandExecuted(id, parameter);
        }

        protected abstract void InternalExecute(string id, TCommandParameter parameter = default);

        protected abstract bool InternalCanExecute(TCommandParameter parameter = default);

        protected virtual void RaiseCanExecuteChecked(TCommandParameter parameter, bool canExecute)
        {
            var result = new CommandCanExecuteResult<TCommandParameter>(canExecute, parameter);
            m_canExecuteChecked.OnNext(result);
        }

        protected virtual void RaiseCommandExecuted(string id, TCommandParameter parameter)
        {
            if (!DisableExecutionLog)
                Logger?.LogInformation($"Command Execution Finished. Id: {id}, ParameterValue: {(parameter != null ? parameter.ToString() : "Null")}, {TypesDescriptionString}");

            var result = new CommandExecuteResult<TCommandParameter>(id, parameter);
            m_commandExecuted.OnNext(result);
        }

        protected virtual void RaiseCommandCanExecuteChanged(bool parameter)
        {
            if (!DisableExecutionLog)
                Logger?.LogInformation($"Command Execution Condition Changed. Execution: {parameter}, {TypesDescriptionString}");

            m_canExecuteChanged.OnNext(parameter);
        }
    }
}