﻿namespace Indoors.Commands.Common
{
    public interface ICommandConfig<TCommandParameters> : ICommandConfig
    {

    }

    public interface ICommandConfig
    {
        bool DisableExecutionLog { get; set; }
    }
}