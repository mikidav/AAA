﻿using System;
using System.Reactive.Subjects;
using Indoors.Commands.Common.Types;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Commands.Common
{
    public abstract class CommandProxyBase<TCommandParameter> : ServiceBase, ICommand<TCommandParameter>
    {
        private readonly ISubject<ICommandCanExecuteResult<TCommandParameter>> m_canExecuteChecked =
            new Subject<ICommandCanExecuteResult<TCommandParameter>>();

        private readonly ISubject<ICommandExecuteResult<TCommandParameter>> m_commandExecuted
            = new Subject<ICommandExecuteResult<TCommandParameter>>();

        private readonly ISubject<bool> m_canExecuteChanged = new Subject<bool>();

        private bool? m_forceCanExecute;

        public bool DisableExecutionLog { get; }

        public Type InstanceType { get; }
        public Type ParameterType { get; }
        public string TypesDescriptionString => $"{nameof(InstanceType)}: {InstanceType}, {nameof(ParameterType)}: {ParameterType}";

        public virtual bool? ForceCanExecute
        {
            get => m_forceCanExecute;
            set
            {
                m_forceCanExecute = value;

                if (value.HasValue)
                    RaiseCommandCanExecuteChanged(value.Value);
            }
        }

        public IObservable<bool> CanExecuteChanged => m_canExecuteChanged;
        public IObservable<ICommandCanExecuteResult<TCommandParameter>> CanExecuteChecked => m_canExecuteChecked;
        public IObservable<ICommandExecuteResult<TCommandParameter>> CommandExecuted => m_commandExecuted;

        protected CommandProxyBase(ICommandConfig<TCommandParameter> commandConfig, ILogger logger = null, string id = null)
            : this(commandConfig.DisableExecutionLog, logger, id)
        {
        }

        protected CommandProxyBase(ICommandConfig commandConfig, ILogger logger = null, string id = null)
            : this(commandConfig.DisableExecutionLog, logger, id)
        {
        }

        protected CommandProxyBase(bool disableExecutionLog = true, ILogger logger = null, string id = null) : base(logger, id)
        {
            DisableExecutionLog = disableExecutionLog;

            InstanceType = GetType();
            ParameterType = typeof(TCommandParameter);
        }

        public virtual bool CanExecute(TCommandParameter parameter = default)
        {
            if (ForceCanExecute.HasValue)
                return ForceCanExecute.Value;

            var canExecute = false;

            if (IsRunning)
            {
                if (!DisableExecutionLog)
                {
                    var error = $"Command Proxy CanExecute Failed. The Command Proxy Service Is Not Running! {TypesDescriptionString}, ParameterValue: {(parameter != null ? parameter.ToString() : "Null")}, {ServiceDescriptionString}";
                    Logger.LogWarning(error);
                }
            }
            else
            {
                canExecute = InternalCanExecute(parameter);
            }

            RaiseCanExecuteChecked(canExecute, parameter);

            return canExecute;
        }

        public virtual string Execute(TCommandParameter parameter = default)
        {
            var operationId = Guid.NewGuid().ToString();

            Execute(operationId, parameter);

            return operationId;
        }

        public virtual void Execute(string id, TCommandParameter parameter = default)
        {
            ValidateIsRunning();

            if (string.IsNullOrWhiteSpace(id))
                throw new ArgumentNullException(nameof(id));

            if (!DisableExecutionLog)
                Logger.LogInformation($"Command Proxy Executing. {TypesDescriptionString}, ParameterValue: {(parameter != null ? parameter.ToString() : "Null")}, {ServiceDescriptionString}");

            try
            {
                InternalExecute(id, parameter);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to execute command! {TypesDescriptionString}, ParameterValue: {(parameter != null ? parameter.ToString() : "Null")}, {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }

            RaiseCommandExecuted(id, parameter);
        }

        protected abstract void InternalExecute(string id, TCommandParameter parameter = default);

        protected abstract bool InternalCanExecute(TCommandParameter parameter = default);

        protected virtual void RaiseCanExecuteChecked(bool canExecute, TCommandParameter parameter)
        {
            var result = new CommandCanExecuteResult<TCommandParameter>(canExecute, parameter);
            m_canExecuteChecked.OnNext(result);
        }

        protected virtual void RaiseCommandExecuted(string id, TCommandParameter parameter)
        {
            if (!DisableExecutionLog)
                Logger.LogInformation($"Command Proxy Execution Finished. {TypesDescriptionString}, {ServiceDescriptionString}");

            var result = new CommandExecuteResult<TCommandParameter>(id, parameter);
            m_commandExecuted.OnNext(result);
        }

        protected virtual void RaiseCommandCanExecuteChanged(bool parameter)
        {
            if (!DisableExecutionLog)
                Logger.LogInformation($"Command Execution Condition Changed. Execution: {parameter}, {TypesDescriptionString}, {ServiceDescriptionString}");

            m_canExecuteChanged.OnNext(parameter);
        }
    }
}