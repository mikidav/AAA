﻿namespace Indoors.Commands.Common.Types
{
    public class CommandExecuteResult<TCommandParameter> : ICommandExecuteResult<TCommandParameter>
    {
        public string OperationId { get; set; }
        public TCommandParameter CommandParameter { get; set; }

        public CommandExecuteResult()
        {

        }

        public CommandExecuteResult(string operationId, TCommandParameter commandParameter)
        {
            OperationId = operationId;
            CommandParameter = commandParameter;
        }
    }
}