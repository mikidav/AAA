﻿namespace Indoors.Commands.Common.Types
{
    public class CommandCanExecuteResult<TCommandParameter> : ICommandCanExecuteResult<TCommandParameter>
    {
        public bool CanExecute { get; set; }
        public TCommandParameter CommandParameter { get; set; }

        public CommandCanExecuteResult()
        {

        }

        public CommandCanExecuteResult(bool canExecute, TCommandParameter commandParameter)
        {
            CanExecute = canExecute;
            CommandParameter = commandParameter;
        }
    }
}