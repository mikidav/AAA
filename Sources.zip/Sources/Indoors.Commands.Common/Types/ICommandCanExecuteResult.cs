﻿namespace Indoors.Commands.Common.Types
{
    public interface ICommandCanExecuteResult<out TCommandParameter>
    {
        bool CanExecute { get; }
        TCommandParameter CommandParameter { get; }
    }
}