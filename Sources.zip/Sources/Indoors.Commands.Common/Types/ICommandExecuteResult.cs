﻿namespace Indoors.Commands.Common.Types
{
    public interface ICommandExecuteResult<out TCommandParameter>
    {
        string OperationId { get; }
        TCommandParameter CommandParameter { get; }
    }
}