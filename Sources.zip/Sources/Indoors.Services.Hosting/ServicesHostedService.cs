﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Services.Hosting
{
    public class ServicesHostedService : Indoors.Hosting.Common.HostedServiceBase
    {
        public IList<IService> Services { get; }

        public ServicesHostedService(IEnumerable<IService> services,
            ILogger logger = null,
            string id = null)
            : base(logger, id)
        {
            Services = services?.ToList() ?? Enumerable.Empty<IService>().ToList();
        }

        protected override Task InnerStartAsync(in CancellationToken cancellationToken)
        {
            var localCancellationToken = cancellationToken;
            return Task.Run(() =>
            {
                foreach (var service in Services)
                {
                    localCancellationToken.ThrowIfCancellationRequested();
                    service.Initialize();
                }

                foreach (var service in Services)
                {
                    localCancellationToken.ThrowIfCancellationRequested();
                    service.Start();
                }
            }, cancellationToken);
        }

        protected override Task InnerStopAsync(in CancellationToken cancellationToken)
        {
            // To perform a healthy stop process it will be performed synchronously

            foreach (var service in Services)
            {
                cancellationToken.ThrowIfCancellationRequested();
                service.Stop();
            }

            foreach (var service in Services)
            {
                cancellationToken.ThrowIfCancellationRequested();
                service.TryDisposeService();
            }

            return Task.CompletedTask;
        }
    }

    public class ServicesHostedService<TService> : ServicesHostedService where TService : IService
    {
        public ServicesHostedService(IEnumerable<TService> services,
            ILogger<ServicesHostedService<TService>> logger = null,
            string id = null)
            : base(services.WhereService(), logger, id)
        {
        }
    }
}