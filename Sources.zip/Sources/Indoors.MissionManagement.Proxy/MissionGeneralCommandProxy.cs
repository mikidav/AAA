﻿using Indoors.Commands.Common;
using Indoors.Communications.Common.Publishers;
using Indoors.MissionManagement.Adapters.Commands;
using Indoors.MissionManagement.Common.CommandParameters;
using Indoors.MissionManagement.Common.Commands;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.MissionManagement.Proxy
{
    public class MissionGeneralCommandProxy<TCommandParameter, TCommandDomainMessage> : CommandProxyBase<TCommandParameter>,
        IMissionCommandProxy,
        IMissionGeneralCommand<TCommandParameter> 
        where TCommandParameter : IMissionCommandParameters 
        where TCommandDomainMessage : class
    {
        public ITypedObjectPublisher<TCommandDomainMessage> Publisher { get; private set; }
        public IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage> MessageAdapter { get; private set; }

        public MissionGeneralCommandProxy(ITypedObjectPublisher<TCommandDomainMessage> publisher,
            IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage> messageAdapter,
            ICommandConfig<TCommandParameter> commandConfig,
            ILogger<MissionGeneralCommandProxy<TCommandParameter, TCommandDomainMessage>> logger = null,
            string id = null)
            : base(commandConfig, logger, id)
        {
            Publisher = publisher;
            MessageAdapter = messageAdapter;
        }

        public MissionGeneralCommandProxy(ITypedObjectPublisher<TCommandDomainMessage> publisher,
            IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage> messageAdapter,
            ICommandConfig commandConfig,
            ILogger<MissionGeneralCommandProxy<TCommandParameter, TCommandDomainMessage>> logger = null,
            string id = null)
            : base(commandConfig, logger, id)
        {
            Publisher = publisher;
            MessageAdapter = messageAdapter;
        }

        public MissionGeneralCommandProxy(ITypedObjectPublisher<TCommandDomainMessage> publisher,
            IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage> messageAdapter,
            bool disableExecutionLog = true,
            ILogger<MissionGeneralCommandProxy<TCommandParameter, TCommandDomainMessage>> logger = null,
            string id = null)
            : base(disableExecutionLog, logger, id)
        {
            Publisher = publisher;
            MessageAdapter = messageAdapter;
        }

        protected override void InternalInitialize()
        {
            Publisher.Initialize();
        }

        protected override void InternalStart()
        {
            Publisher.Start();
        }

        protected override void InternalStop()
        {
            Publisher?.Stop();
        }

        protected override void InternalExecute(string id, TCommandParameter parameter = default)
        {
            var message = MessageAdapter.ToMessage(id, parameter);
            Publisher.Publish(message);
        }

        protected override bool InternalCanExecute(TCommandParameter parameter = default)
        {
            var isProxyRunning = IsRunning;
            var isPublisherRunning = Publisher?.IsRunning == true;
            var canExecute = isProxyRunning && isPublisherRunning;

            return canExecute;
        }

        protected override void InnerManagedDispose()
        {
            Publisher?.TryDisposeService();
            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Publisher = null;
            MessageAdapter = null;
            base.InnerNullifyReferencesDispose();
        }
    }
}
