﻿using Autofac;
using Indoors.Commands.Common;
using Indoors.Communications.RabbitMQ.DI.Autofac;
using Indoors.DomainIcd.Mission;
using Indoors.DomainIcd.Mission.Messages;
using Indoors.MissionManagement.Adapters.Commands;
using Indoors.MissionManagement.Common;
using Indoors.MissionManagement.Common.CommandParameters;
using Indoors.MissionManagement.Common.Commands;
using Indoors.Serializations.Protobuf.DI.Autofac;
using Indoors.Services.Hosting;
using Microsoft.Extensions.Hosting;

namespace Indoors.MissionManagement.Proxy.Container
{
    public class MissionGatewayProxyModuleInstaller : Module
    {
        public bool RegisterHostedService { get; }

        public MissionGatewayProxyModuleInstaller(bool registerHostedService = true)
        {
            RegisterHostedService = registerHostedService;
        }

        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterFileDescriptorProvider<MissionDomainIcdDescriptorProvider>();
            
            RegisterMissionGeneralCommandProxy<MissionStartCommandParameters, MissionStartCommandMessage, MissionDomainIcdStartCommandAdapter>(builder);
            RegisterMissionGeneralCommandProxy<MissionStopCommandParameters, MissionStopCommandMessage, MissionDomainIcdStopCommandAdapter>(builder);
            RegisterMissionGeneralCommandProxy<MissionLandCommandParameters, MissionLandCommandMessage, MissionDomainIcdLandCommandAdapter>(builder);
            RegisterMissionGeneralCommandProxy<MissionTakeOffCommandParameters, MissionTakeOffCommandMessage, MissionDomainIcdTakeOffCommandAdapter>(builder);
            
            builder.RegisterType<MissionFacade>()
                .AsSelf()
                .As<IMissionFacade>()
                .SingleInstance();

            if (RegisterHostedService)
            {
                builder.RegisterType<ServicesHostedService<IMissionCommandProxy>>()
                    .As<IHostedService>()
                    .WithParameter(new NamedParameter("id", "MissionCommandProxyHost"));
            }
        }

        private static void RegisterMissionGeneralCommandProxy
            <TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter>(ContainerBuilder builder)
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IMissionCommandParameters
        {
            RegisterMissionCommandProxy
            <MissionGeneralCommandProxy<TCommandParameter, TCommandDomainMessage>,
                TCommandParameter,
                TCommandDomainMessage,
                TDomainMessageAdapter>(builder);
        }

        private static void RegisterMissionCommandProxy
            <TCommand, TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter>(ContainerBuilder container)
            where TCommand : class, IMissionGeneralCommand<TCommandParameter>, IMissionCommandProxy
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IMissionCommandParameters
        {
            RegisterCommandProxy
            <IMissionGeneralCommand<TCommandParameter>,
                TCommand,
                TCommandParameter,
                TCommandDomainMessage,
                TDomainMessageAdapter>(container);
        }

        private static void RegisterCommandProxy
        <TCommandInterface, TCommand, TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter>(ContainerBuilder builder)
            where TCommandInterface : ICommand<TCommandParameter>
            where TCommand : class, TCommandInterface, IMissionCommandProxy
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IMissionCommandParameters
        {
            builder.RegisterType<TCommand>()
                .AsSelf()
                .As<TCommandInterface, IMissionCommandProxy>()
                .SingleInstance();

            builder.RegisterRabbitMqPublisher<TCommandDomainMessage>();

            builder.RegisterType<TDomainMessageAdapter>()
                .AsSelf()
                .As<IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>>()
                .SingleInstance();
        }
    }
}