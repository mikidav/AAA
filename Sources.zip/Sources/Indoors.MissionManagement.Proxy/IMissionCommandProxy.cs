﻿using Indoors.Services.Common;

namespace Indoors.MissionManagement.Proxy
{
    public interface IMissionCommandProxy : IService
    {

    }
}