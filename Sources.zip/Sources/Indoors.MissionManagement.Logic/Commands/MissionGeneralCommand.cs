﻿using System;
using System.Reactive.Subjects;
using Indoors.Commands.Common;
using Indoors.MissionManagement.Common.CommandParameters;
using Indoors.MissionManagement.Common.Commands;
using Indoors.MissionManagement.Common.IFC;
using Microsoft.Extensions.Logging;

namespace Indoors.MissionManagement.Logic.Commands
{
    public class MissionGeneralCommand<TCommandParameters> : CommandBase<TCommandParameters>,
        IMissionGeneralCommand<TCommandParameters>, ICommandEventAggregator
        where TCommandParameters : IMissionCommandParameters
    {
        private const bool DefaultDisableExecutionLog = false;
        private readonly ISubject<IMissionCommandParameters> _commandSubject = new Subject<IMissionCommandParameters>();
        
        public IObservable<IMissionCommandParameters> CommandArrivedObservable => _commandSubject;

        public MissionGeneralCommand(ICommandConfig<TCommandParameters> commandConfig,
            ILogger<MissionGeneralCommand<TCommandParameters>> logger = null)
            : this(commandConfig?.DisableExecutionLog ?? DefaultDisableExecutionLog, logger)
        {
        }

        public MissionGeneralCommand(ICommandConfig commandConfig,
            ILogger<MissionGeneralCommand<TCommandParameters>> logger = null)
            : this(commandConfig?.DisableExecutionLog ?? DefaultDisableExecutionLog, logger)
        {
        }

        public MissionGeneralCommand(bool disableExecutionLog = DefaultDisableExecutionLog,
            ILogger<MissionGeneralCommand<TCommandParameters>> logger = null)
            : base(disableExecutionLog, logger)
        {
        }

        protected override void InternalExecute(string id, TCommandParameters parameter = default)
        {
            _commandSubject.OnNext(parameter);
        }

        protected override bool InternalCanExecute(TCommandParameters parameter = default)
        {
            return true;
        }

    }
}