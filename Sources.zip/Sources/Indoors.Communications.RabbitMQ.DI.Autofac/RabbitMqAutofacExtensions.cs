﻿using Autofac;
using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Repliers;
using Indoors.Communications.Common.Requesters;
using Indoors.Communications.Common.Subscribers;
using Indoors.Communications.RabbitMQ.Publish;
using Indoors.Communications.RabbitMQ.Reply;
using Indoors.Communications.RabbitMQ.Request;
using Indoors.Communications.RabbitMQ.Subscribe;

namespace Indoors.Communications.RabbitMQ.DI.Autofac
{
    public static class RabbitMqAutofacExtensions
    {
        public static string RegisterRabbitMqPublisher<TPublisher>(this ContainerBuilder builder, string name = null) where TPublisher : class
        {
            var serviceName = name ?? typeof(TypedPublisher<TPublisher>).Name;
            builder.RegisterType<TypedPublisher<TPublisher>>()
                .As<ITypedObjectPublisher<TPublisher>, TypedPublisher<TPublisher>>()
                .Named<TypedPublisher<TPublisher>>(serviceName)
                .Named<ITypedObjectPublisher<TPublisher>>(serviceName)
                .IfNotRegistered(typeof(ITypedObjectPublisher<TPublisher>))
                .SingleInstance();
            return serviceName;
        }

        public static string RegisterRabbitMqSubscriber<TSubscriber>(this ContainerBuilder builder, string name = null) where TSubscriber : class
        {
            var serviceName = name ?? typeof(TypedSubscriber<TSubscriber>).Name;
            builder.RegisterType<TypedSubscriber<TSubscriber>>()
                .As<ITypedObjectSubscriber<TSubscriber>, TypedSubscriber<TSubscriber>>()
                .Named<TypedSubscriber<TSubscriber>>(serviceName)
                .Named<ITypedObjectSubscriber<TSubscriber>>(serviceName)
                .IfNotRegistered(typeof(ITypedObjectSubscriber<TSubscriber>))
                .SingleInstance();
            return serviceName;
        }

        public static string RegisterRabbitMqRequester<TRequest, TRespond>(this ContainerBuilder builder, string name = null)
            where TRequest : class
            where TRespond : class
        {
            var serviceName = name ?? typeof(TypedRequester<TRequest, TRespond>).Name;
            builder.RegisterType<TypedRequester<TRequest, TRespond>>()
                .As<ITypedObjectRequester<TRequest, TRespond>, TypedRequester<TRequest, TRespond>>()
                .Named<TypedRequester<TRequest, TRespond>>(serviceName)
                .Named<ITypedObjectRequester<TRequest, TRespond>>(serviceName)
                .IfNotRegistered(typeof(ITypedObjectRequester<TRequest, TRespond>))
                .SingleInstance();
            return serviceName;
        }

        public static string RegisterRabbitMqReplier<TRequest, TRespond>(this ContainerBuilder builder, string name = null)
            where TRequest : class
            where TRespond : class
        {
            var serviceName = name ?? typeof(TypedReplier<TRequest, TRespond>).Name;
            builder.RegisterType<TypedReplier<TRequest, TRespond>>()
                .As<ITypedObjectReplier<TRequest, TRespond>, TypedReplier<TRequest, TRespond>>()
                .Named<TypedReplier<TRequest, TRespond>>(serviceName)
                .Named<ITypedObjectReplier<TRequest, TRespond>>(serviceName)
                .IfNotRegistered(typeof(ITypedObjectReplier<TRequest, TRespond>))
                .SingleInstance();
            return serviceName;
        }
    }
}