﻿using Autofac;
using Indoors.Communications.RabbitMQ.Configuration;
using Indoors.Communications.RabbitMQ.Connection;
using Indoors.Communications.RabbitMQ.Logger;
using Indoors.Communications.RabbitMQ.Serializer;
using Indoors.Utilities;

namespace Indoors.Communications.RabbitMQ.DI.Autofac
{
    /// <summary>
    /// A Autofac container installer that registers RabbitMQ communication.
    /// </summary>
    public class RabbitMqModuleInstaller : Module
    {
        public string ConfigurationsJsonPath { get; }

        public RabbitMqModuleInstaller(string configurationsJsonPath = null)
        {
            ConfigurationsJsonPath = configurationsJsonPath;
        }

        /// <summary>
        /// Register logic services and interfaces into the supplied container.
        /// </summary>
        /// <param name="builder">The container to hold the services.</param>
        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            if (!string.IsNullOrWhiteSpace(ConfigurationsJsonPath))
                builder.RegisterJsonConfigurations(ConfigurationsJsonPath);

            builder.RegisterType<EasyNetQSerializer>()
                .As<IEasyNetQSerializer>()
                .Named<EasyNetQSerializer>(nameof(EasyNetQSerializer))
                .SingleInstance();

            builder.RegisterType<EasyNetQLogger>()
                .As<IEasyNetQLogger>()
                .Named<EasyNetQLogger>(nameof(EasyNetQLogger))
                .SingleInstance();

            builder.RegisterType<RabbitMqConnection>()
                .As<IRabbitMqConnectionService, IRabbitMqConnection, IRabbitMqConnectionStateProvider>()
                .Named<RabbitMqConnection>(nameof(RabbitMqConnection))
                .SingleInstance();

            builder.RegisterType<PublisherConfiguration>()
                .As<IPublisherConfiguration>()
                .IfNotRegistered(typeof(IPublisherConfiguration))
                .SingleInstance();

            builder.RegisterType<SubscriberConfiguration>()
                .As<ISubscriberConfiguration>()
                .IfNotRegistered(typeof(ISubscriberConfiguration))
                .SingleInstance();

            builder.RegisterType<RequesterConfiguration>()
                .As<IRequesterConfiguration>()
                .IfNotRegistered(typeof(IRequesterConfiguration))
                .SingleInstance();

            builder.RegisterType<ReplierConfiguration>()
                .As<IReplierConfiguration>()
                .IfNotRegistered(typeof(IReplierConfiguration))
                .SingleInstance();
        }
    }
}
