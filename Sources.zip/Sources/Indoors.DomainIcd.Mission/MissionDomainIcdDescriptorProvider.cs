﻿using System.Collections.Generic;
using Google.Protobuf.Reflection;
using Indoors.DomainIcd.Mission.Messages;
using Indoors.Serializations.Protobuf;

namespace Indoors.DomainIcd.Mission
{
    public class MissionDomainIcdDescriptorProvider : IFileDescriptorProvider
    {
        public IEnumerable<FileDescriptor> Descriptors => new[] { MissionMessagesReflection.Descriptor };
    }
}