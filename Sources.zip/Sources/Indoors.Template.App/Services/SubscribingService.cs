﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Disposables;
using Indoors.Communications.Common.Subscribers;
using Indoors.Services.Common;
using Indoors.Template.App.Messages;
using Microsoft.Extensions.Logging;

namespace Indoors.Template.App.Services
{
    public class SubscribingService : ServiceBase, ISubscribingService
    {
        private IDisposable m_subscriptionDisposable;
        public IList<ITypedObjectSubscriber<NotificationMessage>> Subscribers { get; private set; }

        public SubscribingService(IEnumerable<ITypedObjectSubscriber<NotificationMessage>> notificationMessageSubscribers,
            ILogger<SubscribingService> logger = null,
            string id = null) : base(logger,
            id)
        {
            Subscribers = notificationMessageSubscribers?.ToList()
                                        ?? Enumerable.Empty<ITypedObjectSubscriber<NotificationMessage>>().ToList();
        }

        protected override void InternalInitialize()
        {
            Subscribers.InitializeServices();
        }

        protected override void InternalStart()
        {
            var compositeDisposable = new CompositeDisposable();
            foreach (var subscriber in Subscribers)
            {
                compositeDisposable.Add(subscriber.DataReceived
                    .Subscribe(data => OnNotificationMessageSubscribed(subscriber.Id, data)));
            }
            m_subscriptionDisposable = compositeDisposable;

            Subscribers.StartServices();
        }

        protected override void InternalStop()
        {
            Subscribers.StopServices();

            m_subscriptionDisposable?.Dispose();
            m_subscriptionDisposable = null;
        }

        protected override void InnerManagedDispose()
        {
            Subscribers.DisposeServices();
            Subscribers.ClearIfIsNotReadyOnly();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Subscribers = null;

            base.InnerNullifyReferencesDispose();
        }

        private void OnNotificationMessageSubscribed(string subscriberId, NotificationMessage notificationMessage)
        {
            Logger.LogInformation($"Notification subscribed! SubscriberId: {subscriberId}, Content: {notificationMessage}");
        }
    }
}