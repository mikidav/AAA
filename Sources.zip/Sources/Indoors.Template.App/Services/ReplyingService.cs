﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Disposables;
using Indoors.Communications.Common.Repliers;
using Indoors.Services.Common;
using Indoors.Template.App.Messages;
using Microsoft.Extensions.Logging;

namespace Indoors.Template.App.Services
{
    public class ReplyingService : ServiceBase, IReplyingService
    {
        private IDisposable m_subscriptionDisposable;
        public IList<ITypedObjectReplier<RequestMessage, ReplyMessage>> Repliers { get; private set; }

        public ReplyingService(IEnumerable<ITypedObjectReplier<RequestMessage, ReplyMessage>> repliers,
            ILogger<SubscribingService> logger = null,
            string id = null)
            : base(logger, id)
        {
            Repliers = repliers?.ToList()
                                        ?? Enumerable.Empty<ITypedObjectReplier<RequestMessage, ReplyMessage>>().ToList();
        }

        protected override void InternalInitialize()
        {
            Repliers.InitializeServices();
        }

        protected override void InternalStart()
        {
            Repliers.StartServices();

            var compositeDisposable = new CompositeDisposable();
            foreach (var replier in Repliers)
            {
                compositeDisposable.Add(
                    replier.RegisterReply((RequestMessage data, out ReplyMessage replyData) =>
                        ReplyToRequest(replier.Id, data, out replyData)));
            }
            m_subscriptionDisposable = compositeDisposable;
        }

        protected override void InternalStop()
        {
            Repliers.StopServices();

            m_subscriptionDisposable?.Dispose();
            m_subscriptionDisposable = null;
        }

        protected override void InnerManagedDispose()
        {
            Repliers.DisposeServices();
            Repliers.ClearIfIsNotReadyOnly();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Repliers = null;

            base.InnerNullifyReferencesDispose();
        }

        private void ReplyToRequest(string replierId, RequestMessage requestData, out ReplyMessage replyData)
        {
            Logger.LogInformation($"Request subscribed! ReplierId: {replierId}, Content: {requestData}");
            replyData = new ReplyMessage { Reply = $"Reply to: {requestData.Request}" };
        }
    }
}