﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Disposables;
using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Types;
using Indoors.Services.Common;
using Indoors.Template.App.Messages;
using Microsoft.Extensions.Logging;

namespace Indoors.Template.App.Services
{
    public class PublishingService : ServiceBase, IPublishingService
    {
        private IDisposable m_subscriptionsDisposable;

        public IList<ITypedObjectPublisher<NotificationMessage>> Publishers { get; private set; }

        public PublishingService(IEnumerable<ITypedObjectPublisher<NotificationMessage>> notificationPublisher)
        {
            Publishers = notificationPublisher?.ToList() 
                                    ?? Enumerable.Empty<ITypedObjectPublisher<NotificationMessage>>().ToList();
        }

        protected override void InternalInitialize()
        {
            Publishers.InitializeServices();
        }

        protected override void InternalStart()
        {
            var compositeDisposable = new CompositeDisposable();

            foreach (var publisher in Publishers)
            {
                compositeDisposable.Add(publisher.PublishCompleted
                    .Subscribe(data => OnPublishCompleted(publisher.Id, data)));
                compositeDisposable.Add(publisher.PublishFailed
                    .Subscribe(data => OnPublishFailed(publisher.Id, data)));
            }
            
            m_subscriptionsDisposable = compositeDisposable;

            Publishers.StartServices();
        }

        protected override void InternalStop()
        {
            Publishers.StopServices();

            m_subscriptionsDisposable?.Dispose();
            m_subscriptionsDisposable = null;
        }

        protected override void InnerManagedDispose()
        {
            Publishers?.DisposeServices();
            Publishers?.ClearIfIsNotReadyOnly();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Publishers = null;

            base.InnerNullifyReferencesDispose();
        }

        private void OnPublishFailed(string publisherId, OperationFailedData operationFailedData)
        {
            if (operationFailedData?.ThrownException != null)
                Logger.LogDebug(operationFailedData.ThrownException, $"Publish Failed! PublisherId: {publisherId}, OperationId: {operationFailedData.OperationId}");
            else
                Logger.LogDebug($"Publish Failed! PublisherId: {publisherId}, OperationId: {operationFailedData?.OperationId}");
        }

        private void OnPublishCompleted(string publisherId, OperationCompletedData operationCompletedData)
        {
            Logger.LogDebug($"Publish completed! PublisherId: {publisherId}, OperationId: {operationCompletedData?.OperationId}");
        }
    }
}