﻿using Indoors.Services.Common;

namespace Indoors.Template.App.Services
{
    public interface ISubscribingService : IService
    {

    }
}