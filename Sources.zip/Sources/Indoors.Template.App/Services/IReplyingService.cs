﻿using Indoors.Services.Common;

namespace Indoors.Template.App.Services
{
    public interface IReplyingService : IService
    {
    }
}