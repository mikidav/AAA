﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Disposables;
using Indoors.Communications.Common.Requesters;
using Indoors.Communications.Common.Types;
using Indoors.Services.Common;
using Indoors.Template.App.Messages;
using Microsoft.Extensions.Logging;

namespace Indoors.Template.App.Services
{
    public class RequestingService : ServiceBase, IRequestingService
    {
        private IDisposable m_subscriptionsDisposable;

        public IList<ITypedObjectRequester<RequestMessage, ReplyMessage>> Requesters { get; private set; }

        public RequestingService(IEnumerable<ITypedObjectRequester<RequestMessage, ReplyMessage>> requesters)
        {
            Requesters = requesters?.ToList() 
                                    ?? Enumerable.Empty<ITypedObjectRequester<RequestMessage, ReplyMessage>>().ToList();
        }

        protected override void InternalInitialize()
        {
            Requesters.InitializeServices();
        }

        protected override void InternalStart()
        {
            var compositeDisposable = new CompositeDisposable();

            foreach (var requester in Requesters)
            {
                compositeDisposable.Add(requester.RequestCompleted
                    .Subscribe(data => OnRequestCompleted(requester.Id, data)));
                compositeDisposable.Add(requester.RequestFailed
                    .Subscribe(data => OnRequestFailed(requester.Id, data)));
            }
            
            m_subscriptionsDisposable = compositeDisposable;

            Requesters.StartServices();
        }

        protected override void InternalStop()
        {
            Requesters.StopServices();

            m_subscriptionsDisposable?.Dispose();
            m_subscriptionsDisposable = null;
        }

        protected override void InnerManagedDispose()
        {
            Requesters?.DisposeServices();
            Requesters?.ClearIfIsNotReadyOnly();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Requesters = null;

            base.InnerNullifyReferencesDispose();
        }

        private void OnRequestFailed(string requestId, OperationFailedData operationFailedData)
        {
            if (operationFailedData?.ThrownException != null)
                Logger.LogDebug(operationFailedData.ThrownException, $"Request Failed! RequestId: {requestId}, OperationId: {operationFailedData.OperationId}");
            else
                Logger.LogDebug($"Request Failed! RequestId: {requestId}, OperationId: {operationFailedData?.OperationId}");
        }

        private void OnRequestCompleted(string requestId, OperationCompletedData operationCompletedData)
        {
            Logger.LogDebug($"Request completed! RequestId: {requestId}, OperationId: {operationCompletedData?.OperationId}");
        }
    }
}