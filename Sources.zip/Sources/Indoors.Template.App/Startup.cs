using Autofac;
using Indoors.Communications.RabbitMQ.Connection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;

namespace Indoors.Template.App
{
    /// <summary>
    /// The Configure, ConfigureServices, and ConfigureContainer methods all support
    /// environment-specific naming conventions based on the IHostingEnvironment.
    /// EnvironmentName in your app.
    /// By default, the names are Configure, ConfigureServices, and ConfigureContainer.
    /// If you want environment-specific setup you can put the environment name after the Configure part,
    /// like ConfigureDevelopment, ConfigureDevelopmentServices, and ConfigureDevelopmentContainer.
    /// If a method isn�t present with a name matching the environment it�ll fall back to the default.
    /// </summary>
    public sealed class Startup
    {
        public IWebHostEnvironment WebHostEnvironment { get; }
        public IConfiguration Configurations { get; }

        public Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
        {
            Configurations = configuration;
            WebHostEnvironment = webHostEnvironment;
        }

        // ConfigureServices is where you register dependencies. This gets
        // called by the runtime before the ConfigureContainer method, below.
        public void ConfigureServices(IServiceCollection services)
        {
            // Add services to the collection. Don't build or return
            // any IServiceProvider or the ConfigureContainer method
            // won't get called. Don't create a ContainerBuilder
            // for Autofac here, and don't call builder.Populate() - that
            // happens in the AutofacServiceProviderFactory for you.

            services.AddOptions();

            services.AddControllers();

            // 1 - Add health checks
            // 2 - Add custom IService health check
            // 3 - Add health controller for expose Rest-Api to swagger
            services.AddHealthChecks()
                    .AddServicesHealthChecks();
            services.AddHealthController();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Indoors.Template.App", Version = "v1" });
            });
        }

        // This is the default if you don't have an environment specific method.
        public void ConfigureContainer(ContainerBuilder builder)
        {
            // Register your own things directly with Autofac here. Don't
            // call builder.Populate(), that happens in AutofacServiceProviderFactory
            // for you.

            // Install modules using configuration (look at the file appsettings.json)
            var module = new Autofac.Configuration.ConfigurationModule(Configurations);
            builder.RegisterModule(module);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IRabbitMqConnectionService rabbitMqConnection)
        {
            // If, for some reason, you need a reference to the built container, you
            // can use the convenience extension method GetAutofacRoot.
            // var autofacContainer = app.ApplicationServices.GetAutofacRoot();

            app.ConfigureErrorRoutes(WebHostEnvironment);

            app.UseRouting();

            // Configure base health checks for the app
            app.UseIndoorsHealthChecks();

            //Recommended only in development mode
            if (WebHostEnvironment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Indoors.Template.App v1"));
            }


            app.UseEndpoints(endpoints =>
            {
                // Map the service health checks endpoints
                endpoints.MapServicesHealthChecks();
				
                endpoints.MapControllers();
            });

            rabbitMqConnection.Initialize();
            rabbitMqConnection.Start();
        }
    }
}
