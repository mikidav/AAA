﻿using System.Collections.Generic;
using Google.Protobuf.Reflection;
using Indoors.Serializations.Protobuf;

namespace Indoors.Template.App.Messages
{
    public class MessageFileDescriptorProvider : IFileDescriptorProvider
    {
        public IEnumerable<FileDescriptor> Descriptors => new[] { MessagesReflection.Descriptor };
    }
}