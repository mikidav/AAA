﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Requesters;
using Indoors.Template.App.Messages;
using Microsoft.Extensions.Logging;

namespace Indoors.Template.App.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommunicationController : ControllerBase
    {
        public IList<ITypedObjectPublisher<NotificationMessage>> Publishers { get; }
        public IList<ITypedObjectRequester<RequestMessage, ReplyMessage>> Requesters { get; }
        public ILogger<CommunicationController> Logger { get; }

        public CommunicationController(
            IEnumerable<ITypedObjectPublisher<NotificationMessage>> publishers,
            IEnumerable<ITypedObjectRequester<RequestMessage, ReplyMessage>> requesters,
            ILogger<CommunicationController> logger = null)
        {
            Publishers = publishers?.ToList()
                ?? Enumerable.Empty<ITypedObjectPublisher<NotificationMessage>>().ToList();
            Requesters = requesters?.ToList()
                         ?? Enumerable.Empty<ITypedObjectRequester<RequestMessage, ReplyMessage>>().ToList();
            Logger = logger;
        }

        // GET api/communication/notification?content={content}
        [HttpGet("notification")]
        public IActionResult InvokeNotification([FromQuery, Required] string content)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var operationIds = new List<string>(Publishers.Count);

            try
            {
                var notificationMessage = new NotificationMessage { Notification = content };
                foreach (var publisher in Publishers)
                {
                    var operationId = publisher.Publish(notificationMessage);
                    operationIds.Add(operationId);
                }
            }
            catch (Exception ex)
            {
                Logger?.LogError(ex, $"Failed on try to invoke notification! Content: {content}");
                return BadRequest("Some error occurred on notification process... Please retry again.");
            }

            return Ok(new { OperationIDs = operationIds });
        }

        // GET api/communication/requestasync?content={content}
        [HttpGet("requestasync")]
        public async Task<IActionResult> InvokeRequestAsync([FromQuery, Required] string content)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var responds = new ConcurrentDictionary<string, ReplyMessage>();

            try
            {
                var notificationMessage = new RequestMessage { Request = content };

                foreach (var requester in Requesters)
                {
                    var (requestId, reply) = await requester.RequestAsync(notificationMessage);
                    responds.TryAdd(requestId, reply);
                }
            }
            catch (Exception ex)
            {
                Logger?.LogError(ex, $"Failed on try to invoke request! Content: {content}");
                return BadRequest("Some error occurred on request process... Please retry again.");
            }

            return Ok(responds);
        }

        // GET api/communication/request?content={content}
        [HttpGet("request")]
        public IActionResult InvokeRequest([FromQuery, Required] string content)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var responds = new Dictionary<string, ReplyMessage>();

            try
            {
                var notificationMessage = new RequestMessage { Request = content };

                foreach (var requester in Requesters)
                {
                    var (requestId, reply) = requester.Request(notificationMessage);
                    responds.TryAdd(requestId, reply);
                }
            }
            catch (Exception ex)
            {
                Logger?.LogError(ex, $"Failed on try to invoke request! Content: {content}");
                return BadRequest("Some error occurred on request process... Please retry again.");
            }

            return Ok(responds);
        }
    }
}
