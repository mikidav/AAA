using Autofac;
using Indoors.Communications.Core.DI.Autofac;
using Indoors.Communications.RabbitMQ.DI.Autofac;
using Indoors.Serializations.Protobuf.DI.Autofac;
using Indoors.Services.Common;
using Indoors.Services.Hosting;
using Indoors.Template.App.Messages;
using Indoors.Template.App.Services;
using Microsoft.Extensions.Hosting;
using Module = Autofac.Module;

namespace Indoors.Template.App.Container
{
    public class TemplateServicesModuleInstaller : Module
    {
        public bool IsDebug { get; set; }

        public TemplateServicesModuleInstaller(bool isDebug)
        {
            IsDebug = isDebug;
        }

        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            builder.RegisterFileDescriptorProvider<MessageFileDescriptorProvider>();

            builder.RegisterRabbitMqPublisher<NotificationMessage>();

            builder.RegisterUdpPublisher<NotificationMessage>("UdpPublisherNetworkSettings");

            builder.RegisterRabbitMqSubscriber<NotificationMessage>();

            builder.RegisterUdpSubscriber<NotificationMessage>("UdpSubscriberNetworkSettings");

            builder.RegisterRabbitMqRequester<RequestMessage, ReplyMessage>();

            builder.RegisterRabbitMqReplier<RequestMessage, ReplyMessage>();

            builder.RegisterType<PublishingService>()
                .As<IPublishingService, IService>()
                .SingleInstance();

            builder.RegisterType<ServicesHostedService<IPublishingService>>()
                .As<IHostedService>()
                .WithParameter(new NamedParameter("id", "PublishingServiceHost"));

            builder.RegisterType<SubscribingService>()
                .As<ISubscribingService, IService>()
                .SingleInstance();

            builder.RegisterType<ServicesHostedService<ISubscribingService>>()
                .As<IHostedService>()
                .WithParameter(new NamedParameter("id", "SubscribingServiceHost"));

            builder.RegisterType<RequestingService>()
                .As<IRequestingService, IService>()
                .SingleInstance();

            builder.RegisterType<ServicesHostedService<IRequestingService>>()
                .As<IHostedService>()
                .WithParameter(new NamedParameter("id", "RequestingServiceHost"));

            builder.RegisterType<ReplyingService>()
                .As<IReplyingService, IService>()
                .SingleInstance();

            builder.RegisterType<ServicesHostedService<IReplyingService>>()
                .As<IHostedService>()
                .WithParameter(new NamedParameter("id", "ReplyingServiceHost"));
        }
    }
}