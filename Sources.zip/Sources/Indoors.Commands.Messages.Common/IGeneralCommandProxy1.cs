﻿using Indoors.Services.Common;

namespace Indoors.Gateway.Proxy
{
    public interface IGeneralCommandProxy : IService
    {

    }
}
