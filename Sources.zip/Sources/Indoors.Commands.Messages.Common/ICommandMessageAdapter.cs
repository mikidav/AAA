namespace Indoors.Commands.Messages.Common
{
    public interface ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
    {
        (string operationId, TCommandParameter) ToCommandParameter(TCommandDomainMessage src);
        TCommandDomainMessage ToMessage(string operationId, TCommandParameter src);
    }

    public interface ICommandMessageAdapter1<TCommandParameter, TCommandDomainMessage>
    {
        TCommandParameter ToCommandParameter(TCommandDomainMessage message);
        TCommandDomainMessage ToMessage(TCommandParameter commandParameter);
    }


}