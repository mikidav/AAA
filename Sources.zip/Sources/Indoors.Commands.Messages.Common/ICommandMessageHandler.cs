﻿using Indoors.Services.Common;

namespace Indoors.Commands.Messages.Common
{
    public interface ICommandMessageHandler : IService
    {
        
    }
}