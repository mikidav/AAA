﻿using Indoors.Commands.Common;

namespace Indoors.Gateway.Proxy
{
    public interface IGeneralCommandProxy<TCommandParameter> : ICommand<TCommandParameter>
       where TCommandParameter : class
    {

    }
}
