﻿using Indoors.Commands.Common;
using Indoors.Services.Common;
using Indoors.Communications.Common.Publishers;
using Microsoft.Extensions.Logging;
using Indoors.Commands.Messages.Common;

namespace Indoors.Gateway.Proxy
{

    public class GeneralCommandProxy<TCommandParameter, TCommandDomainMessage> : CommandProxyBase<TCommandParameter>,
        IGeneralCommandProxy,
        IGeneralCommandProxy<TCommandParameter>
        where TCommandParameter : class
        where TCommandDomainMessage : class
    {
        public ITypedObjectPublisher<TCommandDomainMessage> Publisher { get; private set; }
        public ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage> MessageAdapter { get; private set; }

        public GeneralCommandProxy(ITypedObjectPublisher<TCommandDomainMessage> publisher,
            ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage> messageAdapter,
            ICommandConfig<TCommandParameter> commandConfig,
            ILogger<GeneralCommandProxy<TCommandParameter, TCommandDomainMessage>> logger = null,
            string id = null)
            : base(commandConfig, logger, id)
        {
            Publisher = publisher;
            MessageAdapter = messageAdapter;
        }

        public GeneralCommandProxy(ITypedObjectPublisher<TCommandDomainMessage> publisher,
            ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage> messageAdapter,
            ICommandConfig commandConfig,
            ILogger<GeneralCommandProxy<TCommandParameter, TCommandDomainMessage>> logger = null,
            string id = null)
            : base(commandConfig, logger, id)
        {
            Publisher = publisher;
            MessageAdapter = messageAdapter;
        }

        public GeneralCommandProxy(ITypedObjectPublisher<TCommandDomainMessage> publisher,
            ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage> messageAdapter,
            bool disableExecutionLog = true,
            ILogger<GeneralCommandProxy<TCommandParameter, TCommandDomainMessage>> logger = null,
            string id = null)
            : base(disableExecutionLog, logger, id)
        {
            Publisher = publisher;
            MessageAdapter = messageAdapter;
        }

        protected override void InternalInitialize()
        {
            Publisher.Initialize();
        }

        protected override void InternalStart()
        {
            Publisher.Start();
        }

        protected override void InternalStop()
        {
            Publisher?.Stop();
        }

        protected override void InternalExecute(string id, TCommandParameter parameter = default)
        {
            var message = MessageAdapter.ToMessage(id, parameter);
            Publisher.Publish(message);
        }

        protected override bool InternalCanExecute(TCommandParameter parameter = default)
        {
            var isProxyRunning = IsRunning;
            var isPublisherRunning = Publisher?.IsRunning == true;
            var canExecute = isProxyRunning && isPublisherRunning;

            return canExecute;
        }

        protected override void InnerManagedDispose()
        {
            Publisher?.TryDisposeService();
            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Publisher = null;
            MessageAdapter = null;
            base.InnerNullifyReferencesDispose();
        }
    }
}
