using System;
using System.Reactive.Subjects;
using Indoors.Commands.Handlers.Common;
using Indoors.Communications.Common.Subscribers;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Commands.Messages.Common
{
    public class CommandMessageHandler<TCommandParameter, TCommandDomainMessage> : ServiceBase, ICommandMessageHandler,
        ICommandNotifier<TCommandParameter>
    {
        private IDisposable m_subscriptionDisposable;

        private readonly ISubject<(string id, TCommandParameter parameter)> m_commandReceived = new Subject<(string id, TCommandParameter parameter)>();

        public IObservable<(string id, TCommandParameter parameter)> CommandReceived => m_commandReceived;
        public ITypedObjectSubscriber<TCommandDomainMessage> Subscriber { get; private set; }
        public ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage> MessageAdapter { get; private set; }

        public Type InstanceType { get; }
        public Type ParameterType { get; }
        public Type MessageType { get; }
        public string TypesDescriptionString => $"{nameof(InstanceType)}: {InstanceType}, {nameof(ParameterType)}: {ParameterType}, {nameof(MessageType)}: {MessageType}";

        public CommandMessageHandler(ITypedObjectSubscriber<TCommandDomainMessage> subscriber,
            ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage> messageAdapter,
            ILogger<CommandMessageHandler<TCommandParameter, TCommandDomainMessage>> logger = null)
            : base(logger, nameof(CommandMessageHandler<TCommandParameter, TCommandDomainMessage>))
        {
            Subscriber = subscriber;
            MessageAdapter = messageAdapter;

            InstanceType = GetType();
            ParameterType = typeof(TCommandParameter);
            MessageType = typeof(TCommandDomainMessage);
        }

        protected override void InternalInitialize()
        {
            Subscriber.Initialize();
        }

        protected override void InternalStart()
        {
            Subscriber.Start();

            m_subscriptionDisposable = Subscriber.DataReceived.Subscribe(OnCommandMessageReceived);
        }

        protected override void InternalStop()
        {
            m_subscriptionDisposable?.Dispose();
            m_subscriptionDisposable = null;

            Subscriber.Stop();
        }

        private void OnCommandMessageReceived(TCommandDomainMessage message)
        {
            try
            {
                HandleCommandMessage(message);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to handle command message! Message: [{message}], {TypesDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }
        }

        protected virtual void HandleCommandMessage(TCommandDomainMessage message)
        {
            var tuple = MessageAdapter.ToCommandParameter(message);
            m_commandReceived.OnNext(tuple);
        }

        protected override void InnerManagedDispose()
        {
            Subscriber?.TryDisposeService();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Subscriber = null;
            MessageAdapter = null;

            base.InnerNullifyReferencesDispose();
        }
    }
}