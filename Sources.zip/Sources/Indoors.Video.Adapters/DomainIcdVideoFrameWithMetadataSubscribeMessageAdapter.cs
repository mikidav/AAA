﻿using Indoors.Communications.Core.Adapters;
using Indoors.DomainIcd.Video.Messages;
using Indoors.Video.Common.Types;

namespace Indoors.Video.Adapters
{
    public class DomainIcdVideoFrameWithMetadataSubscribeMessageAdapter 
        : ISubscribeDataMessageAdapter<IVideoFrame<IVideoFrameMetadata>, VideoFrameMessage>
    {
        public (string operationId, IVideoFrame<IVideoFrameMetadata>) ToData(VideoFrameMessage message)
        {
            if (message?.Data == null)
                return (null, null);

            var frame = message.Data.ToType<VideoFrame<IVideoFrameMetadata>, Image>();
            frame.Metadata = message.Metadata.ToType<VideoFrameMetadata>();
            return (message.Id, frame);
        }
    }
}