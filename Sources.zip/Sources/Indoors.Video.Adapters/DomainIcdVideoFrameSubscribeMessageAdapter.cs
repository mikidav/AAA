﻿using Indoors.Communications.Core.Adapters;
using Indoors.DomainIcd.Video.Messages;
using Indoors.Video.Common.Types;

namespace Indoors.Video.Adapters
{
    public class DomainIcdVideoFrameSubscribeMessageAdapter
        : ISubscribeDataMessageAdapter<IVideoFrame, VideoFrameMessage>
    {
        public (string operationId, IVideoFrame) ToData(VideoFrameMessage message)
        {
            if (message?.Data == null)
                return (null, null);
            var frame = message.Data.ToType<VideoFrame, Image>();
            return (message.Id, frame);
        }
    }
}