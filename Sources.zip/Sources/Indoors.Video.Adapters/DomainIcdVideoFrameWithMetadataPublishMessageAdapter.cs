﻿using Indoors.Communications.Core.Adapters;
using Indoors.DomainIcd.Video.Messages;
using Indoors.Video.Common.Types;

namespace Indoors.Video.Adapters
{
    public class DomainIcdVideoFrameWithMetadataPublishMessageAdapter
        : IPublishDataMessageAdapter<IVideoFrame<IVideoFrameMetadata>, VideoFrameMessage>
    {
        public VideoFrameMessage ToMessage(string operationId, IVideoFrame<IVideoFrameMetadata> data)
        {
            if (data == null)
                return null;

            var messageDataStruct = data.ToMessage();
            var messageMetadataStruct = data.Metadata?.ToMessage();
            var message = new VideoFrameMessage
            {
                Id = operationId ?? $"{data.VideoId}-{data.FrameId}-{data.FrameSequence}",
                Data = messageDataStruct,
                Metadata = messageMetadataStruct
            };
            return message;
        }
    }
}