﻿using Indoors.Communications.Core.Adapters;
using Indoors.DomainIcd.Video.Messages;
using Indoors.Video.Common.Types;

namespace Indoors.Video.Adapters
{
    public class DomainIcdVideoFramePublishMessageAdapter
        : IPublishDataMessageAdapter<IVideoFrame, VideoFrameMessage>
    {
        public VideoFrameMessage ToMessage(string operationId, IVideoFrame data)
        {
            if (data == null)
                return null;

            var messageDataStruct = data.ToMessage();
            var message = new VideoFrameMessage
            {
                Id = operationId ?? $"{data.VideoId}-{data.FrameId}-{data.FrameSequence}",
                Data = messageDataStruct,
            };
            return message;
        }
    }
}