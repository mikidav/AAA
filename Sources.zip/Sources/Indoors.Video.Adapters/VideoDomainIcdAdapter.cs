﻿using System;
using Google.Protobuf;
using Google.Protobuf.WellKnownTypes;
using Indoors.DomainIcd.Video.Messages;
using Indoors.Video.Common.Types;

namespace Indoors.Video.Adapters
{
    public static class VideoDomainIcdAdapter
    {
        public static TVideoFrame ToType<TVideoFrame, TImage>(this VideoFrameStruct messageDataStruct)
            where TVideoFrame : IVideoFrame, new() where TImage : IWritableImage, new()
        {
            if (messageDataStruct == null)
                return default;

            var type = new TVideoFrame
            {
                VideoId = messageDataStruct.VideoId,
                FrameId = messageDataStruct.FrameId,
                FrameSequence = messageDataStruct.FrameSequence,
                FrameTimeSensor = messageDataStruct.FrameTimeSensor?.ToDateTime() ?? default,
                FrameTimeLocal = messageDataStruct.FrameTimeLocal?.ToDateTime() ?? default,
                EncodedImage = messageDataStruct.EncodedImage != null ? messageDataStruct.EncodedImage.ToType<TImage>() : default,
                DecodedImage = messageDataStruct.DecodedImage != null ? messageDataStruct.DecodedImage.ToType<TImage>() : default,
            };

            return type;
        }

        public static VideoFrameStruct ToMessage(this IVideoFrame type)
        {
            if (type == null)
                return default;

            var frameTimeSensor = type.FrameTimeSensor.Kind != DateTimeKind.Utc
                ? type.FrameTimeSensor.ToUniversalTime()
                : type.FrameTimeSensor;

            var frameTimeLocal = type.FrameTimeLocal.Kind != DateTimeKind.Utc
                ? type.FrameTimeLocal.ToUniversalTime()
                : type.FrameTimeLocal;

            var dataStruct = new VideoFrameStruct
            {
                VideoId = type.VideoId ?? string.Empty,
                FrameId = type.FrameId ?? string.Empty,
                FrameSequence = type.FrameSequence,
                FrameTimeSensor = frameTimeSensor.ToTimestamp(),
                FrameTimeLocal = frameTimeLocal.ToTimestamp(),
                EncodedImage = type.EncodedImage?.ToMessage(),
                DecodedImage = type.DecodedImage?.ToMessage(),
            };

            return dataStruct;
        }

        public static TImage ToType<TImage>(this ImageStruct message) where TImage : IWritableImage, new()
        {
            if (message == null)
                return default;

            var type = new TImage
            {
                ImageBuffer = message.ImageBuffer?.ToByteArray(),
                EncodingFormat = message.EncodingFormat,
                PixelFormat = message.PixelFormat,
                Height = message.Height,
                Width = message.Width,
                ContentHeight = message.ContentHeight,
                ContentWidth = message.ContentWidth
            };

            return type;
        }

        public static ImageStruct ToMessage(this IImage type)
        {
            if (type == null)
                return null;

            var message = new ImageStruct
            {
                ImageBuffer = type.ImageBuffer == null ? ByteString.Empty : ByteString.CopyFrom(type.ImageBuffer),
                EncodingFormat = type.EncodingFormat ?? string.Empty,
                PixelFormat = type.PixelFormat ?? string.Empty,
                Height = type.Height,
                Width = type.Width,
                ContentHeight = type.ContentHeight,
                ContentWidth = type.ContentWidth
            };

            return message;
        }

        public static TMetadata ToType<TMetadata>(this VideoFrameMetadataStruct messageVideoFrameMetadataStruct) where TMetadata : IWritableVideoFrameMetadata, new()
        {
            if (messageVideoFrameMetadataStruct == null)
                return default;

            var type = new TMetadata
            {
                VideoId = messageVideoFrameMetadataStruct.VideoId,
                FrameId = messageVideoFrameMetadataStruct.FrameId,
                FrameSequence = messageVideoFrameMetadataStruct.FrameSequence,
                FrameTimeSensor = messageVideoFrameMetadataStruct.FrameTimeSensor?.ToDateTime() ?? default,
                FrameTimeLocal = messageVideoFrameMetadataStruct.FrameTimeLocal?.ToDateTime() ?? default,
            };

            return type;
        }

        public static VideoFrameMetadataStruct ToMessage(this IVideoFrameMetadata type)
        {
            if (type == null)
                return default;

            var frameTimeSensor = type.FrameTimeSensor.Kind != DateTimeKind.Utc
                ? type.FrameTimeSensor.ToUniversalTime()
                : type.FrameTimeSensor;

            var frameTimeLocal = type.FrameTimeLocal.Kind != DateTimeKind.Utc
                ? type.FrameTimeLocal.ToUniversalTime()
                : type.FrameTimeLocal;

            var dataStruct = new VideoFrameMetadataStruct
            {
                VideoId = type.VideoId ?? string.Empty,
                FrameId = type.FrameId ?? string.Empty,
                FrameSequence = type.FrameSequence,
                FrameTimeSensor = frameTimeSensor.ToTimestamp(),
                FrameTimeLocal = frameTimeLocal.ToTimestamp(),
            };

            return dataStruct;
        }

    }
}