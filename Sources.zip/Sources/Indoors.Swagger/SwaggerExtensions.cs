﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;

namespace Indoors.Swagger
{
    public static class SwaggerExtensions
    {
        public static IServiceCollection AddIndoorsSwagger(this IServiceCollection services, SwaggerSettings settings)
        {
            return services.AddSwaggerGen(configuration =>
            {
                configuration.SwaggerDoc(settings.Version, new OpenApiInfo
                {
                    Title = settings.Title,
                    Version = settings.Version,
                    Description = settings.Description
                });
                configuration.EnableAnnotations(true, true);
            });
        }

        public static IApplicationBuilder UseIndoorsSwagger(this IApplicationBuilder app)
        {
            return app.UseSwagger();
        }

        public static IApplicationBuilder UseIndoorsSwaggerUI(this IApplicationBuilder app, SwaggerSettings settings)
        {
            return app.UseSwaggerUI(setupAction =>
            {
                setupAction.SwaggerEndpoint($"/swagger/V1/swagger.json", settings.Version);
            });
        }

        public static IEndpointRouteBuilder MapIndoorsSwagger(this IEndpointRouteBuilder endpoints)
        {
            return endpoints.MapSwagger();
        }
    }
}
