﻿using System.Collections.Generic;
using Google.Protobuf.Reflection;
using Indoors.Serializations.Protobuf;
using Indoors.DomainIcd.Platform.Messages;

namespace Indoors.DomainIcd.Platform
{
    public class PlatformDomainIcdDescriptorProvider : IFileDescriptorProvider
    {
        public IEnumerable<FileDescriptor> Descriptors => new[] { PlatformMessagesReflection.Descriptor };
    }
}