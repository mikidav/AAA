﻿using System;
using System.Runtime.CompilerServices;
using Microsoft.Extensions.Logging;

namespace Indoors.Services.Common
{
    /// <summary>
    /// Defines a base behavior for services
    /// </summary>
    public abstract class ServiceBase : IService, IDisposable
    {
        private ILogger m_logger;
        protected ILogger Logger => m_logger ?? DummyLogger.Instance;

        public string Id { get; }
        public ServiceState State { get; private set; }

        public virtual bool IsUnknown => State == ServiceState.Unknown;
        public virtual bool IsDisposed => State == ServiceState.Disposed;
        public virtual bool IsNotReady => State == ServiceState.NotReady;
        public virtual bool IsReady => State == ServiceState.Ready;
        public virtual bool IsRunning => State == ServiceState.Running;
        public virtual bool IsError => State == ServiceState.Error;

        protected string ServiceDescriptionString => $"ID: {Id}, State: {State}";

        protected ServiceBase(ILogger logger = null, string id = null)
        {
            m_logger = logger;
            Id = GenerateId(id);

            State = ServiceState.NotReady;

            Logger.LogInformation($"{Id} Service created. State: {State}");
        }

        public void Initialize()
        {
            if (IsReady || IsRunning)
                return;

            Logger.LogInformation($"{Id} Service initializing... State: {State}");

            ValidateIsNotDisposed($"Failed to initialize the service because it already was disposed! {ServiceDescriptionString}");

            State = ServiceState.NotReady;

            try
            {
                InternalInitialize();
                State = ServiceState.Ready;

                Logger.LogInformation($"{Id} Service initialized. State: {State}");
            }
            catch (Exception ex)
            {
                State = ServiceState.Error;

                var errorMessage = $"Failed to initialize the Service! {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);

                throw new Exception(errorMessage, ex);
            }
        }

        public void Start()
        {
            if (IsRunning)
                return;

            Logger.LogInformation($"{Id} Service staring... State: {State}");

            ValidateIsNotDisposed($"Failed to start the service because it already was disposed! {ServiceDescriptionString}");

            if (State != ServiceState.Ready)
            {
                var errorMessage = $"Failed to start the service because it was not in a ready state! {ServiceDescriptionString}";
                Logger.LogError(errorMessage);
                throw new Exception(errorMessage);
            }

            try
            {
                InternalStart();
                State = ServiceState.Running;

                Logger.LogInformation($"{Id} Service started. State: {State}");
            }
            catch (Exception ex)
            {
                State = ServiceState.Error;

                var errorMessage = $"Failed to start the Service! {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);

                throw new Exception(errorMessage, ex);
            }
        }

        public void Stop()
        {
            if (IsReady)
                return;

            Logger.LogInformation($"{Id} Service Stopping... State: {State}");

            ValidateIsNotDisposed($"Failed to stop the service because it already was disposed! {ServiceDescriptionString}");

            if (State != ServiceState.Running)
            {
                var errorMessage = $"Failed to stop the service because it was not in a running state! {ServiceDescriptionString}";
                Logger.LogError(errorMessage);
                throw new Exception(errorMessage);
            }

            try
            {
                InternalStop();
                State = ServiceState.Ready;

                Logger.LogInformation($"{Id} Service stopped. State: {State}");
            }
            catch (Exception ex)
            {
                State = ServiceState.Error;

                var errorMessage = $"Failed to stop the Service! {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);

                throw new Exception(errorMessage, ex);
            }
        }

        protected void GoToErrorState(string errorMessage = null, Exception ex = null, [CallerMemberName] string callerName = "")
        {
            if (IsError)
                return;

            errorMessage ??= "Unknown";

            if (IsRunning)
            {
                try
                {
                    Logger.LogInformation($"[{callerName}] Trying to stop the service due to error... {ServiceDescriptionString}, Reason: {errorMessage}");
                    Stop();

                }
                catch (Exception)
                {
                    // ignored
                }
            }

            State = ServiceState.Error;

            var logErrorMessage = $"[{callerName}] Service state changed to Error! {ServiceDescriptionString}, Reason: {errorMessage}";

            if (ex == null)
                Logger.LogError(logErrorMessage);
            else
                Logger.LogError(ex, logErrorMessage);
        }

        protected void ValidateIsRunning(string errorMessage = null, [CallerMemberName] string callerName = "")
        {
            var isRunning = IsRunning;
            if (isRunning)
                return;
            errorMessage ??= $"[{callerName}] The service {Id} is not running as expected! State: {State}";
            Logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        protected void ValidateIsNotDisposed(string errorMessage = null, [CallerMemberName] string callerName = "")
        {
            var isDisposed = IsDisposed;
            if (!isDisposed)
                return;
            errorMessage ??= $"[{callerName}] The service {Id} is disposed! State: {State}";
            Logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        /// <summary>
        /// Implements the actual initializing logic in inheriting services.
        /// </summary>
        protected abstract void InternalInitialize();

        /// <summary>
        /// Implements the actual starting logic in inheriting services.
        /// </summary>
        protected abstract void InternalStart();

        /// <summary>
        /// Implements the actual stopping logic in inheriting services.
        /// </summary>
        protected abstract void InternalStop();

        private string GenerateId(string id)
        {
            if (!string.IsNullOrWhiteSpace(id))
                return id;

            var name = GetType().Name;
            var guid = Guid.NewGuid().ToString();
            var generatedId = $"{name}-{guid}";
            return generatedId;
        }

        #region IDisposable Pattern Support

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // IMPORTANT!! override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
        // ~HostedServiceBase()
        // {
        //     // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
        //     Dispose(disposing: false);
        // }

        protected virtual void Dispose(bool disposing)
        {
            if (IsDisposed)
            {
                if (disposing)
                {
                    if (IsRunning)
                    {
                        try
                        {
                            Logger.LogInformation($"Trying to stop the service as part of dispose sequence...  {ServiceDescriptionString}");
                            Logger.LogWarning($"Keep in mind that the correct use is to stop the service before calling dispose of it. {ServiceDescriptionString}");

                            Stop();
                        }
                        catch (Exception ex)
                        {
                            Logger.LogWarning(ex, $"Error trying to stop a service while disposing it! {ServiceDescriptionString}");
                        }
                    }

                    InnerManagedDispose();
                }

                InnerUnmanagedDispose();

                m_logger = null;

                InnerNullifyReferencesDispose();

                State = ServiceState.Disposed;
            }
        }

        protected virtual void InnerUnmanagedDispose()
        {
        }

        protected virtual void InnerManagedDispose()
        {
        }

        protected virtual void InnerNullifyReferencesDispose()
        {
        }

        #endregion
    }
}