﻿namespace Indoors.Services.Common
{
    public enum ServiceState
    {
        Unknown,
        Disposed,
        Error,
        NotReady,
        Ready,
        Running
    }
}