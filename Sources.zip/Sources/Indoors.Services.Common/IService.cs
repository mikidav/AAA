﻿namespace Indoors.Services.Common
{
    /// Defines a service with a start sequence of 3 stages: construct, initialize and start.
    public interface IService
    {
        string Id { get; }

        ServiceState State { get; }

        bool IsUnknown { get; }
        bool IsDisposed { get; }
        bool IsNotReady { get; }
        bool IsReady { get; }
        bool IsRunning { get; }
        bool IsError { get; }

        void Initialize();

        void Start();

        void Stop();
    }
}
