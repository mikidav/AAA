﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Indoors.Services.Common
{
    public static class ServiceExtensionsMethods
    {
        /// <summary>
        /// Return an <see cref="IEnumerable{IService}"/> of services.
        /// </summary>
        /// <param name="enumerable">An enumerable to case</param>
        /// <returns>An enumerable of services</returns>
        public static IEnumerable<IService> WhereService(this IEnumerable enumerable)
        {
            var serviceState = enumerable?.OfType<IService>();
            return serviceState;
        }

        /// <summary>
        /// Return an <see cref="IEnumerable{IService}"/> of services.
        /// </summary>
        /// <param name="enumerable">An enumerable to case</param>
        /// <returns>An enumerable of services</returns>
        public static IEnumerable<TService> WhereService<TService>(this IEnumerable enumerable) where TService : IService
        {
            var serviceState = enumerable?.OfType<TService>();
            return serviceState;
        }

        /// <summary>
        /// Return an <see cref="IEnumerable{IService}"/> of services in different state from received state.
        /// </summary>
        /// <param name="services">services enumerable</param>
        /// <param name="state">The requested state of the services</param>
        /// <returns>return an enumerable of services</returns>
        public static IEnumerable<IService> WhereServiceStateNot(this IEnumerable<IService> services, ServiceState state)
        {
            var serviceState = services?.Where(service => service?.State != state);
            return serviceState;
        }

        /// <summary>
        /// Return an <see cref="IEnumerable{TService}"/> of services in different state from received state.
        /// </summary>
        /// <typeparam name="TService">Heir type from <see cref="IService"/></typeparam>
        /// <param name="services">services enumerable</param>
        /// <param name="state">The requested state of the services</param>
        /// <returns>return an enumerable of services</returns>
        public static IEnumerable<TService> WhereServiceStateNot<TService>(this IEnumerable<TService> services, ServiceState state) where TService : IService
        {
            var serviceState = services?.Where(service => service?.State != state);
            return serviceState;
        }

        /// <summary>
        /// Return an <see cref="IEnumerable{IService}"/> of services in received state.
        /// </summary>
        /// <param name="services">services enumerable</param>
        /// <param name="state">The requested state of the services</param>
        /// <returns>return an enumerable of running services</returns>
        public static IEnumerable<IService> WhereServiceState(this IEnumerable<IService> services, ServiceState state)
        {
            var serviceState = services?.Where(service => service?.State == state);
            return serviceState;
        }

        /// <summary>
        /// Return an <see cref="IEnumerable{TService}"/> of services in received state.
        /// </summary>
        /// <typeparam name="TService">Heir type from <see cref="IService"/></typeparam>
        /// <param name="services">services enumerable</param>
        /// <param name="state">The requested state of the services</param>
        /// <returns>return an enumerable of running services</returns>
        public static IEnumerable<TService> WhereServiceState<TService>(this IEnumerable<TService> services, ServiceState state) where TService : IService
        {
            var serviceState = services?.Where(service => service?.State == state);
            return serviceState;
        }

        /// <summary>
        /// Return an <see cref="IEnumerable{IService}"/> of services in <see cref="ServiceState.Running"/> state.
        /// </summary>
        /// <param name="services">services enumerable</param>
        /// <returns>return an enumerable of services in <see cref="ServiceState.Running"/> state</returns>
        public static IEnumerable<IService> WhereServicesIsRunning(this IEnumerable<IService> services)
        {
            return WhereServiceState(services, ServiceState.Running);
        }

        /// <summary>
        /// Return an <see cref="IEnumerable{IService}"/> of services in <see cref="ServiceState.Running"/> state.
        /// </summary>
        /// <typeparam name="TService">Heir type from <see cref="IService"/></typeparam>
        /// <param name="services">services enumerable</param>
        /// <returns>return an enumerable of services in <see cref="ServiceState.Running"/> state</returns>
        public static IEnumerable<TService> WhereServicesIsRunning<TService>(this IEnumerable<TService> services) where TService : IService
        {
            return WhereServiceState(services, ServiceState.Running);
        }

        /// <summary>
        /// Initializing enumerable of services. 
        /// </summary>
        /// <typeparam name="TService">Heir type from <see cref="IService"/></typeparam>
        /// <param name="enumerable">Collection of services</param>
        public static void InitializeServices<TService>(this IEnumerable<TService> enumerable)
            where TService : IService
        {
            InitializeServices(enumerable.WhereService());
        }

        /// <summary>
        /// Initializing enumerable of <see cref="IService"/>
        /// </summary>
        /// <param name="enumerable">Collection of <see cref="IService"/></param>
        public static void InitializeServices(this IEnumerable<IService> enumerable)
        {
            enumerable?.ToList().ForEach(service => service.Initialize());
        }

        /// <summary>
        /// Starting enumerable of services. 
        /// </summary>
        /// <typeparam name="TService">Heir type from <see cref="IService"/></typeparam>
        /// <param name="enumerable">Collection of services</param>
        public static void StartServices<TService>(this IEnumerable<TService> enumerable)
            where TService : IService
        {
            StopServices(enumerable.WhereService());
        }

        /// <summary>
        /// Starting enumerable of <see cref="IService"/>
        /// </summary>
        /// <param name="enumerable">Collection of <see cref="IService"/></param>
        public static void StartServices(this IEnumerable<IService> enumerable)
        {
            enumerable?.ToList().ForEach(service => service.Start());
        }

        /// <summary>
        /// Stopping enumerable of services. 
        /// </summary>
        /// <typeparam name="TService">Heir type from <see cref="IService"/></typeparam>
        /// <param name="enumerable">Collection of services</param>
        /// <param name="stopInReverseOrder">Stop the services in reverse order [default=true].</param>
        public static void StopServices<TService>(this IEnumerable<TService> enumerable,
            bool stopInReverseOrder = true)
            where TService : IService
        {
            StopServices(enumerable.WhereService(), stopInReverseOrder);
        }

        /// <summary>
        /// Starting enumerable of <see cref="IService"/>
        /// </summary>
        /// <param name="enumerable">Collection of <see cref="IService"/></param>
        /// <param name="stopInReverseOrder">Stop the services in reverse order [default=true].</param>
        public static void StopServices(this IEnumerable<IService> enumerable,
            bool stopInReverseOrder = true)
        {
            if (stopInReverseOrder)
                enumerable = enumerable?.Reverse();

            enumerable?.ToList().ForEach(service => service.Start());
        }

        /// <summary>
        /// Return an <see cref="IEnumerable{IDisposable}"/>.
        /// </summary>
        /// <param name="enumerable">An enumerable to case</param>
        /// <returns>An enumerable of disposables</returns>
        public static IEnumerable<IDisposable> WhereDisposable(this IEnumerable enumerable)
        {
            var serviceState = enumerable.OfType<IDisposable>();
            return serviceState;
        }

        /// <summary>
        /// Return an <see cref="IEnumerable{TDisposable}"/>.
        /// </summary>
        /// <param name="enumerable">An enumerable to case</param>
        /// <returns>An enumerable of disposables</returns>
        public static IEnumerable<TDisposable> WhereDisposable<TDisposable>(this IEnumerable enumerable) where TDisposable : IDisposable
        {
            var serviceState = enumerable?.OfType<TDisposable>();
            return serviceState;
        }

        /// <summary>
        /// Disposing enumerable of services. 
        /// </summary>
        /// <typeparam name="TService">Heir type from <see cref="IService"/></typeparam>
        /// <param name="enumerable">Collection of services</param>
        public static void DisposeServices<TService>(this IEnumerable<TService> enumerable)
            where TService : IService
        {
            DisposeServices(enumerable.WhereService());
        }

        /// <summary>
        /// Disposing enumerable of <see cref="IService"/>
        /// </summary>
        /// <param name="enumerable">Collection of <see cref="IService"/></param>
        public static void DisposeServices(this IEnumerable<IService> enumerable)
        {
            enumerable?.WhereDisposable().ToList().ForEach(disposable => disposable.Dispose());
        }

        /// <summary>
        /// Clear enumerable if the enumerable is not read only
        /// </summary>
        /// <typeparam name="T">The type of the items in the enumerable</typeparam>
        /// <param name="enumerable">The enumerable to clear</param>
        public static void ClearIfIsNotReadyOnly<T>(this ICollection<T> enumerable)
        {
            if (enumerable?.IsReadOnly == false)
                enumerable.Clear();
        }
        /// <summary>
        /// Try cast safely service to <see cref="IDisposable"/> and call dispose method.
        /// </summary>
        /// <param name="service">A service to dispose</param>
        public static void TryDisposeService(this IService service)
        {
            (service as IDisposable)?.Dispose();
        }
    }
}