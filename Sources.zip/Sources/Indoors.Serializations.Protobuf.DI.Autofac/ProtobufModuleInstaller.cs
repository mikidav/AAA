﻿
using Autofac;
using Indoors.Serializations.Common;

namespace Indoors.Serializations.Protobuf.DI.Autofac
{
    /// <summary>
    /// A autofac container installer that registers Google.Protobuf serializer.
    /// </summary>
    public class ProtobufModuleInstaller : Module
    {
        /// <summary>
        /// Register logic services and interfaces into the supplied container.
        /// </summary>
        /// <param name="builder">The container to hold the services.</param>
        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            RegisterSerializers(builder);

            RegisterDeserializers(builder);
        }

        private static void RegisterSerializers(ContainerBuilder builder)
        {
            builder.RegisterType<ProtobufSerializer>()
                .As<ICustomSerializer>()
                .Named<ProtobufSerializer>(nameof(ProtobufSerializer))
                .SingleInstance();
        }

        private static void RegisterDeserializers(ContainerBuilder builder)
        {
            builder.RegisterType<ProtobufDeserializer>()
                .As<ICustomDeserializer>()
                .UsingConstructor(typeof(IFileDescriptorProvider[]))
                .Named<ProtobufDeserializer>(nameof(ProtobufDeserializer))
                .SingleInstance();
        }
    }
}

