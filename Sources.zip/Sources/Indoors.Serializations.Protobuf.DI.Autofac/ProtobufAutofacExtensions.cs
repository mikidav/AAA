﻿using Autofac;

namespace Indoors.Serializations.Protobuf.DI.Autofac
{
    public static class ProtobufAutofacExtensions
    {
        public static string RegisterFileDescriptorProvider<TFileDescriptorProvider>(this ContainerBuilder builder, string name = null)
            where TFileDescriptorProvider : IFileDescriptorProvider
        {
            var serviceName = name ?? typeof(TFileDescriptorProvider).Name;
            builder.RegisterType<TFileDescriptorProvider>()
                .As<IFileDescriptorProvider, TFileDescriptorProvider>()
                .Named<TFileDescriptorProvider>(serviceName)
                .Named<IFileDescriptorProvider>(serviceName)
                .IfNotRegistered(typeof(TFileDescriptorProvider))
                .SingleInstance();
            return serviceName;
        }
    }
}