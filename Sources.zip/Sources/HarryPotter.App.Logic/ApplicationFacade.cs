﻿using Indoors.Platform.Gateway.Common;
using Indoors.Video.Common;
using Indoors.Video.Common.Facade;

namespace HarryPotter.App.Logic
{
    public class ApplicationFacade : IApplicationFacade
    {
        public IPlatformFacade PlatformFacade { get; }
        public IMultiVideoFacade MultiVideoFacade { get; }

        public ApplicationFacade(IPlatformFacade platformFacade, IMultiVideoFacade multiVideoFacade)
        {
            PlatformFacade = platformFacade;
            MultiVideoFacade = multiVideoFacade;

            PlatformFacade.TakeOffCommand.ForceCanExecute = true;
            PlatformFacade.LandCommand.ForceCanExecute = true;
            PlatformFacade.ArmCommand.ForceCanExecute = true;
            PlatformFacade.DisarmCommand.ForceCanExecute = true;
            PlatformFacade.GoCommand.ForceCanExecute = true;

            const string videoId = "AnAmazingVideo";

            MultiVideoFacade.AddVideo(videoId, VideoTypes.DefaultVideoType);

            MultiVideoFacade.StartVideo(videoId, true);
        }
    }
}