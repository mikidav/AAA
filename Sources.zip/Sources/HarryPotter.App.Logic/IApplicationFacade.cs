﻿using Indoors.Platform.Gateway.Common;
using Indoors.Video.Common.Facade;

namespace HarryPotter.App.Logic
{
    public interface IApplicationFacade
    {
        IPlatformFacade PlatformFacade { get; }
        
        IMultiVideoFacade MultiVideoFacade { get; }
    }
}