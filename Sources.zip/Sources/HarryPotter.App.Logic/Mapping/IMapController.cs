﻿using System;

namespace HarryPotter.App.Logic.Mapping
{

    public interface IMapController
    {
        IObservable<int> MapResetRequested { get; }
        GoToPoint GoToPoint { get; set; }

        void ResetMap();
    }
}