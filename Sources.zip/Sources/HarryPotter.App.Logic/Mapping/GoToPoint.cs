﻿namespace HarryPotter.App.Logic.Mapping
{
    public class GoToPoint
    {
        public int X { get; set; }
        public int Y { get; set; }

        public GoToPoint(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}