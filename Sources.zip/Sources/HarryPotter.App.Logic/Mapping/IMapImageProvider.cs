﻿using Indoors.Services.Common;
using System;

namespace HarryPotter.App.Logic.Mapping
{
    public interface IMapImageProvider<TMap> : IService
    {
        public IObservable<TMap> MapImageUpdated { get; }
    }
}
