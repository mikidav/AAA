﻿using System;
using System.Reactive.Subjects;

namespace HarryPotter.App.Logic.Mapping
{
    public class MapController : IMapController
    {
        private readonly ISubject<int> m_mapResetRequested = new Subject<int>();

        public IObservable<int> MapResetRequested => m_mapResetRequested;

        public GoToPoint GoToPoint { get; set; }

        public void ResetMap()
        {
            m_mapResetRequested.OnNext(0);
        }
    }
}
