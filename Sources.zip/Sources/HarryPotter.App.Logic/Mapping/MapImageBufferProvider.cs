﻿using Indoors.Communications.Common.Subscribers;
using Indoors.Communications.Common.Types;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;
using System;
using System.Reactive.Linq;
using System.Reactive.Subjects;

namespace HarryPotter.App.Logic.Mapping
{
    public class MapImageBufferProvider : ServiceBase, IMapImageProvider<byte[]>
    {
        private IDisposable m_subscriptionDisposable;

        private readonly ISubject<byte[]> m_mapImageUpdatedSubject = new Subject<byte[]>();

        public IObservable<byte[]> MapImageUpdated => m_mapImageUpdatedSubject;

        public IBufferSubscriber<byte[]> Subscriber { get; private set; }


        public MapImageBufferProvider(IBufferSubscriber<byte[]> subscriber, ILogger logger = null, string id = null) : base(logger, id)
        {
            Subscriber = subscriber;
        }

        protected override void InternalInitialize()
        {
            Subscriber.Initialize();
        }

        protected override void InternalStart()
        {
            m_subscriptionDisposable = Subscriber.BufferReceived.Where(_ => IsRunning).Subscribe(OnBufferSubscribed);

            Subscriber.Start();
        }

        protected override void InternalStop()
        {
            m_subscriptionDisposable?.Dispose();
            m_subscriptionDisposable = null;

            Subscriber?.Stop();
        }

        protected override void InnerManagedDispose()
        {
            Subscriber?.TryDisposeService();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Subscriber = null;

            base.InnerNullifyReferencesDispose();
        }

        private void OnBufferSubscribed(BufferData<byte[]> bufferData)
        {
            if (bufferData?.Buffer == null)
                return;

            m_mapImageUpdatedSubject.OnNext(bufferData.Buffer);
        }
    }
}
