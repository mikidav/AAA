﻿using Indoors.Services.Common;
using System;
using System.IO;
using System.Reactive.Subjects;
using System.Threading.Tasks;

namespace HarryPotter.App.Logic.Mapping
{
    public class MapImageBufferDemoProvider : ServiceBase, IMapImageProvider<byte[]>
    {
        private readonly ISubject<byte[]> m_mapImageUpdatedSubject = new Subject<byte[]>();

        public IObservable<byte[]> MapImageUpdated => m_mapImageUpdatedSubject;

        public MapImageBufferDemoProvider()
        {

        }

        protected override void InternalInitialize()
        {
        }

        protected override void InternalStart()
        {
            Task.Run(async () =>
            {
                while (true)
                {
                    await Task.Delay(2000);
                    try
                    {
                        var newBuff = File.ReadAllBytes(@"C:\IndoorsData\map_nahsholim1.png");
                        m_mapImageUpdatedSubject.OnNext(newBuff);
                    }
                    catch (Exception ex)
                    {

                    }
                }
            });
        }

        protected override void InternalStop()
        {

        }
    }
}
