﻿namespace HarryPotter.App.Logic.Platforms
{
    public interface IPlatformControlSettings
    {
        double DefaultHeightChangeMeters { get; }
        double DefaultMovementDistanceMeters { get; }
        double DefaultTakeOffHeightMeters { get; }
        double DefaultYawChangeDegrees { get; }
    }
}