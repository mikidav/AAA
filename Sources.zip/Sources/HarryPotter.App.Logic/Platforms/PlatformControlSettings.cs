﻿namespace HarryPotter.App.Logic.Platforms
{
    public class PlatformControlSettings : IPlatformControlSettings
    {
        public double DefaultTakeOffHeightMeters { get; set; }
        public double DefaultMovementDistanceMeters { get; set; }
        public double DefaultHeightChangeMeters { get; set; }
        public double DefaultYawChangeDegrees { get; set; }
    }
}
