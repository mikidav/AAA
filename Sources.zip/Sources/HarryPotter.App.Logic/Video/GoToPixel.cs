﻿namespace HarryPotter.App.Logic.Video
{
    public class GoToPixel
    {
        public string FrameId { get; set; }
        public double X { get; set; }
        public double Y { get; set; }

        public GoToPixel(double x, double y) : this(string.Empty, x, y)
        {
        }

        public GoToPixel(string frameId, double x, double y)
        {
            FrameId = frameId;
            X = x;
            Y = y;
        }
    }
}