﻿using Indoors.Gateways.Common.DeviceAdapters;
using Indoors.Gateways.Common.Settings;
using Indoors.Services.Common;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Logging;

namespace Indoors.Gateways.Common
{
    public class Gateway : CompositeServiceBase, IGateway
    {
        public IGatewaySettings GatewaySettings { get; }
        public IList<IDeviceAdapter> DeviceAdapters { get; protected set; }

        public Gateway(IGatewaySettings gatewaySettings, 
            IEnumerable<IDeviceAdapter> deviceAdapters = null,
            ILogger<Gateway> logger = null, 
            string id = null)
        : base(logger, id)
        {
            GatewaySettings = gatewaySettings;
            DeviceAdapters = deviceAdapters?.ToList() ?? Enumerable.Empty<IDeviceAdapter>().ToList();
        }

        protected override IEnumerable<IService> GetServices()
        {
            return DeviceAdapters.WhereService();
        }
    }
}
