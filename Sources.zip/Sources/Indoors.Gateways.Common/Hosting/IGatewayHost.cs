﻿using Indoors.Services.Common;

namespace Indoors.Gateways.Common.Hosting
{
    public interface IGatewayHost : IService
    {
        IGateway Gateway { get; }

    }
}
