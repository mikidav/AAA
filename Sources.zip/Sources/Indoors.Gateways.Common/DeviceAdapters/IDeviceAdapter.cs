﻿using Indoors.Services.Common;

namespace Indoors.Gateways.Common.DeviceAdapters
{
    public interface IDeviceAdapter : IService
    {

    }
}
