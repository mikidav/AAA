﻿namespace Indoors.Gateways.Common.Settings
{
    public class GatewaySettings : IGatewaySettings
    {
        public string Id { get; set; }
    }
}
