﻿namespace Indoors.Gateways.Common.Settings
{
    public interface IGatewaySettings
    {
        string Id { get; }
    }
}
