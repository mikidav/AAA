﻿using System.Collections.Generic;
using System.Linq;
using Indoors.Gateways.Common.DeviceAdapters;
using Indoors.Gateways.Common.Settings;

namespace Indoors.Gateways.Common.Builders
{
    public class InjectionBasedGatewayBuilder : ICustomGatewayBuilder
    {
        public IGatewaySettings GatewaySettings { get; }
        public IList<IDeviceAdapter> DeviceAdapters { get; }

        public InjectionBasedGatewayBuilder(IGatewaySettings gatewaySettings, IEnumerable<IDeviceAdapter> deviceAdapters = null)
        {
            GatewaySettings = gatewaySettings;
            DeviceAdapters = deviceAdapters?.ToList() ?? Enumerable.Empty<IDeviceAdapter>().ToList();
        }

        public IGateway BuildGateway()
        {
            var gateway = new Gateway(GatewaySettings, DeviceAdapters);
            return gateway;
        }
    }
}
