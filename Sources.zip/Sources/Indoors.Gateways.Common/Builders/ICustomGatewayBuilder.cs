﻿namespace Indoors.Gateways.Common.Builders
{
    public interface ICustomGatewayBuilder
    {
        IGateway BuildGateway();
    }
}
