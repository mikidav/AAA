﻿using Indoors.Services.Common;

namespace Indoors.Gateways.Common
{
    public interface IGateway : IService
    {
    }
}
