﻿using System;
using MessageNavigationModeEnum = Indoors.DomainIcd.Platform.Messages.NavigationModeEnum;
using CommandNavigationModeEnum = Indoors.Platform.Gateway.Common.Types.NavigationModeEnum;

namespace Indoors.Platform.Gateway.Adapter.Types
{
    public static class NavigationModeEnumAdapter
    {
        public static MessageNavigationModeEnum ToMessage(
            this CommandNavigationModeEnum messageEnum)
        {
            return messageEnum switch
            {
                CommandNavigationModeEnum.Unknown => MessageNavigationModeEnum.Unknown,
                CommandNavigationModeEnum.Indoors => MessageNavigationModeEnum.Indoors,
                CommandNavigationModeEnum.Outdoors => MessageNavigationModeEnum.Outdoors,
                _ => throw new ArgumentOutOfRangeException(nameof(messageEnum), messageEnum, null)
            };
        }

        public static CommandNavigationModeEnum ToCommand(
            this MessageNavigationModeEnum messageEnum)
        {
            return messageEnum switch
            {
                MessageNavigationModeEnum.Unknown  => CommandNavigationModeEnum.Unknown,
                MessageNavigationModeEnum.Indoors => CommandNavigationModeEnum.Indoors,
                MessageNavigationModeEnum.Outdoors => CommandNavigationModeEnum.Outdoors,
                _ => throw new ArgumentOutOfRangeException(nameof(messageEnum), messageEnum, null)
            };
        }
    }
}