﻿using System;
using MessageOperationalModeEnum = Indoors.DomainIcd.Platform.Messages.OperationalModeEnum;
using CommandOperationalModeEnum = Indoors.Platform.Gateway.Common.Types.OperationalModeEnum;

namespace Indoors.Platform.Gateway.Adapter.Types
{
    public static class OperationalModeEnumAdapter
    {
        public static MessageOperationalModeEnum ToMessage(
            this CommandOperationalModeEnum messageEnum)
        {
            return messageEnum switch
            {
                CommandOperationalModeEnum.ExplorationStart => MessageOperationalModeEnum.ExplorationStart,
                CommandOperationalModeEnum.ExplorationStop => MessageOperationalModeEnum.ExplorationStop,
                CommandOperationalModeEnum.ManualStart => MessageOperationalModeEnum.ManualStart,
                CommandOperationalModeEnum.ManualStop => MessageOperationalModeEnum.ManualStop,
                _ => throw new ArgumentOutOfRangeException(nameof(messageEnum), messageEnum, null)
            };
        }

        public static CommandOperationalModeEnum ToCommand(
            this MessageOperationalModeEnum messageEnum)
        {
            return messageEnum switch
            {
                MessageOperationalModeEnum.ExplorationStart => CommandOperationalModeEnum.ExplorationStart,
                MessageOperationalModeEnum.ExplorationStop => CommandOperationalModeEnum.ExplorationStop,
                MessageOperationalModeEnum.ManualStart => CommandOperationalModeEnum.ManualStart,
                MessageOperationalModeEnum.ManualStop => CommandOperationalModeEnum.ManualStop,
                _ => throw new ArgumentOutOfRangeException(nameof(messageEnum), messageEnum, null)
            };
        }
    }
}