﻿using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public class PlatformDomainIcdDisarmCommandAdapter : IPlatformDomainIcdCommandMessageAdapter<PlatformDisarmCommandParameters, PlatformDisarmCommandMessage>
    {
        public PlatformDisarmCommandMessage ToMessage(string operationId, PlatformDisarmCommandParameters commandParameter)
        {
            var message = new PlatformDisarmCommandMessage
            {
                CommandId = operationId,
                PlatformId = commandParameter?.PlatformId
            };

            return message;
        }

        public (string operationId, PlatformDisarmCommandParameters) ToCommandParameter(PlatformDisarmCommandMessage message)
        {
            if (message == null)
                return (null, null);

            var parameters = new PlatformDisarmCommandParameters
            {
                PlatformId = message.PlatformId,
            };

            return (message.CommandId, parameters);
        }
    }
}