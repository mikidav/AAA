﻿using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public class PlatformDomainIcdSystemBootCommandAdapter : IPlatformDomainIcdCommandMessageAdapter<PlatformSystemBootCommandParameters, PlatformSystemBootCommandMessage>
    {
        public PlatformSystemBootCommandMessage ToMessage(string operationId, PlatformSystemBootCommandParameters commandParameter)
        {
            var message = new PlatformSystemBootCommandMessage
            {
                CommandId = operationId,
                PlatformId = commandParameter?.PlatformId
            };

            return message;
        }

        public (string operationId, PlatformSystemBootCommandParameters) ToCommandParameter(PlatformSystemBootCommandMessage message)
        {
            if (message == null)
                return (null, null);

            var parameters = new PlatformSystemBootCommandParameters
            {
                PlatformId = message.PlatformId,
            };

            return (message.CommandId, parameters);
        }
    }
}