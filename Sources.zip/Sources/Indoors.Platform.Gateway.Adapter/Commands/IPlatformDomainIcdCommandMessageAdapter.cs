﻿using Indoors.Commands.Messages.Common;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public interface IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
        : ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage> 
            where TCommandParameter : IPlatformCommandParameter
            where TCommandDomainMessage : class
    {

    }
}