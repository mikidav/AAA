﻿using Indoors.DomainIcd.Entities.Adapters;
using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public class PlatformDomainIcdGoToCommandAdapter : IPlatformDomainIcdCommandMessageAdapter<PlatformGoToCommandParameters, PlatformGoToCommandMessage>
    {
        public PlatformGoToCommandMessage ToMessage(string operationId, PlatformGoToCommandParameters commandParameter)
        {
            if (commandParameter == null)
                return null;
            var message = new PlatformGoToCommandMessage
            {
                CommandId = operationId,
                PlatformId = commandParameter.PlatformId,
                GoToData = new PlatformGoToStruct
                {
                    Location = commandParameter.Location.ToMessage(),
                }
            };
            return message;
        }

        public (string operationId, PlatformGoToCommandParameters) ToCommandParameter(PlatformGoToCommandMessage message)
        {
            if (message?.GoToData == null)
                return (message?.CommandId, null);

            var parameter = new PlatformGoToCommandParameters
            {
                PlatformId = message.PlatformId,
                Location = message.GoToData.Location.ToType()
            };

            return (message.CommandId, parameter);
        }
    }
}