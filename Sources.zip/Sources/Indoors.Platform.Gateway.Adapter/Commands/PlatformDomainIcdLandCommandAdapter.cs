﻿using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public class PlatformDomainIcdLandCommandAdapter : IPlatformDomainIcdCommandMessageAdapter<PlatformLandCommandParameters, PlatformLandCommandMessage>
    {
        public PlatformLandCommandMessage ToMessage(string operationId, PlatformLandCommandParameters commandParameter)
        {
            var message = new PlatformLandCommandMessage
            {
                CommandId = operationId,
                PlatformId = commandParameter?.PlatformId
            };

            return message;
        }

        public (string operationId, PlatformLandCommandParameters) ToCommandParameter(PlatformLandCommandMessage message)
        {
            if (message == null)
                return (null, null);

            var parameters = new PlatformLandCommandParameters
            {
                PlatformId = message.PlatformId,
            };

            return (message.CommandId, parameters);
        }
    }
}