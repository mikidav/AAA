﻿using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public class PlatformDomainIcdRecoverCommandAdapter : IPlatformDomainIcdCommandMessageAdapter<PlatformRecoverCommandParameters, PlatformRecoverCommandMessage>
    {
        public PlatformRecoverCommandMessage ToMessage(string operationId, PlatformRecoverCommandParameters commandParameter)
        {
            var message = new PlatformRecoverCommandMessage
            {
                CommandId = operationId,
                PlatformId = commandParameter?.PlatformId
            };

            return message;
        }

        public (string operationId, PlatformRecoverCommandParameters) ToCommandParameter(PlatformRecoverCommandMessage message)
        {
            if (message == null)
                return (null, null);

            var parameters = new PlatformRecoverCommandParameters
            {
                PlatformId = message.PlatformId,
            };

            return (message.CommandId, parameters);
        }
    }
}