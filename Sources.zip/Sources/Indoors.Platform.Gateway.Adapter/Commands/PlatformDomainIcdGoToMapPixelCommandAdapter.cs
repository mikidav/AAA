﻿using Indoors.DomainIcd.Entities.Adapters;
using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public class PlatformDomainIcdGoToMapPixelCommandAdapter : IPlatformDomainIcdCommandMessageAdapter<PlatformGoToMapPixelCommandParameters, PlatformGoToMapPixelCommandMessage>
    {
        public PlatformGoToMapPixelCommandMessage ToMessage(string operationId, PlatformGoToMapPixelCommandParameters commandParameter)
        {
            if (commandParameter == null)
                return null;

            var message = new PlatformGoToMapPixelCommandMessage
            {
                CommandId = operationId,
                PlatformId = commandParameter.PlatformId,
                GoToMapPixelData = new PlatformGoToMapPixelStruct
                {
                    Location = commandParameter.Location.ToMessage(),
                }
            };
            return message;
        }

        public (string operationId, PlatformGoToMapPixelCommandParameters) ToCommandParameter(PlatformGoToMapPixelCommandMessage message)
        {
            if (message?.GoToMapPixelData == null)
                return (message?.CommandId, null);

            var parameter = new PlatformGoToMapPixelCommandParameters
            {
                PlatformId = message.PlatformId,
                Location = message.GoToMapPixelData.Location.ToType()
            };

            return (message.CommandId, parameter);
        }
    }
}