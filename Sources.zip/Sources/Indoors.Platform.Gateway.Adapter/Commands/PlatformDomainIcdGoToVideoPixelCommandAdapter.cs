﻿using Indoors.DomainIcd.Entities.Adapters;
using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public class PlatformDomainIcdGoToVideoPixelCommandAdapter : IPlatformDomainIcdCommandMessageAdapter<PlatformGoToVideoPixelCommandParameters, PlatformGoToVideoPixelCommandMessage>
    {
        public PlatformGoToVideoPixelCommandMessage ToMessage(string operationId, PlatformGoToVideoPixelCommandParameters commandParameter)
        {
            if (commandParameter == null)
                return null;

            var message = new PlatformGoToVideoPixelCommandMessage
            {
                CommandId = operationId,
                PlatformId = commandParameter.PlatformId,
                GoToVideoPixelData = new PlatformGoToVideoPixelStruct
                {
                    Location = commandParameter.Location.ToMessage(),
                    FrameId = commandParameter.FrameId
                }
            };
            return message;
        }

        public (string operationId, PlatformGoToVideoPixelCommandParameters) ToCommandParameter(PlatformGoToVideoPixelCommandMessage message)
        {
            if (message?.GoToVideoPixelData == null)
                return (message?.CommandId, null);

            var parameter = new PlatformGoToVideoPixelCommandParameters
            {
                PlatformId = message.PlatformId,
                Location = message.GoToVideoPixelData.Location.ToType(),
                FrameId = message.GoToVideoPixelData.FrameId
            };

            return (message.CommandId, parameter);
        }
    }
}