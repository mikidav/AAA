﻿using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Adapter.Types;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public class PlatformDomainIcdSetOperationalModeCommandAdapter : IPlatformDomainIcdCommandMessageAdapter<PlatformSetOperationalModeCommandParameters, PlatformSetOperationalModeCommandMessage>
    {
        public PlatformSetOperationalModeCommandMessage ToMessage(string operationId, PlatformSetOperationalModeCommandParameters commandParameter)
        {
            if (commandParameter == null)
                return null;

            var message = new PlatformSetOperationalModeCommandMessage
            {
                CommandId = operationId,
                PlatformId = commandParameter.PlatformId,
                SetOperationalModeData = new PlatformSetOperationalModeStruct
                {
                    Mode = commandParameter.Mode.ToMessage()
                }
            };
            return message;
        }

        public (string operationId, PlatformSetOperationalModeCommandParameters) ToCommandParameter(PlatformSetOperationalModeCommandMessage message)
        {
            if (message?.SetOperationalModeData == null)
                return (message?.CommandId, null);

            var parameter = new PlatformSetOperationalModeCommandParameters
            {
                PlatformId = message.PlatformId,
                Mode = message.SetOperationalModeData.Mode.ToCommand()
            };

            return (message.CommandId, parameter);
        }
    }
}