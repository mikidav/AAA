﻿using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public class PlatformDomainIcdReturnHomeCommandAdapter : IPlatformDomainIcdCommandMessageAdapter<PlatformReturnHomeCommandParameters, PlatformReturnHomeCommandMessage>
    {
        public PlatformReturnHomeCommandMessage ToMessage(string operationId, PlatformReturnHomeCommandParameters commandParameter)
        {
            var message = new PlatformReturnHomeCommandMessage
            {
                CommandId = operationId,
                PlatformId = commandParameter?.PlatformId
            };

            return message;
        }

        public (string operationId, PlatformReturnHomeCommandParameters) ToCommandParameter(PlatformReturnHomeCommandMessage message)
        {
            if (message == null)
                return (null, null);

            var parameters = new PlatformReturnHomeCommandParameters
            {
                PlatformId = message.PlatformId,
            };

            return (message.CommandId, parameters);
        }
    }
}