﻿using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public class PlatformDomainIcdTakeOffCommandAdapter : IPlatformDomainIcdCommandMessageAdapter<PlatformTakeOffCommandParameters, PlatformTakeoffCommandMessage>
    {
        public PlatformTakeoffCommandMessage ToMessage(string operationId, PlatformTakeOffCommandParameters commandParameter)
        {
            var message = new PlatformTakeoffCommandMessage
            {
                CommandId = operationId,
                PlatformId = commandParameter?.PlatformId,
                TakeoffData = new PlatformTakeoffStruct
                {
                    TakeoffHeightMeters = commandParameter?.HeightMeters ?? 0
                }
            };
            return message;
        }

        public (string operationId, PlatformTakeOffCommandParameters) ToCommandParameter(PlatformTakeoffCommandMessage message)
        {
            if (message == null)
                return (null, null);

            var parameter = new PlatformTakeOffCommandParameters
            {
                PlatformId = message.PlatformId,
                HeightMeters = message.TakeoffData?.TakeoffHeightMeters ?? 0
            };

            return (message.CommandId, parameter);
        }
    }
}