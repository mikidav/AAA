﻿using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public class PlatformDomainIcdMoveCommandAdapter : IPlatformDomainIcdCommandMessageAdapter<PlatformMoveCommandParameters, PlatformMoveCommandMessage>
    {
        public PlatformMoveCommandMessage ToMessage(string operationId, PlatformMoveCommandParameters commandParameter)
        {
            if (commandParameter == null)
                return null;

            var message = new PlatformMoveCommandMessage
            {
                CommandId = operationId,
                PlatformId = commandParameter.PlatformId,
                MoveData = new PlatformMoveStruct
                {
                    AngleXYDegrees = commandParameter.AngleXYDegrees,
                    DistanceXMeters = commandParameter.DistanceXMeters,
                    DistanceYMeters = commandParameter.DistanceYMeters,
                    DistanceZMeters = commandParameter.DistanceZMeters,
                }
            };

            return message;
        }

        public (string operationId, PlatformMoveCommandParameters) ToCommandParameter(PlatformMoveCommandMessage message)
        {
            if (message?.MoveData == null)
                return (message?.CommandId, null);

            var parameter = new PlatformMoveCommandParameters
            {
                PlatformId = message.PlatformId,
                AngleXYDegrees = message.MoveData.AngleXYDegrees,
                DistanceXMeters = message.MoveData.DistanceXMeters,
                DistanceYMeters = message.MoveData.DistanceYMeters,
                DistanceZMeters = message.MoveData.DistanceZMeters
            };

            return (message.CommandId, parameter);
        }
    }
}