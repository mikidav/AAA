﻿using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Adapter.Types;
using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Adapter.Commands
{
    public class PlatformDomainIcdSetNavigationModeCommandAdapter : IPlatformDomainIcdCommandMessageAdapter<PlatformSetNavigationModeCommandParameters, PlatformSetNavigationModeCommandMessage>
    {
        public PlatformSetNavigationModeCommandMessage ToMessage(string operationId, PlatformSetNavigationModeCommandParameters commandParameter)
        {
            if (commandParameter == null)
                return null;

            var message = new PlatformSetNavigationModeCommandMessage
            {
                CommandId = operationId,
                PlatformId = commandParameter.PlatformId,
                NavigationModeData = new PlatformSetNavigationModeStruct
                {
                    Mode = commandParameter.Mode.ToMessage()
                }
            };
            return message;
        }

        public (string operationId, PlatformSetNavigationModeCommandParameters) ToCommandParameter(PlatformSetNavigationModeCommandMessage message)
        {
            if (message?.NavigationModeData == null)
                return (message?.CommandId, null);

            var parameter = new PlatformSetNavigationModeCommandParameters
            {
                PlatformId = message.PlatformId,
                Mode = message.NavigationModeData.Mode.ToCommand()
            };

            return (message.CommandId, parameter);
        }
    }
}