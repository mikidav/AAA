﻿using System;
using Indoors.MissionManagement.Common.CommandParameters;

namespace Indoors.MissionManagement.Common.IFC
{
    public interface ICommandEventAggregator
    {
        IObservable<IMissionCommandParameters> CommandArrivedObservable { get; }
    }
}
