﻿using Indoors.Commands.Common;
using Indoors.MissionManagement.Common.CommandParameters;

namespace Indoors.MissionManagement.Common.Commands
{
    public interface IMissionGeneralCommand<TCommandParameter> : ICommand<TCommandParameter>
        where TCommandParameter : IMissionCommandParameters
    {

    }
}