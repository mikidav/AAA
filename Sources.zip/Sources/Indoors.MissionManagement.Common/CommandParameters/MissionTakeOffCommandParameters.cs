﻿namespace Indoors.MissionManagement.Common.CommandParameters
{
    public class MissionTakeOffCommandParameters : MissionCommandParameters
    {
        /// <summary>
        /// A unique value for identifying the platform for which the command is intended.<br />
        /// for all the platforms use "*"
        /// </summary>
        public string PlatformId { get; set; }
        
        public double HeightMeters { get; set; }

        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(PlatformId)}: {PlatformId}, {nameof(HeightMeters)}: {HeightMeters}";
        }
    }
}