﻿namespace Indoors.MissionManagement.Common.CommandParameters
{
    public interface IMissionCommandParameters
    {
        /// <summary>
        /// A unique value for identifying the mission for which the command is intended.<br />
        /// this field is mandatory
        /// </summary>
        string MissionId { get; }

        bool IsMissionIdIdValid { get; }
    }
}