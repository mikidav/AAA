﻿namespace Indoors.MissionManagement.Common.CommandParameters
{
    public class MissionStartCommandParameters : MissionCommandParameters
    {
        
    }
}
