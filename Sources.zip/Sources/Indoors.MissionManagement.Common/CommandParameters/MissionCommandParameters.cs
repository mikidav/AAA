﻿namespace Indoors.MissionManagement.Common.CommandParameters
{
    public class MissionCommandParameters : IMissionCommandParameters
    {
        public string MissionId { get; set; }

        public virtual bool IsMissionIdIdValid => string.IsNullOrEmpty(MissionId);

        public override string ToString()
        {
            return $"{nameof(MissionId)}: {MissionId}";
        }
    }
}