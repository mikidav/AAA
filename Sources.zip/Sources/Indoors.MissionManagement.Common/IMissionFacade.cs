﻿using Indoors.MissionManagement.Common.CommandParameters;
using Indoors.MissionManagement.Common.Commands;

namespace Indoors.MissionManagement.Common
{
    public interface IMissionFacade
    {
        IMissionGeneralCommand<MissionStartCommandParameters> MissionStartCommand { get; }
        IMissionGeneralCommand<MissionStopCommandParameters> MissionStopCommand { get; }
        IMissionGeneralCommand<MissionTakeOffCommandParameters> MissionTakeOffCommand { get; }
        IMissionGeneralCommand<MissionLandCommandParameters> MissionLandCommand { get; }
    }
}