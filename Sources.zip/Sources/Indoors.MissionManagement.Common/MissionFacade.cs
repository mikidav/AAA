﻿using Indoors.MissionManagement.Common.CommandParameters;
using Indoors.MissionManagement.Common.Commands;

namespace Indoors.MissionManagement.Common
{
    public class MissionFacade : IMissionFacade
    {
        public IMissionGeneralCommand<MissionStartCommandParameters> MissionStartCommand { get; }
        public IMissionGeneralCommand<MissionStopCommandParameters> MissionStopCommand { get; }
        public IMissionGeneralCommand<MissionTakeOffCommandParameters> MissionTakeOffCommand { get; }
        public IMissionGeneralCommand<MissionLandCommandParameters> MissionLandCommand { get; }
        
        public MissionFacade(
            IMissionGeneralCommand<MissionStartCommandParameters> missionStartCommand,
            IMissionGeneralCommand<MissionStopCommandParameters> missionStopCommand,
            IMissionGeneralCommand<MissionTakeOffCommandParameters> missionTakeOffCommand,
            IMissionGeneralCommand<MissionLandCommandParameters> missionLandCommand)
        {
            MissionStartCommand = missionStartCommand;
            MissionStopCommand = missionStopCommand;
            MissionTakeOffCommand = missionTakeOffCommand;
            MissionLandCommand = missionLandCommand;
        }

    }
}