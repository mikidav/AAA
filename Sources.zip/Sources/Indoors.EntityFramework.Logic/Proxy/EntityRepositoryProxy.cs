﻿using Indoors.EntityFramework.Common.Data;
using Indoors.EntityFramework.Entities.Base;
using Indoors.EntityFramework.Entities.Enums;
using Indoors.EntityFramework.Logic.Common;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Reactive.Subjects;
using System.Threading;
using System.Threading.Tasks;
using Indoors.EntityFramework.Common.Proxy;

namespace Indoors.EntityFramework.Logic.Proxy
{
    public class EntityRepositoryProxy : EntityRepository, IEntityRepositoryAggregator
    {
        private readonly ISubject<NotificationData> _notificationSubject = new Subject<NotificationData>();
        private readonly ISubject<Guid> _loadRequestSubject = new Subject<Guid>();

        //EventAggregator notifications
        private readonly ISubject<IEntity> _addedSubject = new Subject<IEntity>();
        private readonly ISubject<IEntity> _updatedSubject = new Subject<IEntity>();
        private readonly ISubject<IEntity> _deletedSubject = new Subject<IEntity>();

        public IObservable<IEntity> AddedObservable => _addedSubject;
        public IObservable<IEntity> UpdatedObservable => _updatedSubject;
        public IObservable<IEntity> DeletedObservable => _deletedSubject;

        //Outgoing notification - update the world
        public IObservable<NotificationData> NotificationObservable => _notificationSubject;
        //Request for load the proxy from the entity management service
        public IObservable<Guid> LoadRequestObservable => _loadRequestSubject;

        public EntityRepositoryProxy(ILogger<EntityRepositoryProxy> logger = null, string id = null)
            : base(logger, id)
        {
        }

        protected override void InternalStart()
        {
            base.InternalStart();

            _loadRequestSubject.OnNext(Guid.NewGuid());
        }

        protected override void InternalAddAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default)
        {
            //Notify to all
            var notificationData = new NotificationData
            {
                Type = NotificationTypeEnum.Added,
                Entity = entity
            };

            _notificationSubject.OnNext(notificationData);
        }

        protected override void InternalUpdateAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default)
        {
            //Notify to all
            var notificationData = new NotificationData
            {
                Type = NotificationTypeEnum.Updated,
                Entity = entity
            };

            _notificationSubject.OnNext(notificationData);
        }

        protected override void InternalDeleteAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default)
        {
            //Notify to all
            var notificationData = new NotificationData
            {
                Type = NotificationTypeEnum.Deleted,
                Entity = entity
            };

            _notificationSubject.OnNext(notificationData);
        }

        public void AddTypeToRepository(Type type)
        {
            if (!Repository.TryAdd(type, new ConcurrentDictionary<Guid, IEntity>()))
            {
                Logger.LogWarning($"The type {type} already registered to the repository");
                return;
            }

            Logger.LogInformation($"The type {type} registered to the repository");
        }

        public void Load<TEntity>(OperationData data)
            where TEntity : class, IEntity
        {
            if (data.Entities == null || !data.Entities.Any())
            {
                Logger.LogInformation($"There is no entities of type {typeof(TEntity)} to load");
                return;
            }

            if (!Repository.ContainsKey(typeof(TEntity)))
            {
                Logger.LogError($"Could not add or update the repository : " +
                        $"the type {typeof(TEntity)} is not registered");
                return;
            }

            Logger.LogInformation($"Start loading the repository for {typeof(TEntity)} from external source");

            data.Entities.ToList().ForEach(e =>
            {
                Repository[typeof(TEntity)].TryAdd(e.Id, e);
                Logger.LogInformation($"Added entity {e} to local repository");
            });

            Logger.LogInformation($"Finished loading the repository for {typeof(TEntity)} from external source");
        }

        public async Task NotifyAsync<TEntity>(NotificationData data, CancellationToken cancellationToken = default)
            where TEntity : class, IEntity
        {
            await Task.Factory.StartNew(() =>
            {
                var isOperationSucceeded = Repository.TryGetValue(typeof(TEntity), out var repository);

                if (!isOperationSucceeded)
                {
                    Logger.LogError($"Notify: Operation on entity {data.Entity} failed " +
                        $"the type {typeof(TEntity)} is not registered");
                    return;
                }

                switch (data.Type)
                {
                    case NotificationTypeEnum.Added:
                        isOperationSucceeded = repository.TryAdd(data.Entity.Id, data.Entity);
                        break;
                    case NotificationTypeEnum.Updated:
                        isOperationSucceeded = repository.AddOrUpdate(data.Entity.Id, data.Entity, (id, old) => data.Entity) != null;
                        break;
                    case NotificationTypeEnum.Deleted:
                        isOperationSucceeded = repository.TryRemove(data.Entity.Id, out _);
                        break;
                    default:
                        Logger.LogError($"Unknown notification type: {data.Type}");
                        break;
                }

                if (!isOperationSucceeded)
                {
                    Logger.LogError($"Notify: Operation {data.Type} Failed on entity {data.Entity}");
                    return;
                }

                Publish(data.Entity, data.Type);

            }, cancellationToken, TaskCreationOptions.LongRunning, TaskScheduler.Default);
        }

        public void Publish(IEntity entity, NotificationTypeEnum type)
        {
            switch (type)
            {
                case NotificationTypeEnum.Added:
                    _addedSubject.OnNext(entity);
                    break;
                case NotificationTypeEnum.Updated:
                    _updatedSubject.OnNext(entity);
                    break;
                case NotificationTypeEnum.Deleted:
                    _deletedSubject.OnNext(entity);
                    break;
            }
        }
    }
}
