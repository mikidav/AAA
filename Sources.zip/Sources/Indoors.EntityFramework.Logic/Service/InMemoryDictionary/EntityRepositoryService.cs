﻿using Indoors.EntityFramework.Common.Data;
using Indoors.EntityFramework.Entities.Base;
using Indoors.EntityFramework.Entities.Enums;
using Indoors.EntityFramework.Logic.Common;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Reactive.Subjects;
using System.Threading;
using System.Threading.Tasks;
using Indoors.EntityFramework.Common.Service;

namespace Indoors.EntityFramework.Logic.Service.InMemoryDictionary
{
    public class EntityRepositoryService : EntityRepository, IEntityRepositoryService
    {
        private readonly ISubject<OperationData> _allEntitiesSubject = new Subject<OperationData>();

        public IObservable<OperationData> AllEntitiesObservable => _allEntitiesSubject;

        public EntityRepositoryService(ILogger<EntityRepositoryService> logger = null)
            : base(logger)
        {
        }

        public void AddTypeToRepository(Type type)
        {
            if (!Repository.TryAdd(type, new ConcurrentDictionary<Guid, IEntity>()))
            {
                Logger.LogWarning($"The type {type} already registered to the repository");
                return;
            }

            Logger.LogInformation($"The type {type} registered to the repository");
        }

        public async Task FireAllAsync<TEntity>(Guid correlationId, CancellationToken cancellationToken = default)
            where TEntity : class, IEntity
        {
            var entities = await GetAsync<TEntity>(cancellationToken);

            var getAllData = new OperationData()
            {
                CorrelationId = correlationId,
                Entities = entities ?? new List<TEntity>(),
                EntityType = typeof(TEntity)
            };

            _allEntitiesSubject.OnNext(getAllData);
        }

        public async Task HandleNotificationAsync<TEntity>(TEntity entity, NotificationTypeEnum notificationType,
            CancellationToken cancellationToken = default)
            where TEntity : class, IEntity
        {
            switch (notificationType)
            {
                case NotificationTypeEnum.Added:
                    await AddAsync<TEntity>(entity, cancellationToken);
                    break;
                case NotificationTypeEnum.Updated:
                    await UpdateAsync<TEntity>(entity, cancellationToken);
                    break;
                case NotificationTypeEnum.Deleted:
                    await DeleteAsync<TEntity>(entity, cancellationToken);
                    break;
                default:
                    Logger.LogError($"Unsupported notification type: {notificationType}");
                    break;
            }
        }
    }
}
