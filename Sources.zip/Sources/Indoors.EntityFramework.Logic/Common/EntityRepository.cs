﻿using Indoors.EntityFramework.Common;
using Indoors.EntityFramework.Entities.Base;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Indoors.EntityFramework.Logic.Common
{
    /// <summary>
    /// Base repository for handling the CRUD operations
    /// This implementation using ConcurrentDictionary for caching
    /// </summary>
    public abstract class EntityRepository : ServiceBase, IEntityRepository
    {
        protected ConcurrentDictionary<Type, ConcurrentDictionary<Guid, IEntity>> Repository = new ConcurrentDictionary<Type, ConcurrentDictionary<Guid, IEntity>>();

        protected EntityRepository(ILogger<EntityRepository> logger = null, string id = null)
            : base(logger, id)
        {
        }

        protected override void InternalInitialize()
        {
        }

        protected override void InternalStart()
        {
        }

        protected override void InternalStop()
        {
        }

        public async Task AddAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default)
            where TEntity : class, IEntity
        {
            await Task.Run(() =>
            {
                var result = Repository.TryGetValue(typeof(TEntity), out var repository);
                if (!result)
                {
                    Logger.LogError($"Could not add entity {entity} to the repository: the type {typeof(TEntity)} is not registered");
                    return;
                }

                result = repository.TryAdd(entity.Id, entity);
                if (!result)
                {
                    Logger.LogError($"Failed to add entity {entity} to the repository");
                    return;
                }

                Logger.LogDebug($"The entity {entity} added to the repository");

                InternalAddAsync(entity, cancellationToken);
            }, cancellationToken);
        }

        public async Task UpdateAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default)
            where TEntity : class, IEntity
        {
            await Task.Run(() =>
            {
                var result = Repository.TryGetValue(typeof(TEntity), out var repository);
                if (!result)
                {
                    Logger.LogError($"Could not update entity {entity} from the repository : " +
                        $"the type {typeof(TEntity)} is not registered");
                    return;
                }

                var updatedEntity = repository.AddOrUpdate(entity.Id, entity, (id, old) => entity);

                Logger.LogDebug($"The entity {updatedEntity} updated in the repository");

                InternalUpdateAsync(entity, cancellationToken);

            }, cancellationToken);
        }

        public async Task DeleteAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default)
            where TEntity : class, IEntity
        {
            await Task.Run(() =>
            {
                var result = Repository.TryGetValue(typeof(TEntity), out var repository);
                if (!result)
                {
                    Logger.LogError($"Could not delete entity {entity} from the repository : " +
                        $"the type {typeof(TEntity)} is not registered");
                    return;
                }

                result = repository.TryRemove(entity.Id, out _);
                if (!result)
                {
                    Logger.LogError($"Failed to remove entity {entity} from the repository");
                    return;
                }

                Logger.LogDebug($"The entity {entity} deleted from the repository");

                InternalDeleteAsync(entity, cancellationToken);

            }, cancellationToken);
        }

        /// <summary>
        /// Notice! : this method get the entities from the local repository!
        /// </summary>
        public async Task<IEnumerable<TEntity>> GetAsync<TEntity>(CancellationToken cancellationToken = default)
            where TEntity : class, IEntity
        {
            return await Task.Run(() =>
            {
                var entities = Get(typeof(TEntity)).Cast<TEntity>();
                return entities;
            }, cancellationToken);
        }

        /// <summary>
        /// Notice! : this method get the entities from the local repository!
        /// </summary>
        public async Task<TEntity> GetAsync<TEntity>(Guid id, CancellationToken cancellationToken = default)
            where TEntity : class, IEntity
        {
            return await Task.Run(() =>
            {
                var entity = Get(typeof(TEntity), id) as TEntity;
                return entity;
            }, cancellationToken);
        }

        private IEnumerable<IEntity> Get(Type type)
        {
            var operationResult = Repository.TryGetValue(type, out var results);

            if (!operationResult)
            {
                Logger.LogError($"Could not get entities from the repository : " +
                    $"the type {type} is not registered");
                return null;
            }

            return results.Values;
        }

        private IEntity Get(Type type, Guid id)
        {
            var result = Repository.TryGetValue(type, out var repository);
            if (!result)
            {
                Logger.LogError($"Could not get entity of type {type} from the repository : " +
                    $"the type {type} is not registered");
                return null;
            }

            var operationResult = repository.TryGetValue(id, out var entity);

            if (!operationResult)
            {
                Logger.LogInformation($"Id {id} not exist in the repository");
                return null;
            }

            return entity;
        }

        protected virtual void InternalAddAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default) where TEntity : class, IEntity { }
        protected virtual void InternalDeleteAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default) where TEntity : class, IEntity { }
        protected virtual void InternalUpdateAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default) where TEntity : class, IEntity { }
    }
}
