﻿using Indoors.Services.Common;

namespace Indoors.Communications.Common.Repliers
{
    public interface IReplier : IService
    {
        
    }
}