﻿using System;

namespace Indoors.Communications.Common.Correlation
{
    public class GuidCorrelationIdGenerator : ICorrelationIdGenerator
    {
        public string Generate()
        {
            var guid = Guid.NewGuid().ToString();
            return guid;
        }
    }
}