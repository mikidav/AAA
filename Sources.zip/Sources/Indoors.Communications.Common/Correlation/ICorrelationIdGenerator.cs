﻿namespace Indoors.Communications.Common.Correlation
{
    public interface ICorrelationIdGenerator
    {
        string Generate();
    }
}