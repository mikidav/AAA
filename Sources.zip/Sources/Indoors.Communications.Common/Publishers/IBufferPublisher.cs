﻿using System.Collections;
using Indoors.Communications.Common.Types;

namespace Indoors.Communications.Common.Publishers
{
    public interface IBufferPublisher<TBuffer> : IPublisher where TBuffer : IList
    {
        string Publish(in BufferData<TBuffer> bufferData);

        void Publish(string publishId, in BufferData<TBuffer> bufferData);
    }
}