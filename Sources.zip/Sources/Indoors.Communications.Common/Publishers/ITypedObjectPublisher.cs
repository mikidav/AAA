﻿namespace Indoors.Communications.Common.Publishers
{
    public interface ITypedObjectPublisher<TData> : IPublisher
    {
        string Publish(in TData data);

        void Publish(string publishId, in TData data);
    }
}