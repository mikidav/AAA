﻿using System;
using Indoors.Communications.Common.Types;
using Indoors.Services.Common;

namespace Indoors.Communications.Common.Publishers
{
    public interface IPublisher : IService
    {
        /// <summary>
        /// Raised when data is published successfully
        /// </summary>
        IObservable<OperationCompletedData> PublishCompleted { get; }

        /// <summary>
        /// Raised when data fails to publish, containing 
        /// </summary>
        IObservable<OperationFailedData> PublishFailed { get; }
    }
}