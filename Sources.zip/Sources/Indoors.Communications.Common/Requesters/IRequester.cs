﻿using System;
using Indoors.Communications.Common.Types;
using Indoors.Services.Common;

namespace Indoors.Communications.Common.Requesters
{
    public interface IRequester : IService
    {
        /// <summary>
        /// Raised when data is published successfully
        /// </summary>
        IObservable<OperationCompletedData> RequestCompleted { get; }

        /// <summary>
        /// Raised when data fails to publish, containing 
        /// </summary>
        IObservable<OperationFailedData> RequestFailed { get; }
    }
}