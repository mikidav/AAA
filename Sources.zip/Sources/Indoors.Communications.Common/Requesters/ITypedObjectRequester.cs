﻿using System.Threading;
using System.Threading.Tasks;

namespace Indoors.Communications.Common.Requesters
{
    public interface ITypedObjectRequester<in TRequestData, TReplyData> : IRequester
    {
        (string requestId, TReplyData reply) Request(TRequestData requestData);

        TReplyData Request(string requestId, TRequestData requestData);

        Task<(string requestId, TReplyData reply)> RequestAsync(TRequestData requestData, CancellationToken cancellationToken = default);

        Task<TReplyData> RequestAsync(string requestId, TRequestData requestData, CancellationToken cancellationToken = default);
    }
}