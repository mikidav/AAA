﻿using System;
using System.Collections;
using Indoors.Communications.Common.Types;

namespace Indoors.Communications.Common.Subscribers
{
    public interface IBufferSubscriber<TBuffer> : ISubscriber where TBuffer : IList
    {
        IObservable<BufferData<TBuffer>> BufferReceived { get; }
    }
}