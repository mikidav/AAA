﻿using Indoors.Services.Common;

namespace Indoors.Communications.Common.Subscribers
{
    public interface ISubscriber : IService
    {

    }
}