﻿using System;

namespace Indoors.Communications.Common.Subscribers
{
    public interface ITypedObjectSubscriber<out TData> : ISubscriber
    {
        IObservable<TData> DataReceived { get; }
    }
}