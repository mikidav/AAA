﻿namespace Indoors.Communications.Common.Types
{
    public class OperationCompletedData
    {
        public string OperationId { get; }

        public OperationCompletedData(string operationId)
        {
            OperationId = operationId;
        }
    }
}