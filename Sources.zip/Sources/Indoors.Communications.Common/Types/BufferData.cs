﻿using System;
using System.Collections;

namespace Indoors.Communications.Common.Types
{
    public class BufferData<TBuffer> where TBuffer : IList
    {
        public TBuffer Buffer { get; }
        public ulong DataStartIndex { get; }
        public ulong DataLength { get; }

        public BufferData(TBuffer buffer, ulong dataStartIndex, ulong dataLength)
        {
            Buffer = buffer;
            DataStartIndex = dataStartIndex;
            DataLength = dataLength;
        }

        public BufferData(TBuffer buffer, ulong dataStartIndex)
            : this(buffer, dataStartIndex, (ulong)buffer.Count)
        {
        }

        public BufferData(TBuffer buffer)
            : this(buffer, 0, (ulong)buffer.Count)
        {
        }

        public bool IsValid()
        {
            if (Buffer == null)
                return false;
            var dataEndIndex = DataStartIndex + DataLength - 1;
            var isLengthValid = dataEndIndex < (ulong)Buffer.Count;
            return isLengthValid;
        }

        public void ThrowIfIsNotValid()
        {
            if (Buffer == null)
                throw new NullReferenceException("The buffer could not be null!");
            var dataEndIndex = DataStartIndex + DataLength - 1;
            var isLengthValid = dataEndIndex < (ulong)Buffer.Count;
            if (!isLengthValid)
                throw new IndexOutOfRangeException("DataStartIndex plus DataLength exceeding the size of the array");
        }
    }
}