﻿using System;
using System.IO;
using Autofac;
using Microsoft.Extensions.Configuration;
using Autofac.Configuration;

namespace Indoors.Utilities
{
    public static class AutofacConfigurationRegistrationExtensions
    {
        public static void RegisterXmlConfigurations(this ContainerBuilder builder, string xmlConfigurationsFilePath)
        {
            if (string.IsNullOrWhiteSpace(xmlConfigurationsFilePath))
                throw new ArgumentNullException(nameof(xmlConfigurationsFilePath));
            
            xmlConfigurationsFilePath = RelativePathToAbsolutePath(xmlConfigurationsFilePath);

            if (!File.Exists(xmlConfigurationsFilePath))
                throw new Exception($"XML configuration file does not exists! Path: \"{xmlConfigurationsFilePath}\"");

            var configuration = new ConfigurationBuilder()
                .AddXmlFile(xmlConfigurationsFilePath)
                .Build();

            RegisterConfigurations(builder, configuration);
        }
        
        public static void RegisterJsonConfigurations(this ContainerBuilder builder, string jsonConfigurationsFilePath)
        {
            if (string.IsNullOrWhiteSpace(jsonConfigurationsFilePath))
                throw new ArgumentNullException(nameof(jsonConfigurationsFilePath));
            
            jsonConfigurationsFilePath = RelativePathToAbsolutePath(jsonConfigurationsFilePath);

            if (!File.Exists(jsonConfigurationsFilePath))
                throw new Exception($"JSON configuration file does not exists! Path: \"{jsonConfigurationsFilePath}\"");

            var configuration = new ConfigurationBuilder()
                .AddJsonFile(jsonConfigurationsFilePath)
                .Build();

            RegisterConfigurations(builder, configuration);
        }

        public static void RegisterConfigurations(this ContainerBuilder builder, IConfiguration configuration)
        {
            if (builder == null)
                throw new NullReferenceException(nameof(builder));

            if (configuration == null)
                throw new NullReferenceException(nameof(configuration));

            var module = new ConfigurationModule(configuration);
            builder.RegisterModule(module);
        }

        private static string RelativePathToAbsolutePath(string jsonConfigurationsFilePath)
        {
            if (!Path.IsPathRooted(jsonConfigurationsFilePath))
            {
                jsonConfigurationsFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, jsonConfigurationsFilePath);
                jsonConfigurationsFilePath = Path.GetFullPath(jsonConfigurationsFilePath);
            }

            return jsonConfigurationsFilePath;
        }
    }
}