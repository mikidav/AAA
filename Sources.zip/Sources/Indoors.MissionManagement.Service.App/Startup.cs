using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Autofac;
using Indoors.Communications.RabbitMQ.Connection;
using Indoors.ConfigurationReader;
using Indoors.MissionManagement.Service.App.Hosting;
using Indoors.MissionManagement.Service.Hosting;
using Indoors.Services.Common;
using Indoors.Services.Hosting;
using Indoors.Swagger;
using Microsoft.Extensions.Configuration;
using Indoors.EntityFramework.Entities;
using Indoors.EntityFramework.Proxy.Modules;

namespace Indoors.MissionManagement.Service.App
{
    public class Startup
    {
        public IWebHostEnvironment WebHostEnvironment { get; }
        public IConfiguration Configurations { get; }

        public Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
        {
            Configurations = configuration;
            WebHostEnvironment = webHostEnvironment;
        }

        // ConfigureServices is where you register dependencies. This gets
        // called by the runtime before the ConfigureContainer method, below.
        public void ConfigureServices(IServiceCollection services)
        {
            // Add services to the collection. Don't build or return
            // any IServiceProvider or the ConfigureContainer method
            // won't get called. Don't create a ContainerBuilder
            // for Autofac here, and don't call builder.Populate() - that
            // happens in the AutofacServiceProviderFactory for you.

            services.AddOptions();

            services.AddControllers();

            // 1 - Add health checks
            // 2 - Add custom IService health check
            // 3 - Add health controller for expose Rest-Api to swagger
            services.AddHealthChecks()
                    .AddServicesHealthChecks();
            services.AddHealthController();

            services.AddIndoorsSwagger(IndoorsConfigurationReader.Instance.GetConfiguration<SwaggerSettings>(Configurations, "swagger_settings"));
        }

        // This is the default if you don't have an environment specific method.
        public void ConfigureContainer(ContainerBuilder builder)
        {
            // Register your own things directly with Autofac here. Don't
            // call builder.Populate(), that happens in AutofacServiceProviderFactory
            // for you.

            var module = new Autofac.Configuration.ConfigurationModule(Configurations);
            builder.RegisterModule(module);
            
            builder.RegisterEntityType<PlatformStatus>();

            builder.RegisterType<MissionManagementServiceHost>()
                .As<IMissionManagementServiceHost, IService>();

            builder.RegisterType<MissionManagementHost>()
                .As<IMissionManagementHost, IService>();

            builder.RegisterType<ServicesHostedService<IMissionManagementHost>>()
                .As<IHostedService>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IRabbitMqConnectionService rabbitMqConnection)
        {
            // If, for some reason, you need a reference to the built container, you
            // can use the convenience extension method GetAutofacRoot.
            // var autofacContainer = app.ApplicationServices.GetAutofacRoot();

            app.ConfigureErrorRoutes(WebHostEnvironment);

            app.UseRouting();

            // Configure base health checks for the app
            app.UseIndoorsHealthChecks();

            //Use swagger
            app.UseIndoorsSwagger();

            //Recommended only in development mode
            if (WebHostEnvironment.IsDevelopment())
            {
                // Notice! for using this implementation of swagger generator any Rest-Api have to be
                // [HttpGet\Post\Put\Delete] attribute or using  [ApiExplorerSettings(IgnoreApi = true)] attribute
                // For ignore this Rest method
                app.UseIndoorsSwaggerUI(IndoorsConfigurationReader.Instance.GetConfiguration<SwaggerSettings>(Configurations, "swagger_settings"));
            }

            app.UseEndpoints(endpoints =>
            {
                // Map the service health checks endpoints
                endpoints.MapServicesHealthChecks();

                //Map the endpoints for using swagger
                endpoints.MapIndoorsSwagger();

                endpoints.MapControllers();
            });

            rabbitMqConnection.Initialize();
            rabbitMqConnection.Start();
        }
    }
}
