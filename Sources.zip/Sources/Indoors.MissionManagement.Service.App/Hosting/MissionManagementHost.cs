﻿using Indoors.MissionManagement.Service.Hosting;
using Indoors.Services.Common;

namespace Indoors.MissionManagement.Service.App.Hosting
{
    public class MissionManagementHost : ServiceBase, IMissionManagementHost
    {
        private readonly IMissionManagementServiceHost _missionManagementServiceHost;

        public MissionManagementHost(IMissionManagementServiceHost missionManagementServiceHost)
        {
            _missionManagementServiceHost = missionManagementServiceHost;
        }

        protected override void InternalInitialize()
        {
            _missionManagementServiceHost.Initialize();
        }

        protected override void InternalStart()
        {
            _missionManagementServiceHost.Start();
        }

        protected override void InternalStop()
        {
            _missionManagementServiceHost.Stop();
        }
    }
}
