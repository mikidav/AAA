﻿using Indoors.Services.Common;

namespace Indoors.MissionManagement.Service.App.Hosting
{
    public interface IMissionManagementHost : IService
    {
    }
}
