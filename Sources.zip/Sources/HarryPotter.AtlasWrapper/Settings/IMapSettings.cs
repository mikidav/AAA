﻿namespace HarryPotter.AtlasWrapper.Settings
{
    public interface IMapSettings
    {
        int Width { get; }
        int Height { get; }

        double MaximumDistanceConstraintFactor { get; }
    }
}
