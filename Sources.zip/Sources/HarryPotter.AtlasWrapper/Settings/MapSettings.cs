﻿namespace HarryPotter.AtlasWrapper.Settings
{
    public class MapSettings : IMapSettings
    {
        public int Width { get; set; }

        public int Height { get; set; }

        public double MaximumDistanceConstraintFactor { get; set; }
    }
}
