﻿using System.Windows.Forms;
using Rafael.MAAM.Infra.Atlas.Presentation.UI;

namespace HarryPotter.AtlasWrapper
{
    partial class AtlasContainer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private TableLayoutPanel m_tableLayoutPanel1;
        private Panel m_panel1;
        private ViewControl m_viewControlVideo;
        private ViewControl m_viewControlMap;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                m_tableLayoutPanel1?.Dispose();
                m_panel1?.Dispose();
                m_viewControlVideo?.Dispose();
                m_viewControlMap?.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        }

        #endregion


    }
}
