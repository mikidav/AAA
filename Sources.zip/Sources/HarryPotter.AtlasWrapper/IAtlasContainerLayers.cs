﻿using System;
using System.ComponentModel;

namespace HarryPotter.AtlasWrapper
{
    public interface IAtlasContainerLayers : INotifyPropertyChanged, IDisposable
    {
        bool Visible { get; set; }
        string Name { get; }
    }
}