﻿using System;
using Indoors.Video.Common.Metadata;
using Indoors.Video.Common.Types;
using Rafael.MAAM.Infra.Atlas.Presentation.Overlays;
using Rafael.MAAM.Infra.Atlas.Presentation.UI;

namespace HarryPotter.AtlasWrapper
{
    public class VideoMetadataLayer : AtlasContainerLayersBase
    {
        private readonly OverlayLayer m_overlayLayer;

        private IDisposable m_subscriptionDisposable;

        public IMetadataProvider<IVideoFrameMetadata> MetadataProvider { get; }

        public VideoMetadataLayer(IMetadataProvider<IVideoFrameMetadata> metadataProvider,
            IViewControl viewControl,
            string layerName,
            bool defaultVisible = true) : base(viewControl, layerName ?? $"{nameof(VideoMetadataLayer)}-{Guid.NewGuid()}")
        {
            MetadataProvider = metadataProvider;

            m_overlayLayer = new OverlayLayer(layerName, viewControl.View) { Visible = defaultVisible };

            viewControl.View.LayersManager.OverlayLayers.Add(m_overlayLayer);

            if (metadataProvider?.MetadataUpdated != null)
                m_subscriptionDisposable = metadataProvider.MetadataUpdated.Subscribe(OnMetadataUpdated);
        }

        public override bool Visible
        {
            get => m_overlayLayer.Visible;
            set
            {
                m_overlayLayer.Visible = value;

                OnPropertyChanged();
            }
        }

        private void OnMetadataUpdated(IVideoFrameMetadata videoFrame)
        {
            // TODO update some vectors by metadata
        }

        protected override void InnerManagedDispose()
        {
            m_subscriptionDisposable?.Dispose();
            m_subscriptionDisposable = null;

            ViewControl?.View?.LayersManager?.OverlayLayers?.Remove(m_overlayLayer);

            m_overlayLayer?.Dispose();
            
            base.InnerManagedDispose();
        }
    }
}