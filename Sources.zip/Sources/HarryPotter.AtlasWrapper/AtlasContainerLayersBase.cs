﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;
using Rafael.MAAM.Infra.Atlas.Presentation.UI;

namespace HarryPotter.AtlasWrapper
{
    public abstract class AtlasContainerLayersBase : IAtlasContainerLayers
    {
        private bool m_disposed;
        private ILogger m_logger;
        protected ILogger Logger => m_logger ?? DummyLogger.Instance;
        protected IViewControl ViewControl { get; private set; }

        public virtual bool Visible { get; set; }
        public virtual string Name { get; }

        protected AtlasContainerLayersBase(IViewControl videoControl, string name = null, ILogger logger = null)
        {
            ViewControl = videoControl;
            Name = name;
            m_logger = logger;

            m_disposed = false;
        }

        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #region IDisposable Pattern Support

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // IMPORTANT!! override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
        // ~HostedServiceBase()
        // {
        //     // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
        //     Dispose(disposing: false);
        // }

        protected virtual void Dispose(bool disposing)
        {
            if (!m_disposed)
            {
                if (disposing)
                    InnerManagedDispose();

                InnerUnmanagedDispose();
                InnerNullifyReferencesDispose();

                m_disposed = true;
            }
        }

        protected virtual void InnerUnmanagedDispose()
        {
        }

        protected virtual void InnerManagedDispose()
        {
        }

        protected virtual void InnerNullifyReferencesDispose()
        {
            ViewControl = null;
            m_logger = null;
        }

        #endregion
    }
}