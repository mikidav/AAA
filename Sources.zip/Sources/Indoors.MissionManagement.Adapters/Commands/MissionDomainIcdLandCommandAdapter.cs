﻿using Indoors.DomainIcd.Mission.Messages;
using Indoors.MissionManagement.Common.CommandParameters;

namespace Indoors.MissionManagement.Adapters.Commands
{
    public class MissionDomainIcdLandCommandAdapter : IMissionDomainIcdCommandMessageAdapter<MissionLandCommandParameters, MissionLandCommandMessage>
    {
        public MissionLandCommandMessage ToMessage(string operationId, MissionLandCommandParameters commandParameter)
        {
            var message = new MissionLandCommandMessage
            {
                CommandId = operationId,
                MissionId = commandParameter?.MissionId,
                PlatformId = commandParameter?.PlatformId
            };

            return message;
        }

        public (string operationId, MissionLandCommandParameters) ToCommandParameter(MissionLandCommandMessage message)
        {
            if (message == null)
                return (null, null);

            var parameters = new MissionLandCommandParameters
            {
                MissionId = message.MissionId,
                PlatformId = message.PlatformId,
            };

            return (message.CommandId, parameters);
        }
    }
}