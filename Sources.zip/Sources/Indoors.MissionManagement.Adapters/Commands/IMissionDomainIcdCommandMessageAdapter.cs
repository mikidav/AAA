﻿using Indoors.Commands.Messages.Common;
using Indoors.MissionManagement.Common.CommandParameters;

namespace Indoors.MissionManagement.Adapters.Commands
{
    public interface IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
        : ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage> 
            where TCommandParameter : IMissionCommandParameters
            where TCommandDomainMessage : class
    {

    }
}