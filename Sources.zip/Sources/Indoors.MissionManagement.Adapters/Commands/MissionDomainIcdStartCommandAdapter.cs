﻿using Indoors.DomainIcd.Mission.Messages;
using Indoors.MissionManagement.Common.CommandParameters;

namespace Indoors.MissionManagement.Adapters.Commands
{
    public class MissionDomainIcdStartCommandAdapter : IMissionDomainIcdCommandMessageAdapter<MissionStartCommandParameters, MissionStartCommandMessage>
    {
        public MissionStartCommandMessage ToMessage(string operationId, MissionStartCommandParameters commandParameter)
        {
            var message = new MissionStartCommandMessage
            {
                CommandId = operationId,
                MissionId = commandParameter?.MissionId
            };

            return message;
        }

        public (string operationId, MissionStartCommandParameters) ToCommandParameter(MissionStartCommandMessage message)
        {
            if (message == null)
                return (null, null);

            var parameters = new MissionStartCommandParameters
            {
                MissionId = message.MissionId,
            };

            return (message.CommandId, parameters);
        }
    }
}