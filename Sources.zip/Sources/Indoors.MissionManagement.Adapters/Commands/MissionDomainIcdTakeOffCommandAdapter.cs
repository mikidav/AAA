﻿using Indoors.DomainIcd.Mission.Messages;
using Indoors.MissionManagement.Common.CommandParameters;

namespace Indoors.MissionManagement.Adapters.Commands
{
    public class MissionDomainIcdTakeOffCommandAdapter : IMissionDomainIcdCommandMessageAdapter<MissionTakeOffCommandParameters, MissionTakeOffCommandMessage>
    {
        public MissionTakeOffCommandMessage ToMessage(string operationId, MissionTakeOffCommandParameters commandParameter)
        {
            var message = new MissionTakeOffCommandMessage
            {
                CommandId = operationId,
                MissionId = commandParameter?.MissionId,
                PlatformId = commandParameter?.PlatformId,
                TakeoffData = new MissionTakeoffStruct
                {
                    TakeoffHeightMeters = commandParameter?.HeightMeters ?? 0
                }
            };
            return message;
        }

        public (string operationId, MissionTakeOffCommandParameters) ToCommandParameter(MissionTakeOffCommandMessage message)
        {
            if (message == null)
                return (null, null);

            var parameter = new MissionTakeOffCommandParameters
            {
                MissionId = message.MissionId,
                PlatformId = message.PlatformId,
                HeightMeters = message.TakeoffData?.TakeoffHeightMeters ?? 0
            };

            return (message.CommandId, parameter);
        }
    }
}