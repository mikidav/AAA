﻿using Indoors.DomainIcd.Mission.Messages;
using Indoors.MissionManagement.Common.CommandParameters;

namespace Indoors.MissionManagement.Adapters.Commands
{
    public class MissionDomainIcdStopCommandAdapter : IMissionDomainIcdCommandMessageAdapter<MissionStopCommandParameters, MissionStopCommandMessage>
    {
        public MissionStopCommandMessage ToMessage(string operationId, MissionStopCommandParameters commandParameter)
        {
            var message = new MissionStopCommandMessage
            {
                CommandId = operationId,
                MissionId = commandParameter?.MissionId
            };

            return message;
        }

        public (string operationId, MissionStopCommandParameters) ToCommandParameter(MissionStopCommandMessage message)
        {
            if (message == null)
                return (null, null);

            var parameters = new MissionStopCommandParameters
            {
                MissionId = message.MissionId,
            };

            return (message.CommandId, parameters);
        }
    }
}