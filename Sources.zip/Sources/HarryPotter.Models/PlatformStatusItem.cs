﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace HarryPotter.Models
{
    public class PlatformStatusItem : INotifyPropertyChanged
    {
        private float m_batteryCapacity;
        private float m_networkSignalQuality;
        private float m_sensorQuality;
        private PlatformType m_platformType;
        private Location3D m_location;
        private string m_state;
        private bool m_visible;

        public string Id { get; set; }

        public bool Visible
        {
            get => m_visible; 
            set
            {
                m_visible = value;
                OnPropertyChanged(nameof(Visible));
            }
        }

        //
        public PlatformType PlatformType
        {
            get => m_platformType;
            set
            {
                m_platformType = value;
                OnPropertyChanged(nameof(PlatformType));
            }
        }

        /// <summary>
        ///     value between 0-100,used by convertor to display icon
        /// </summary>
        public float BatteryCapacity
        {
            get => m_batteryCapacity;
            set
            {
                m_batteryCapacity = value;
                OnPropertyChanged(nameof(BatteryCapacity));
            }
        }


        /// <summary>
        ///     value between 0-1,used by convertor to display icon
        /// </summary>
        public float SensorQuality
        {
            get => m_sensorQuality;
            set
            {
                m_sensorQuality = value;
                OnPropertyChanged(nameof(SensorQuality));
            }
        }


        /// <summary>
        ///     value between 0-100,used by convertor to display icon
        /// </summary>
        public float NetworkSignalQuality
        {
            get => m_networkSignalQuality;
            set
            {
                m_networkSignalQuality = value;
                OnPropertyChanged(nameof(NetworkSignalQuality));
            }
        }

        public Location3D Location
        {
            get { return m_location; }
            set
            {
                if (value == m_location)
                    return;

                m_location = value;
                OnPropertyChanged(nameof(Location));
            }
        }

        public string State
        {
            get { return m_state; }
            set
            {
                if (value == m_state)
                    return;

                m_state = value;
                OnPropertyChanged(nameof(State));
            }
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


        public event PropertyChangedEventHandler PropertyChanged;
    }
}