﻿namespace HarryPotter.Models
{
    public enum ViewEnum
    {
        MapAndVideoView,
        MapView,
        VideoView
    }
}