﻿namespace HarryPotter.Models
{
    public enum PlatformType
    {
        Drone,
        Car,
        Dog
    }
}