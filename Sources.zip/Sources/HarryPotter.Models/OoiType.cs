﻿namespace HarryPotter.Models
{
    public enum OoiType
    {
        People,
        Weapons,
        Furniture,
        Platform,
        Tools
    }

    public class Ooi
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }
        public OoiType Ooitype { get; set; }

        public Ooi(double X = 0, double Y = 0, double Z = 0, OoiType ooitype = OoiType.Platform)
        {
            this.X = X;
            this.Y = Y;
            this.Z = Z;
            Ooitype = ooitype;
        }

        public override int GetHashCode()
        {
            return (int)((X + Y) * 10000000 % 1000000);
        }
    }

    public enum LayerType
    {
        People,
        Weapons,
        Furniture,
        Platform,
        Tools
    }

    public class LayerState
    {
        public LayerType Layer { get; set; }
        //Visibility
        public bool Visibility { get; set; }
    }
}