﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace HarryPotter.Models
{
    public class OoiFilterItem : INotifyPropertyChanged
    {
        private OoiType m_itemType;
        private bool m_visible;
        private string m_ooiCount;

        public bool Visible
        {
            get => m_visible;
            set
            {
                if (value == m_visible) return;
                m_visible = value;
                OnPropertyChanged(nameof(Visible));
            }
        }

        public OoiType ItemType
        {
            get => m_itemType;
            set
            {
                if (value == m_itemType) return;
                m_itemType = value;
                OnPropertyChanged(nameof(ItemType));
                OnPropertyChanged(nameof(OoiTypeText));
            }
        }

        public string OoiTypeText => ItemType.ToString();

        public string OoiCount
        {
            get => m_ooiCount;
            set
            {
                if (value == m_ooiCount) return;
                m_ooiCount = value;
                OnPropertyChanged(nameof(OoiCount));
            }
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


        public event PropertyChangedEventHandler PropertyChanged;
    }
}