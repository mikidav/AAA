﻿using System.Collections.Generic;
using Google.Protobuf.Reflection;
using Indoors.DomainIcd.Video.Messages;
using Indoors.Serializations.Protobuf;

namespace Indoors.DomainIcd.Video
{
    public class VideoDomainIcdDescriptorProvider : IFileDescriptorProvider
    {
        public IEnumerable<FileDescriptor> Descriptors => new[] { VideoMessagesReflection.Descriptor };
    }
}