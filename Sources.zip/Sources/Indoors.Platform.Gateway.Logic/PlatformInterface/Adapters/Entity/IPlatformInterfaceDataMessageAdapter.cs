﻿using Indoors.EntityFramework.Entities.Base;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Entity
{
    public interface IPlatformInterfaceEntityDataAdapter<in TPlatformData, TEntity>
        where TPlatformData : class
        where TEntity : IEntity
    {
        TEntity ToData(TPlatformData platformData, TEntity entity = default);
    }
}