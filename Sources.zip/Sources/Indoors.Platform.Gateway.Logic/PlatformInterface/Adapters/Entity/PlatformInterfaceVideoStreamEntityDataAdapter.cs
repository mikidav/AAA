﻿using System;
using Indoors.EntityFramework.Entities;
using Subgiga;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Entity
{
    public class PlatformInterfaceVideoStreamEntityDataAdapter : IPlatformInterfaceEntityDataAdapter<RosSensorImage, VideoStream>
    {
        private static readonly string s_executingAssemblyName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;

        public VideoStream ToData(RosSensorImage platformData, VideoStream entity = default)
        {
            entity ??= new VideoStream(Guid.NewGuid());

            entity = entity with
            {
                UpdatedBy = s_executingAssemblyName,
                UpdatedTimeUtc = DateTime.UtcNow,
                Version = Guid.NewGuid().ToString(),
                EncodingFormat = platformData.Encoding ?? "JPEG",
                Height = platformData.Height,
                Width = platformData.Width
            };

            return entity;
        }
    }
}