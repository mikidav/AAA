﻿using Indoors.EntityFramework.Entities.Types;
using Subgiga;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Types
{
    public static class PlatformInterfacePointAdapter
    {
        public static GeoPoint3D ToGeoPoint3D(this RosPoint rosPoint)
        {
            if (rosPoint == null)
                return null;

            GeoPoint3D geoPoint3D = new(rosPoint.X, rosPoint.Y, rosPoint.Z);
            return geoPoint3D;
        }

        public static RosPoint ToRosPoint(this GeoPoint3D geoPoint3D)
        {
            if (geoPoint3D == null)
                return null;

            RosPoint rosPoint = new()
            {
                X = (float)geoPoint3D.X,
                Y = (float)geoPoint3D.Y,
                Z = (float)geoPoint3D.Z
            };
            return rosPoint;
        }
    }
}