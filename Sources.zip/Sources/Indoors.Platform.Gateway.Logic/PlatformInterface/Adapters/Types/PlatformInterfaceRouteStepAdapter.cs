﻿using Indoors.EntityFramework.Entities.Types;
using Subgiga;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Types
{
    public static class PlatformInterfaceRouteStepAdapter
    {
        public static RouteStep ToRouteStep(this RosPose rosPose)
        {
            if (rosPose == null)
                return null;

            RouteStep routeStep = new(rosPose.Position.ToGeoPoint3D(), rosPose.Orientation.ToOrientation());
            return routeStep;
        }

        public static RosPose ToRosPose(this RouteStep routeStep)
        {
            if (routeStep == null)
                return null;

            RosPose rosPoint = new()
            {
               Position = routeStep.Location.ToRosPoint(),
               Orientation = routeStep.Orientation.ToRosQuaternion()
            };
            return rosPoint;
        }
    }
}