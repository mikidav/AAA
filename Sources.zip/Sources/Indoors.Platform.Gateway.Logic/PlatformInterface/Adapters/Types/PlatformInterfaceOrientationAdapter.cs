﻿using Indoors.EntityFramework.Entities.Types;
using Subgiga;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Types
{
    public static class PlatformInterfaceOrientationAdapter
    {
        public static Orientation ToOrientation(this RosQuaternion rosQuaternion)
        {
            if (rosQuaternion == null)
                return null;

            Orientation orientation = new(rosQuaternion.X, rosQuaternion.Y, rosQuaternion.Z, rosQuaternion.W);
            return orientation;
        }

        public static RosQuaternion ToRosQuaternion(this Orientation orientation)
        {
            if (orientation == null)
                return null;

            RosQuaternion rosQuaternion = new()
            {
                X = (float)orientation.X,
                Y = (float)orientation.Y,
                Z = (float)orientation.Z,
                W = (float)orientation.W
            };
            return rosQuaternion;
        }
    }
}