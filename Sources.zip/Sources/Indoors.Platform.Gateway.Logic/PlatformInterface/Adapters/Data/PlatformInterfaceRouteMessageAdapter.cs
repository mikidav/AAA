﻿using Indoors.Platform.Gateway.Logic.PlatformInterface.Incoming;
using Subgiga.Messages;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Data
{
    public class PlatformInterfaceRouteMessageAdapter : IPlatformInterfaceDataMessageAdapter<IncomingMessageWrapper, RosPoseArray>
    {
        public RosPoseArray ToData(IncomingMessageWrapper message)
        {
            if (message.Topic != 26)
                return null;

            var rosPoseArray = RosPoseArray.Parser.ParseFrom(message.Data);
            return rosPoseArray;
        }
    }
}