﻿using Indoors.Platform.Gateway.Logic.PlatformInterface.Incoming;
using Subgiga;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Data
{
    public class PlatformInterfaceFrontierMessageAdapter : IPlatformInterfaceDataMessageAdapter<IncomingMessageWrapper, RosPointArray>
    {
        public RosPointArray ToData(IncomingMessageWrapper message)
        {
            if (message.Topic != 27)
                return null;

            var rosPointArray = RosPointArray.Parser.ParseFrom(message.Data);
            return rosPointArray;
        }
    }
}