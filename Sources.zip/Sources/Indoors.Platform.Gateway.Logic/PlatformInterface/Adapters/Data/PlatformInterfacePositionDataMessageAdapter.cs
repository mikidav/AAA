﻿using Indoors.Platform.Gateway.Logic.PlatformInterface.Incoming;
using Subgiga;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Data
{
    public class PlatformInterfacePositionDataMessageAdapter : IPlatformInterfaceDataMessageAdapter<IncomingMessageWrapper, RosPoseStamped>
    {
        public RosPoseStamped ToData(IncomingMessageWrapper message)
        {
            if (message.Topic != 20)
                return null;

            var rosPose = RosPoseStamped.Parser.ParseFrom(message.Data);
            return rosPose;
        }
    }
}