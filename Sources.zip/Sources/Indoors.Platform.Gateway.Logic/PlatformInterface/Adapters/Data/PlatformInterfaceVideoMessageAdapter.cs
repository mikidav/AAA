﻿using Indoors.Platform.Gateway.Logic.PlatformInterface.Incoming;
using Subgiga;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Data
{
    public class PlatformInterfaceVideoMessageAdapter : IPlatformInterfaceDataMessageAdapter<IncomingMessageWrapper, RosSensorImage>
    {
        public RosSensorImage ToData(IncomingMessageWrapper message)
        {
            if (message.Topic != 28)
                return null;

            var rosSensorImage = RosSensorImage.Parser.ParseFrom(message.Data);
            return rosSensorImage;
        }
    }
}