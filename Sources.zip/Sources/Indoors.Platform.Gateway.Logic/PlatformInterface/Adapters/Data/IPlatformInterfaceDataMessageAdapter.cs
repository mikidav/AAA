﻿namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Data
{
    public interface IPlatformInterfaceDataMessageAdapter<in TPlatformMessage, out TPlatformData>
        where TPlatformData : class
        where TPlatformMessage : class
    {
        TPlatformData ToData(TPlatformMessage message);
    }
}