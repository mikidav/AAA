﻿using Indoors.Platform.Gateway.Logic.PlatformInterface.Incoming;
using Subgiga;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Data
{
    public class PlatformInterfaceSystemStateMessageAdapter : IPlatformInterfaceDataMessageAdapter<IncomingMessageWrapper, RosMsgHeader>
    {
        public RosMsgHeader ToData(IncomingMessageWrapper message)
        {
            if (message.Topic != 9)
                return null;

            var header = RosMsgHeader.Parser.ParseFrom(message.Data);
            return header;
        }
    }
}