﻿using Indoors.Platform.Gateway.Logic.PlatformInterface.Incoming;
using Subgiga;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Data
{
    public class PlatformInterfaceGeneralStatusMessageAdapter : IPlatformInterfaceDataMessageAdapter<IncomingMessageWrapper, RosInt16MultiArray>
    {
        public RosInt16MultiArray ToData(IncomingMessageWrapper message)
        {
            if (message.Topic != 6)
                return null;

            var rosPose = RosInt16MultiArray.Parser.ParseFrom(message.Data);
            return rosPose;
        }
    }
}