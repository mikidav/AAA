﻿using Google.Protobuf;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;
using Subgiga;
using Subgiga.Messages;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public class PlatformInterfaceRecoverCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<PlatformRecoverCommandParameters, OutgoingCommandMessageWrapper>
    {
        public OutgoingCommandMessageWrapper ToMessage(PlatformRecoverCommandParameters commandParameter)
        {
            var inertia = new Inertia
            {
                M = 4 // 4 = Recover
            };

            var commandMessage = new CommandMessage
            {
                Inertia = inertia
            };

            
            var commandMessageWrapper = new OutgoingCommandMessageWrapper
            {
                MessageByteString = commandMessage.ToByteString(),
                Topic = 2,
                ProtocolType = protocol_type.Critical
            };

            return commandMessageWrapper;
        }
    }
}