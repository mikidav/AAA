﻿using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public interface IPlatformInterfaceCommandMessageAdapter<in TCommandParameters, out TPlatformMessage>
        where TCommandParameters : IPlatformCommandParameter
        where TPlatformMessage : class
    {
        TPlatformMessage ToMessage(TCommandParameters commandParameter);
    }
}