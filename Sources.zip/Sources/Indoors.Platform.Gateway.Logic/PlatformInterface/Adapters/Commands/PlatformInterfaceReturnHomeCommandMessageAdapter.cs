﻿using System;
using Google.Protobuf;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;
using Subgiga;
using Subgiga.Messages;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public class PlatformInterfaceReturnHomeCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<PlatformReturnHomeCommandParameters, OutgoingCommandMessageWrapper>
    {
        public OutgoingCommandMessageWrapper ToMessage(PlatformReturnHomeCommandParameters commandParameter)
        {
            var totalSeconds = TimeSpan.FromTicks(DateTime.UtcNow.Ticks).TotalSeconds;

            var poseStamped = new RosPoseStamped
            {
                Header = new RosMsgHeader
                {
                    Stamp = new time
                    {
                        Sec = (int)totalSeconds,
                        Nsec = 0
                    },
                    FrameId = "map"
                },
                Pose = new RosPose
                {
                    Position = new RosPoint(),
                    Orientation = new RosQuaternion { W = 1 }
                }
            };

            var commandMessageWrapper = new OutgoingCommandMessageWrapper
            {
                MessageByteString = poseStamped.ToByteString(),
                Topic = 5,
                ProtocolType = protocol_type.Critical
            };

            return commandMessageWrapper;
        }
    }
}