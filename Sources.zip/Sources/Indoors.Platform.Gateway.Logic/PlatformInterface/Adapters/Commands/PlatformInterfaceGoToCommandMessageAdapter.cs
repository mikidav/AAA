﻿using System;
using Google.Protobuf;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;
using Subgiga;
using Subgiga.Messages;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public class PlatformInterfaceGoToCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<PlatformGoToCommandParameters, OutgoingCommandMessageWrapper>
    {
        public OutgoingCommandMessageWrapper ToMessage(PlatformGoToCommandParameters commandParameter)
        {
            if (commandParameter?.Location == null)
                return null;
            
            var totalSeconds = TimeSpan.FromTicks(DateTime.UtcNow.Ticks).TotalSeconds;

            var poseStamped = new RosPoseStamped
            {
                Header = new RosMsgHeader
                {
                    Stamp = new time
                    {
                        Sec = (int)totalSeconds,
                        Nsec = 0
                    },
                    FrameId = "map"
                },
                Pose = new RosPose
                {
                    Position = new RosPoint
                    {
                        X = (float)commandParameter.Location.X,
                        Y = (float)commandParameter.Location.Y
                    },
                }
            };

            var commandMessageWrapper = new OutgoingCommandMessageWrapper
            {
                MessageByteString = poseStamped.ToByteString(),
                Topic = 5,
                ProtocolType = protocol_type.Critical
            };

            return commandMessageWrapper;
        }
    }
}