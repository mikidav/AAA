﻿using Google.Protobuf;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;
using Subgiga;
using Subgiga.Messages;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public class PlatformInterfaceLandCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<PlatformLandCommandParameters, OutgoingCommandMessageWrapper>
    {
        public OutgoingCommandMessageWrapper ToMessage(PlatformLandCommandParameters commandParameter)
        {
            var inertia = new Inertia
            {
                M = 3 // 3 = Land
            };

            var commandMessage = new CommandMessage
            {
                Inertia = inertia
            };

            var commandMessageWrapper = new OutgoingCommandMessageWrapper
            {
                MessageByteString = commandMessage.ToByteString(),
                Topic = 2,
                ProtocolType = protocol_type.Critical
            };

            return commandMessageWrapper;
        }
    }
}