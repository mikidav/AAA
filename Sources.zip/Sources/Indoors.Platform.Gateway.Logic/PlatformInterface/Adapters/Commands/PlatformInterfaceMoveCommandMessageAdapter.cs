﻿using Google.Protobuf;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;
using Subgiga;
using Subgiga.Messages;
using UnitsNet;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public class PlatformInterfaceMoveCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<PlatformMoveCommandParameters, OutgoingCommandMessageWrapper>
    {
        public OutgoingCommandMessageWrapper ToMessage(PlatformMoveCommandParameters commandParameter)
        {
            if (commandParameter == null)
                return null;

            var angleInRadians = Angle.FromDegrees(commandParameter.AngleXYDegrees).Radians;
            
            var inertia = new Inertia
            {
                M = 7, // 14 = move Old, 7 Move New
                Com = new Vector3
                {
                    X = (float) commandParameter.DistanceXMeters,
                    Y = (float)commandParameter.DistanceYMeters * -1,
                    Z = (float)commandParameter.DistanceZMeters
                },
                Ixz = (float) angleInRadians * -1,
            };

            var commandMessage = new CommandMessage
            {
                Inertia = inertia
            };

            var commandMessageWrapper = new OutgoingCommandMessageWrapper
            {
                MessageByteString = commandMessage.ToByteString(),
                Topic = 2,
                ProtocolType = protocol_type.Critical
            };

            return commandMessageWrapper;
        }
    }
}