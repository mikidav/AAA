﻿using Gateway.Messages;
using Google.Protobuf;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public class PlatformInterfaceSetNavigationModeCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<PlatformSetNavigationModeCommandParameters, OutgoingSystemInstructionMessageWrapper>
    {
        public OutgoingSystemInstructionMessageWrapper ToMessage(PlatformSetNavigationModeCommandParameters commandParameter)
        {
            var commandCode = commandParameter.Mode switch
            {
                Common.Types.NavigationModeEnum.Unknown => 0,
                Common.Types.NavigationModeEnum.Indoors => 14,
                Common.Types.NavigationModeEnum.Outdoors => 15,
                _ => 0,
            };

            var runScriptHeader = new Header
            {
                Type = 0,
                Id = 42 /*TODO set meaningful ID*/
            };

            var systemInstructionMessage = new run_script_msg
            {
                Header = runScriptHeader,
                Command = commandCode,
            };

            var systemInstructionMessageWrapper = new OutgoingSystemInstructionMessageWrapper
            {
                MessageByteString = systemInstructionMessage.ToByteString(),
            };

            return systemInstructionMessageWrapper;
        }
    }
}