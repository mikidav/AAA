﻿using Google.Protobuf;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;
using Subgiga;
using Subgiga.Messages;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public class PlatformInterfaceDisarmCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<PlatformDisarmCommandParameters, OutgoingCommandMessageWrapper>
    {
        public OutgoingCommandMessageWrapper ToMessage(PlatformDisarmCommandParameters commandParameter)
        {
            var inertia = new Inertia
            {
                M = 0 // 0 = DISARM
            };

            var commandMessage = new CommandMessage
            {
                Inertia = inertia
            };

            var commandMessageWrapper = new OutgoingCommandMessageWrapper
            {
                MessageByteString = commandMessage.ToByteString(),
                Topic = 2,
                ProtocolType = protocol_type.Critical
            };

            return commandMessageWrapper;
        }
    }
}