﻿using Google.Protobuf;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;
using Subgiga;
using Subgiga.Messages;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public class PlatformInterfaceArmCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<PlatformArmCommandParameters, OutgoingCommandMessageWrapper>
    {
        public OutgoingCommandMessageWrapper ToMessage(PlatformArmCommandParameters commandParameter)
        {
            var inertia = new Inertia
            {
                M = 1 // 1 = ARM
            };

            var commandMessage = new CommandMessage
            {
                Inertia = inertia
            };

            
            var commandMessageWrapper = new OutgoingCommandMessageWrapper
            {
                MessageByteString = commandMessage.ToByteString(),
                Topic = 2,
                ProtocolType = protocol_type.Critical
            };

            return commandMessageWrapper;
        }
    }
}