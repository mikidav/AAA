﻿using Google.Protobuf;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;
using Subgiga;
using Subgiga.Messages;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public class PlatformInterfaceTakeOffCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<PlatformTakeOffCommandParameters, OutgoingCommandMessageWrapper>
    {
        public OutgoingCommandMessageWrapper ToMessage(PlatformTakeOffCommandParameters commandParameter)
        {
            var inertia = new Inertia
            {
                M = 20, // 2 = TakeOff // 20 Arm and Takeoff
                Com = new Vector3
                {
                    Z = (float)commandParameter.HeightMeters
                }
            };

            var commandMessage = new CommandMessage
            {
                Inertia = inertia
            };

            var commandMessageWrapper = new OutgoingCommandMessageWrapper
            {
                MessageByteString = commandMessage.ToByteString(),
                Topic = 2,
                ProtocolType = protocol_type.Critical
            };

            return commandMessageWrapper;
        }
    }
}