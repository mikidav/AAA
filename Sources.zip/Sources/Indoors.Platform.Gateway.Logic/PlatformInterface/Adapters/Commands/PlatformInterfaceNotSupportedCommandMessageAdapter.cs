﻿using Indoors.Platform.Gateway.Common.CommandParameters;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public class PlatformInterfaceNotSupportedCommandMessageAdapter<TCommandParameters, TPlatformMessage> : IPlatformInterfaceCommandMessageAdapter<TCommandParameters, TPlatformMessage> 
        where TCommandParameters : IPlatformCommandParameter 
        where TPlatformMessage : class
    {
        public TPlatformMessage ToMessage(TCommandParameters commandParameter)
        {
            return null;
        }
    }
}