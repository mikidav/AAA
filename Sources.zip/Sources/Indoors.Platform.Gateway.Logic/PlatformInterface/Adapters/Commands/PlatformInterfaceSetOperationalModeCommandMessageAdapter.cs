﻿using System;
using Google.Protobuf;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Common.Types;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;
using Subgiga;
using Subgiga.Messages;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public class PlatformInterfaceSetOperationalModeCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<PlatformSetOperationalModeCommandParameters, OutgoingCommandMessageWrapper>
    {
        public OutgoingCommandMessageWrapper ToMessage(PlatformSetOperationalModeCommandParameters commandParameter)
        {
            var inertia = commandParameter.Mode switch
            {
                OperationalModeEnum.ExplorationStart => new Inertia { M = 11 },
                OperationalModeEnum.ExplorationStop => new Inertia { M = 12 },
                OperationalModeEnum.ManualStart => new Inertia { M = 7, Com = new Vector3 { X = 0, Z = 1 } },
                OperationalModeEnum.ManualStop => new Inertia { M = 10, Com = new Vector3 { X = 0, Z = 1 } },
                _ => throw new ArgumentOutOfRangeException(nameof(commandParameter.Mode), commandParameter.Mode, null)
            };

            var commandMessage = new CommandMessage
            {
                Inertia = inertia
            };

            var commandMessageWrapper = new OutgoingCommandMessageWrapper
            {
                MessageByteString = commandMessage.ToByteString(),
                Topic = 2,
                ProtocolType = protocol_type.Critical
            };

            return commandMessageWrapper;
        }
    }
}