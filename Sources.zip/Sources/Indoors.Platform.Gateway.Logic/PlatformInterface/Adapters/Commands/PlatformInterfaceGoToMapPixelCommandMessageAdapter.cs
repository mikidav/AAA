﻿using System;
using Google.Protobuf;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;
using Subgiga;
using Subgiga.Messages;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands
{
    public class PlatformInterfaceGoToMapPixelCommandMessageAdapter : IPlatformInterfaceCommandMessageAdapter<PlatformGoToMapPixelCommandParameters, OutgoingCommandMessageWrapper>
    {
        public OutgoingCommandMessageWrapper ToMessage(PlatformGoToMapPixelCommandParameters commandParameter)
        {
            if (commandParameter?.Location == null)
                return null;
            
            var poseStamped = new RosPoseStamped
            {
                Header = new RosMsgHeader
                {
                    FrameId = "mappixel"
                },
                Pose = new RosPose
                {
                    Position = new RosPoint
                    {
                        X = (float) commandParameter.Location.X,
                        Y = (float) commandParameter.Location.Y
                    },
                }
            };

            var commandMessageWrapper = new OutgoingCommandMessageWrapper
            {
                MessageByteString = poseStamped.ToByteString(),
                Topic = 29,
                ProtocolType = protocol_type.Critical
            };

            return commandMessageWrapper;
        }
    }
}