﻿using System;
using System.Reactive.Linq;
using Indoors.EntityFramework.Common;
using Indoors.EntityFramework.Entities.Base;
using Indoors.Platform.Gateway.Logic.Entities;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Entity;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Handlers
{
    public class EntityHandler<TPlatformData, TEntity> : ServiceBase, IPlatformDataHandler
        where TPlatformData : class
        where TEntity : class, IEntity
    {
        private IDisposable m_subscriptionDisposable;

        public IDataNotifier<TPlatformData> DataNotifier { get; private set; }
        public IPlatformInterfaceEntityDataAdapter<TPlatformData, TEntity> DataAdapter { get; private set; }
        public IEntityRepository EntityRepository { get; private set; }
        public IEntityProvider<TEntity> EntityProvider { get; private set; }

        public EntityHandler(IDataNotifier<TPlatformData> dataNotifier,
            IPlatformInterfaceEntityDataAdapter<TPlatformData, TEntity> dataAdapter,
            IEntityRepository entityRepository,
            IEntityProvider<TEntity> entityProvider,
            ILogger<EntityHandler<TPlatformData, TEntity>> logger = null,
            string id = null) : base(logger,
            id)
        {
            EntityRepository = entityRepository;
            DataAdapter = dataAdapter;
            EntityProvider = entityProvider;
            DataNotifier = dataNotifier;
        }

        protected override void InternalInitialize()
        {
            // no internal logic
        }

        protected override void InternalStart()
        {
            m_subscriptionDisposable = DataNotifier.DataNotified.Where(_ => IsRunning).Subscribe(OnDataReceived);
        }

        protected override void InternalStop()
        {
            m_subscriptionDisposable?.Dispose();
            m_subscriptionDisposable = null;
        }

        protected override void InnerNullifyReferencesDispose()
        {
            EntityRepository = null;
            DataAdapter = null;
            EntityProvider = null;
            DataNotifier = null;

            base.InnerNullifyReferencesDispose();
        }

        private void OnDataReceived(TPlatformData data)
        {
            try
            {
                var entity = EntityProvider?.GetEntity(RetrievePolicyEnum.CreateIfNotExists);
                entity = DataAdapter.ToData(data, entity);
                if (entity != null)
                    EntityRepository.Update(entity);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, $"Failed on try to adapt and update entity! Data: {data}, {ServiceDescriptionString}");
            }
        }
    }
}