﻿using Indoors.Services.Common;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Handlers
{
    public interface IPlatformDataHandler : IService
    {
    }
}