﻿using System;
using System.Reactive.Linq;
using Indoors.Communications.Common.Publishers;
using Indoors.EntityFramework.Entities;
using Indoors.Platform.Gateway.Logic.Entities;
using Indoors.Services.Common;
using Indoors.Video.Common.Settings;
using Indoors.Video.Common.Types;
using Microsoft.Extensions.Logging;
using Subgiga;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Handlers
{
    public class VideoFrameHandler : ServiceBase, IPlatformDataHandler
    {
        private IDisposable m_subscriptionDisposable;

        public IDataNotifier<RosSensorImage> DataNotifier { get; private set; }
        public ITypedObjectPublisher<IVideoFrame<IVideoFrameMetadata>> Publisher { get; private set; }
        public IEntityProvider<VideoStream> VideoStreamEntityProvider { get; private set; }
        public IVideoSettings VideoSettings { get; }

        public VideoFrameHandler(IDataNotifier<RosSensorImage> dataNotifier,
            ITypedObjectPublisher<IVideoFrame<IVideoFrameMetadata>> publisher,
            IEntityProvider<VideoStream> videoStreamEntityProvider,
            IVideoSettings videoSettings,
            ILogger<VideoFrameHandler> logger = null,
            string id = null) : base(logger, id)
        {
            Publisher = publisher;
            VideoStreamEntityProvider = videoStreamEntityProvider;
            VideoSettings = videoSettings;
            DataNotifier = dataNotifier;
        }

        protected override void InternalInitialize()
        {
            Publisher.Initialize();
        }

        protected override void InternalStart()
        {
            Publisher.Start();

            m_subscriptionDisposable = DataNotifier.DataNotified.Where(_ => IsRunning).Subscribe(OnDataReceived);
        }

        protected override void InternalStop()
        {
            m_subscriptionDisposable?.Dispose();
            m_subscriptionDisposable = null;

            Publisher?.Stop();
        }

        protected override void InnerManagedDispose()
        {
            Publisher?.TryDisposeService();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Publisher = null;
            DataNotifier = null;
            VideoStreamEntityProvider = null;
            base.InnerNullifyReferencesDispose();
        }

        private void OnDataReceived(RosSensorImage data)
        {
            try
            {
                var videoFrame = BuildVideoFrame(data);
                if (videoFrame != null)
                    Publisher.Publish(videoFrame);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, $"Failed on try to adapt and update entity! Data: {data}, {ServiceDescriptionString}");
            }
        }

        private IVideoFrame<IVideoFrameMetadata> BuildVideoFrame(RosSensorImage data)
        {
            var videoStream = VideoStreamEntityProvider.GetEntity(RetrievePolicyEnum.CreateIfNotExists);
            var videoStreamId = videoStream?.Id.ToString() ?? string.Empty;

            // TODO set real values when they will be correct and remove video settings
            var encodedImage = new Image
            {
                ImageBuffer = data.Data.ToByteArray(),
                Width = VideoSettings.FrameWidth,
                Height = VideoSettings.FrameHeight,
                ContentWidth = VideoSettings.FrameWidth,
                ContentHeight = VideoSettings.FrameHeight,
                PixelFormat = VideoSettings.PixelFormat,
                EncodingFormat = "JPEG"
            };

            var nowUtc = DateTime.UtcNow;

            var frameTimeInSensor = data.Header.Stamp != null
                ? new DateTime(TimeSpan.FromSeconds(data.Header.Stamp.Sec).Ticks)
                : nowUtc;

            var metadata = new VideoFrameMetadata
            {
                VideoId = videoStreamId,
                FrameId = data.Header.FrameId,
                FrameSequence = data.Header.Seq,
                FrameTimeSensor = frameTimeInSensor,
                FrameTimeLocal = nowUtc
            };

            var videoFrame = new VideoFrame<IVideoFrameMetadata>
            {
                Metadata = metadata,
                VideoId = videoStreamId,
                FrameId = data.Header.FrameId,
                FrameSequence = data.Header.Seq,
                FrameTimeSensor = frameTimeInSensor,
                FrameTimeLocal = nowUtc,
                EncodedImage = encodedImage
            };

            return videoFrame;
        }
    }
}