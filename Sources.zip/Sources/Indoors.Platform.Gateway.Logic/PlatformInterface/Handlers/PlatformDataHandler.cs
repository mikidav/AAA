﻿using System;
using System.Reactive.Subjects;
using Indoors.Communications.Common.Subscribers;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Data;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Handlers
{
    public class PlatformDataHandler<TPlatformMessage, TPlatformData> : ServiceBase,
        IPlatformDataHandler,
        IDataNotifier<TPlatformData>
        where TPlatformMessage : class
        where TPlatformData : class
    {
        private readonly ISubject<TPlatformData> m_dataNotifiedSubject = new Subject<TPlatformData>();
        private IDisposable m_subscriptionDisposable;

        public IObservable<TPlatformData> DataNotified => m_dataNotifiedSubject;

        public ITypedObjectSubscriber<TPlatformMessage> Subscriber { get; private set; }

        public IPlatformInterfaceDataMessageAdapter<TPlatformMessage, TPlatformData> Adapter { get; private set; }

        public PlatformDataHandler(ITypedObjectSubscriber<TPlatformMessage> subscriber, IPlatformInterfaceDataMessageAdapter<TPlatformMessage, TPlatformData> adapter, ILogger logger = null, string id = null) : base(logger, id)
        {
            Subscriber = subscriber;
            Adapter = adapter;
        }

        protected override void InternalInitialize()
        {
            // no internal logic
        }

        protected override void InternalStart()
        {
            m_subscriptionDisposable = Subscriber.DataReceived.Subscribe(OnDataReceived);
        }

        protected override void InternalStop()
        {
            m_subscriptionDisposable?.Dispose();
            m_subscriptionDisposable = null;
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Adapter = null;
            Subscriber = null;

            base.InnerNullifyReferencesDispose();
        }

        private void OnDataReceived(TPlatformMessage platformMessage)
        {
            var platformData = Adapter.ToData(platformMessage);
            if (platformData != null)
                m_dataNotifiedSubject.OnNext(platformData);
        }
    }
}