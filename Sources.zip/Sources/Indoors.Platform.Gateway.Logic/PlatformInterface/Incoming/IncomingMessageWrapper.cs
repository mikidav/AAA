﻿namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Incoming
{
    public class IncomingMessageWrapper
    {
        public Subgiga.Messages.protocol_type ProtocolType { get; init; }

        public int Topic { get; set; }
        
        public byte[] Data { get; init; }

        public override string ToString()
        {
            return $"{nameof(Topic)}: {Topic}, {nameof(Data)}Length: {Data.Length}";
        }
    }
}