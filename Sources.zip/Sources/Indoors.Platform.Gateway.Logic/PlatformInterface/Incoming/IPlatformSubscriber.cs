﻿using Indoors.Communications.Common.Subscribers;
using Subgiga;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Incoming
{
    public interface IPlatformSubscriber : ITypedObjectSubscriber<IncomingMessageWrapper>
    {

    }
}