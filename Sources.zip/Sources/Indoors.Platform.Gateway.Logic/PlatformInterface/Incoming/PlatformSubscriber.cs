﻿using System;
using System.Reactive.Linq;
using Google.Protobuf;
using Indoors.Communications.Common.Subscribers;
using Indoors.Communications.Common.Types;
using Indoors.Communications.Core.Subscribe;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Incoming
{
    public class PlatformSubscriber : SubscriberBase<IncomingMessageWrapper>, IPlatformSubscriber
    {
        private IDisposable m_subscriptionDisposable;
        private IDisposable m_secondarySubscriptionDisposable;

        public IBufferSubscriber<byte[]> Subscriber { get; private set; }
        public IBufferSubscriber<byte[]> SecondarySubscriber { get; private set; }

        public IObservable<IncomingMessageWrapper> DataReceived => DataSubscribedSubject;

        public PlatformSubscriber(IBufferSubscriber<byte[]> subscriber, ILogger logger = null, string id = null) : base(logger, id)
        {
            Subscriber = subscriber;
        }

        public PlatformSubscriber(IBufferSubscriber<byte[]> subscriber, IBufferSubscriber<byte[]> secondarySubscriber, ILogger logger = null, string id = null) : base(logger, id)
        {
            Subscriber = subscriber;
            SecondarySubscriber = secondarySubscriber;
        }

        protected override void InternalInitialize()
        {
            Subscriber?.Initialize();
            SecondarySubscriber?.Initialize();
        }

        protected override void InternalStart()
        {
            m_subscriptionDisposable = Subscriber?.BufferReceived?.Where(_ => IsRunning)?.Subscribe(OnBufferSubscribed);
            m_secondarySubscriptionDisposable = SecondarySubscriber?.BufferReceived?.Where(_ => IsRunning)?.Subscribe(OnSecondaryBufferSubscribed);

            Subscriber?.Start();
            SecondarySubscriber?.Start();
        }

        protected override void InternalStop()
        {
            m_subscriptionDisposable?.Dispose();
            m_subscriptionDisposable = null;

            m_secondarySubscriptionDisposable?.Dispose();
            m_secondarySubscriptionDisposable = null;

            Subscriber?.Stop();
            SecondarySubscriber?.Stop();
        }

        protected override void InnerManagedDispose()
        {
            Subscriber?.TryDisposeService();
            SecondarySubscriber?.TryDisposeService();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Subscriber = null;
            SecondarySubscriber = null;

            base.InnerNullifyReferencesDispose();
        }

        private void OnBufferSubscribed(BufferData<byte[]> bufferData)
        {
            var gatewayMessage = Subgiga.Messages.gateway_message.Parser.ParseFrom(bufferData.Buffer, (int)bufferData.DataStartIndex, (int)bufferData.DataLength);
            if (gatewayMessage.Header == null)
            {
                Logger.LogWarning($"Skipping gateway message due to lack of header... {ServiceDescriptionString}");
                return;
            }

            var gatewayDataBuffer = gatewayMessage.Data.ToByteArray();

            var subGigaMessage = Subgiga.Messages.subgiga_message.Parser.ParseFrom(gatewayDataBuffer, 0, gatewayDataBuffer.Length);

            var dataBuffer = subGigaMessage.Data.ToByteArray();

            var incomingMessageWrapper = new IncomingMessageWrapper
            {
                ProtocolType = subGigaMessage.ProtocolType,
                Topic = subGigaMessage.TopicId,
                Data = dataBuffer
            };

            if (incomingMessageWrapper.Topic == 28 && SecondarySubscriber != null)
                return;

            InvokeHandlersSync(incomingMessageWrapper);
        }

        private void OnSecondaryBufferSubscribed(BufferData<byte[]> bufferData)
        {
            // Video Message on secondary channel.
            var rosVideo = new Subgiga.RosSensorImage { Header = new Subgiga.RosMsgHeader(), Data = Google.Protobuf.ByteString.CopyFrom(bufferData.Buffer) };
            var dataBuffer = rosVideo.ToByteArray();

            var incomingMessageWrapper = new IncomingMessageWrapper
            {
                ProtocolType = Subgiga.Messages.protocol_type.Critical,
                Topic = 28, // Video
                Data = dataBuffer
            };

            InvokeHandlersSync(incomingMessageWrapper);
        }
    }
}