﻿using System;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface
{
    public interface IDataNotifier<out TData>
    {
        IObservable<TData> DataNotified { get; }
    }
}