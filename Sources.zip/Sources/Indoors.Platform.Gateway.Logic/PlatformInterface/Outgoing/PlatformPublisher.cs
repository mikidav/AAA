﻿using System;
using Google.Protobuf;
using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Types;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing
{
    public class PlatformPublisher : ServiceBase, IPlatformPublisher
    {
        public IBufferPublisher<byte[]> Publisher { get; private set; }

        public IObservable<OperationCompletedData> PublishCompleted => Publisher?.PublishCompleted;
        public IObservable<OperationFailedData> PublishFailed => Publisher?.PublishFailed;

        public PlatformPublisher(IBufferPublisher<byte[]> publisher, ILogger<PlatformPublisher> logger = null, string id = null)
        : base(logger, id)
        {
            Publisher = publisher;
        }

        public string Publish(in OutgoingSystemInstructionMessageWrapper data)
        {
            byte[] messageBuffer;
            try
            {
                messageBuffer = data.MessageByteString.ToByteArray();
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to build message buffer! {data}, {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }

            string publishId;
            try
            {
                var bufferData = new BufferData<byte[]>(messageBuffer, 0, (ulong)messageBuffer.Length);
                publishId = Publisher.Publish(bufferData);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to publish message buffer! {data}, BufferSize: {messageBuffer.Length}, {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }

            return publishId;
        }

        public void Publish(string publishId, in OutgoingSystemInstructionMessageWrapper data)
        {
            byte[] messageBuffer;
            try
            {
                messageBuffer = data.MessageByteString.ToByteArray();
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to build message buffer! {data}, {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }

            try
            {
                var bufferData = new BufferData<byte[]>(messageBuffer, 0, (ulong)messageBuffer.Length);
                Publisher.Publish(publishId, bufferData);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to publish message buffer! {data}, BufferSize: {messageBuffer.Length}, {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }
        }

        public string Publish(in OutgoingCommandMessageWrapper data)
        {
            byte[] messageBuffer;
            try
            {
                messageBuffer = BuildMessageBuffer(data);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to build message buffer! {data}, {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }

            string publishId;
            try
            {
                var bufferData = new BufferData<byte[]>(messageBuffer, 0, (ulong)messageBuffer.Length);
                publishId = Publisher.Publish(bufferData);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to publish message buffer! {data}, BufferSize: {messageBuffer.Length}, {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }

            return publishId;
        }

        public void Publish(string publishId, in OutgoingCommandMessageWrapper data)
        {
            byte[] messageBuffer;
            try
            {
                messageBuffer = BuildMessageBuffer(data);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to build message buffer! {data}, {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }

            try
            {
                var bufferData = new BufferData<byte[]>(messageBuffer, 0, (ulong)messageBuffer.Length);
                Publisher.Publish(publishId, bufferData);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to publish message buffer! {data}, BufferSize: {messageBuffer.Length}, {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }
        }


        protected override void InternalInitialize()
        {
            Publisher.Initialize();
        }

        protected override void InternalStart()
        {
            Publisher.Start();
        }

        protected override void InternalStop()
        {
            Publisher?.Stop();
        }

        protected override void InnerManagedDispose()
        {
            Publisher?.TryDisposeService();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Publisher = null;

            base.InnerNullifyReferencesDispose();
        }

        private static byte[] BuildMessageBuffer(OutgoingCommandMessageWrapper commandMessageMessage)
        {
            var commandMessageByteString = commandMessageMessage.MessageByteString;

            var subGigaMessage = CreateSubGigaMessage(commandMessageMessage.ProtocolType, commandMessageMessage.Topic, commandMessageByteString);

            var subGigaMessageBytesString = subGigaMessage.ToByteString();

            var gatewayMessage = CreateGatewayMessage(/*TODO set meaningful ID*/42, subGigaMessageBytesString);

            var gatewayMessageBytes = gatewayMessage.ToByteArray();

            return gatewayMessageBytes;
        }

        private static Subgiga.Messages.subgiga_message CreateSubGigaMessage(Subgiga.Messages.protocol_type protocol, int topic, ByteString data)
        {
            var subGigaMessage = new Subgiga.Messages.subgiga_message
            {
                Data = data,
                ProtocolType = protocol,
                TopicId = topic
            };

            return subGigaMessage;
        }

        private static Subgiga.Messages.gateway_message CreateGatewayMessage(uint id, ByteString data)
        {
            var header = new Subgiga.Messages.gateway_header
            {
                Id = id,
                Type = 100 // 100 - Unique identifier of sub-giga
            };

            var gatewayMessage = new Subgiga.Messages.gateway_message
            {
                Header = header,
                Data = data
            };

            return gatewayMessage;
        }

    }
}