﻿using Indoors.Communications.Common.Publishers;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing
{
    public interface IPlatformPublisher : 
        ITypedObjectPublisher<OutgoingCommandMessageWrapper>, ITypedObjectPublisher<OutgoingSystemInstructionMessageWrapper>
    {

    }
}