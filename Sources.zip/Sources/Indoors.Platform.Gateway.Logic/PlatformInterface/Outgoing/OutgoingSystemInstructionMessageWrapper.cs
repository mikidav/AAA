﻿using Google.Protobuf;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing
{
    public class OutgoingSystemInstructionMessageWrapper
    {
        public ByteString MessageByteString { get; init; }

        public override string ToString()
        {
            return $"{nameof(MessageByteString)}: [{MessageByteString}]";
        }
    }
}