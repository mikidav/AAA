﻿using Google.Protobuf;
using Subgiga;

namespace Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing
{
    public class OutgoingCommandMessageWrapper
    {
        public Subgiga.Messages.protocol_type ProtocolType { get; init; }

        public int Topic { get; set; }
        
        public ByteString MessageByteString { get; init; }

        public override string ToString()
        {
            return $"{nameof(ProtocolType)}: {ProtocolType}, {nameof(Topic)}: {Topic}, {nameof(MessageByteString)}: [{MessageByteString}]";
        }
    }
}