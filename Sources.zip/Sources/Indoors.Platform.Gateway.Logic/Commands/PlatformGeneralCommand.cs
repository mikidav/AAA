﻿using Indoors.Commands.Common;
using Indoors.Communications.Common.Publishers;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Common.Commands;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Logic.Commands
{
    public class PlatformGeneralCommand<TCommandParameters, TMessage> : CommandBase<TCommandParameters>,
        IPlatformGeneralCommand<TCommandParameters>
        where TCommandParameters : IPlatformCommandParameter
        where TMessage : class
    {
        private const bool DefaultDisableExecutionLog = false;
        
        public ITypedObjectPublisher<TMessage> Publisher { get; }
        public IPlatformInterfaceCommandMessageAdapter<TCommandParameters, TMessage> Adapter { get; }

        public PlatformGeneralCommand(ITypedObjectPublisher<TMessage> publisher,
            IPlatformInterfaceCommandMessageAdapter<TCommandParameters, TMessage> adapter,
            ICommandConfig<TCommandParameters> commandConfig,
            ILogger<PlatformGeneralCommand<TCommandParameters, TMessage>> logger = null)
            : this(publisher, adapter, commandConfig?.DisableExecutionLog ?? DefaultDisableExecutionLog, logger)
        {
        }

        public PlatformGeneralCommand(ITypedObjectPublisher<TMessage> publisher,
            IPlatformInterfaceCommandMessageAdapter<TCommandParameters, TMessage> adapter,
            ICommandConfig commandConfig,
            ILogger<PlatformGeneralCommand<TCommandParameters, TMessage>> logger = null)
            : this(publisher, adapter, commandConfig?.DisableExecutionLog ?? DefaultDisableExecutionLog, logger)
        {
        }

        public PlatformGeneralCommand(ITypedObjectPublisher<TMessage> publisher,
            IPlatformInterfaceCommandMessageAdapter<TCommandParameters, TMessage> adapter,
            bool disableExecutionLog = DefaultDisableExecutionLog,
            ILogger<PlatformGeneralCommand<TCommandParameters, TMessage>> logger = null)
            : base(disableExecutionLog,
            logger)
        {
            Publisher = publisher;
            Adapter = adapter;
        }

        protected override void InternalExecute(string id, TCommandParameters parameter = default)
        {
            var message = Adapter.ToMessage(parameter);
            if (message != null)
                Publisher.Publish(id, message);
            else
                Logger.LogWarning($"Received unsupported command! Id: {id}, ParameterValue: {(parameter != null ? parameter.ToString() : "Null")}, {TypesDescriptionString}");
        }

        protected override bool InternalCanExecute(TCommandParameters parameter = default)
        {
            var isPublisherRunning = Publisher?.IsRunning == true;
            return isPublisherRunning;
        }
    }
}