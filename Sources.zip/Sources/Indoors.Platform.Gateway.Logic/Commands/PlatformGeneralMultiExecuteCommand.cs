﻿using Indoors.Commands.Common;
using Indoors.Communications.Common.Publishers;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Common.Commands;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Adapters.Commands;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Logic.Commands
{
    public class PlatformGeneralMultiExecuteCommand<TCommandParameters, TMessage> : CommandBase<TCommandParameters>,
        IPlatformGeneralCommand<TCommandParameters>
        where TCommandParameters : IPlatformCommandParameter
        where TMessage : class
    {
        private const bool DefaultDisableExecutionLog = false;

        private const uint DefaultNumberOfExecutions = 2;

        public uint NumberOfExecutions { get; }
        public ITypedObjectPublisher<TMessage> Publisher { get; }
        public IPlatformInterfaceCommandMessageAdapter<TCommandParameters, TMessage> Adapter { get; }

        public PlatformGeneralMultiExecuteCommand(uint numberOfExecutions,
            ITypedObjectPublisher<TMessage> publisher,
            IPlatformInterfaceCommandMessageAdapter<TCommandParameters, TMessage> adapter,
            ICommandConfig<TCommandParameters> commandConfig,
            ILogger<PlatformGeneralCommand<TCommandParameters, TMessage>> logger = null)
            : this(numberOfExecutions, publisher, adapter, commandConfig?.DisableExecutionLog ?? DefaultDisableExecutionLog, logger)
        {
        }

        public PlatformGeneralMultiExecuteCommand(uint numberOfExecutions,
            ITypedObjectPublisher<TMessage> publisher,
            IPlatformInterfaceCommandMessageAdapter<TCommandParameters, TMessage> adapter,
            ICommandConfig commandConfig,
            ILogger<PlatformGeneralCommand<TCommandParameters, TMessage>> logger = null)
            : this(numberOfExecutions, publisher, adapter, commandConfig?.DisableExecutionLog ?? DefaultDisableExecutionLog, logger)
        {
        }

        public PlatformGeneralMultiExecuteCommand(uint numberOfExecutions,
            ITypedObjectPublisher<TMessage> publisher,
            IPlatformInterfaceCommandMessageAdapter<TCommandParameters, TMessage> adapter,
            bool disableExecutionLog = DefaultDisableExecutionLog,
            ILogger<PlatformGeneralCommand<TCommandParameters, TMessage>> logger = null)
            : base(disableExecutionLog, logger)
        {
            Publisher = publisher;
            Adapter = adapter;

            if (numberOfExecutions == 0)
            {
                Logger.LogWarning($"Initialized with zero number of executions... set default value {DefaultNumberOfExecutions}");
                NumberOfExecutions = DefaultNumberOfExecutions;
            }
            else
            {
                NumberOfExecutions = numberOfExecutions;
            }
        }

        protected override void InternalExecute(string id, TCommandParameters parameter = default)
        {
            var message = Adapter.ToMessage(parameter);
            if (message == null)
            {
                Logger.LogWarning($"Received unsupported command! Id: {id}, ParameterValue: {(parameter != null ? parameter.ToString() : "Null")}, {TypesDescriptionString}");
                return;
            }

            for (var i = 0; i < NumberOfExecutions; i++)
            {
                Publisher.Publish(id, message);
                Logger.LogDebug($"Executed {i + 1} time.., Parameters: {parameter}, Message: {message}");
            }

        }

        protected override bool InternalCanExecute(TCommandParameters parameter = default)
        {
            var isPublisherRunning = Publisher?.IsRunning == true;
            return isPublisherRunning;
        }
    }
}