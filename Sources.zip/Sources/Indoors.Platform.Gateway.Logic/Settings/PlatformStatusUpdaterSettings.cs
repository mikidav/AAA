﻿namespace Indoors.Platform.Gateway.Logic.Settings
{
    public class PlatformStatusUpdaterSettings : IPlatformStatusUpdaterSettings
    {
        public double UpdateFrequencyHz { get; set; }

        public double BatteryVoltageLow { get; set; }

        public double BatteryVoltageHigh { get; set; }

        public override string ToString()
        {
            return $"{nameof(UpdateFrequencyHz)}: {UpdateFrequencyHz}, {nameof(BatteryVoltageLow)}: {BatteryVoltageLow}, {nameof(BatteryVoltageHigh)}: {BatteryVoltageHigh}";
        }
    }
}