﻿namespace Indoors.Platform.Gateway.Logic.Settings
{
    public interface IPlatformStatusUpdaterSettings
    {
        double UpdateFrequencyHz { get; }

        double BatteryVoltageLow { get; }
        double BatteryVoltageHigh { get; }
    }
}