﻿using System;
using Indoors.EntityFramework.Entities.Base;

namespace Indoors.Platform.Gateway.Logic.Settings
{
    public class EntityProviderSettings<TEntity> : IEntityProviderSettings<TEntity> where TEntity : IEntity
    {
        public Guid EntityId { get; set; }

        public EntityProviderSettings(string entityId)
        {
            EntityId = Guid.Parse(entityId);
        }
        
        public EntityProviderSettings()
        {
        }

        public override string ToString()
        {
            return $"{nameof(EntityId)}: {EntityId}";
        }
    }
}