﻿namespace Indoors.Platform.Gateway.Logic.Settings
{
    public interface INavigationUpdaterSettings
    {
        double UpdateFrequencyHz { get; }
    }
}