﻿using System;
using Indoors.EntityFramework.Entities.Base;

namespace Indoors.Platform.Gateway.Logic.Settings
{
    public interface IEntityProviderSettings<TEntity> where TEntity : IEntity
    {
        Guid EntityId { get; }
    }
}