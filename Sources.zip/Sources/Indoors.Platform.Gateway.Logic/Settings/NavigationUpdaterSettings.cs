﻿namespace Indoors.Platform.Gateway.Logic.Settings
{
    public class NavigationUpdaterSettings : INavigationUpdaterSettings
    {
        public double UpdateFrequencyHz { get; set; }

        public override string ToString()
        {
            return $"{nameof(UpdateFrequencyHz)}: {UpdateFrequencyHz}";
        }
    }
}