﻿using Indoors.EntityFramework.Entities.Base;

namespace Indoors.Platform.Gateway.Logic.Entities
{
    public interface IEntityProvider<out TEntity> where TEntity : IEntity
    {
        bool IsCreateRetrievePolicySupported { get; }
        
        TEntity GetEntity(RetrievePolicyEnum retrievePolicy = RetrievePolicyEnum.DefaultIfNotExists);
    }

    public enum RetrievePolicyEnum
    {
        DefaultIfNotExists,
        CreateIfNotExists
    }
}