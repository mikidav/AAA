﻿using System;
using Indoors.EntityFramework.Common;
using Indoors.EntityFramework.Entities.Base;
using Indoors.Platform.Gateway.Logic.Settings;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Logic.Entities
{
    public abstract class EntityProviderBase<TEntity> : IEntityProvider<TEntity> where TEntity : EntityBase
    {
        public IEntityRepository EntityRepository { get; }
        public IEntityProviderSettings<TEntity> Settings { get; }
        public ILogger<EntityProviderBase<TEntity>> Logger { get; }

        public virtual bool IsCreateRetrievePolicySupported => true;
        
        protected EntityProviderBase(IEntityRepository entityRepository,
            IEntityProviderSettings<TEntity> settings = null,
            ILogger<EntityProviderBase<TEntity>> logger = null)
        {
            EntityRepository = entityRepository;
            Settings = settings;
            Logger = logger;

            logger?.LogInformation($"Initialize with the settings: [{settings?.ToString() ?? "Null"}]");
        }

        public TEntity GetEntity(RetrievePolicyEnum retrievePolicy = RetrievePolicyEnum.DefaultIfNotExists)
        {
            var nullableEntityId = Settings?.EntityId;

            TEntity entity = default;

            if (nullableEntityId.HasValue)
                entity = EntityRepository.Get<TEntity>(nullableEntityId.Value);

            if (entity == default
                && retrievePolicy == RetrievePolicyEnum.CreateIfNotExists)
            {
                if (!IsCreateRetrievePolicySupported)
                    throw new Exception("Create retrieve policy is unsupported!");
                
                var entityId = nullableEntityId ?? Guid.NewGuid();
                entity = CreateEntity(entityId);
                
                EntityRepository.Add(entity);

                Logger?.LogDebug($"Entity created! Type: {typeof(TEntity).Name}, Id: {entityId}");
            }

            return entity;
        }

        protected abstract TEntity CreateEntity(Guid entityId);
    }
}