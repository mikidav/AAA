﻿using System;
using Indoors.EntityFramework.Common;
using Indoors.EntityFramework.Entities;
using Indoors.Platform.Gateway.Logic.Settings;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Logic.Entities
{
    public class NavigationEntityProvider : EntityProviderBase<Navigation>
    {
        public NavigationEntityProvider(IEntityRepository entityRepository,
            IEntityProviderSettings<Navigation> settings = null,
            ILogger<NavigationEntityProvider> logger = null)
            : base(entityRepository, settings, logger)
        {
        }

        protected override Navigation CreateEntity(Guid entityId)
        {
            return new(entityId);
        }
    }
}