﻿using System;
using Indoors.EntityFramework.Common;
using Indoors.EntityFramework.Entities;
using Indoors.Platform.Gateway.Logic.Settings;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Logic.Entities
{
    public class PlatformStatusEntityProvider : EntityProviderBase<PlatformStatus>
    {
        public IEntityProviderSettings<VideoStream> VideoStreamEntityProviderSettings { get; }
        public IEntityProviderSettings<Navigation> NavigationEntityProviderSettings { get; }

        public PlatformStatusEntityProvider(IEntityRepository entityRepository,
            IEntityProviderSettings<PlatformStatus> settings = null,
            IEntityProviderSettings<VideoStream> videoStreamEntityProviderSettings = null,
            IEntityProviderSettings<Navigation> navigationEntityProviderSettings = null,
            ILogger<PlatformStatusEntityProvider> logger = null)
            : base(entityRepository, settings, logger)
        {
            VideoStreamEntityProviderSettings = videoStreamEntityProviderSettings;
            NavigationEntityProviderSettings = navigationEntityProviderSettings;
        }

        protected override PlatformStatus CreateEntity(Guid entityId)
        {
            var videoStreamEntityId = VideoStreamEntityProviderSettings?.EntityId;
            var navigationEntityId = NavigationEntityProviderSettings?.EntityId;

            PlatformStatus platformStatus;
            
            if (videoStreamEntityId.HasValue && navigationEntityId.HasValue)
                platformStatus = new PlatformStatus(entityId) { VideoStreamEntityId = videoStreamEntityId, NavigationEntityId = navigationEntityId };
            else if (videoStreamEntityId.HasValue)
                platformStatus = new PlatformStatus(entityId) { VideoStreamEntityId = videoStreamEntityId };
            else if (navigationEntityId.HasValue)
                platformStatus = new PlatformStatus(entityId) { NavigationEntityId = navigationEntityId };
            else
                platformStatus = new PlatformStatus(entityId);

            return platformStatus;
        }
    }
}