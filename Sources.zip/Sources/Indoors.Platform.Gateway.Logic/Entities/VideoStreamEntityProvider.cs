﻿using System;
using Indoors.EntityFramework.Common;
using Indoors.EntityFramework.Entities;
using Indoors.Platform.Gateway.Logic.Settings;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Logic.Entities
{
    public class VideoStreamEntityProvider : EntityProviderBase<VideoStream>
    {
        public VideoStreamEntityProvider(IEntityRepository entityRepository,
            IEntityProviderSettings<VideoStream> settings = null,
            ILogger<VideoStreamEntityProvider> logger = null)
            : base(entityRepository, settings, logger)
        {
        }

        protected override VideoStream CreateEntity(Guid entityId)
        {
            return new(entityId);
        }
    }
}