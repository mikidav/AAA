﻿using Indoors.Services.Common;

namespace Indoors.Platform.Gateway.Logic.DeviceAdapters
{
    public interface IDeviceAdapterIncomingHandler : IService
    {

    }
}