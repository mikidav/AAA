﻿using System.Collections.Generic;
using System.Linq;
using Indoors.Gateways.Common.DeviceAdapters;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Logic.DeviceAdapters
{
    public class PlatformGatewayDeviceAdapter : ServiceBase, IDeviceAdapter
    {
        public IList<IDeviceAdapterOutgoingHandler> OutgoingDataHandlers { get; private set; }
        public IList<IDeviceAdapterIncomingHandler> IncomingDataHandlers { get; private set; }
        public PlatformGatewayDeviceAdapter(IEnumerable<IDeviceAdapterOutgoingHandler> outgoingDataHandlers = null,
            IEnumerable<IDeviceAdapterIncomingHandler> incomingDataHandlers = null,
            ILogger<PlatformGatewayDeviceAdapter> logger = null,
            string id = null) : base(logger,
            id)
        {
            OutgoingDataHandlers = outgoingDataHandlers?.ToList() ?? Enumerable.Empty<IDeviceAdapterOutgoingHandler>().ToList();
            IncomingDataHandlers = incomingDataHandlers?.ToList() ?? Enumerable.Empty<IDeviceAdapterIncomingHandler>().ToList();
        }

        protected override void InternalInitialize()
        {
            OutgoingDataHandlers.InitializeServices();
            
            IncomingDataHandlers.InitializeServices();
        }

        protected override void InternalStart()
        {
            OutgoingDataHandlers.StartServices();
            
            IncomingDataHandlers.StartServices();
        }

        protected override void InternalStop()
        {
            IncomingDataHandlers.StopServices();
            
            OutgoingDataHandlers.StopServices();
        }

        protected override void InnerManagedDispose()
        {
            OutgoingDataHandlers.DisposeServices();
            OutgoingDataHandlers.ClearIfIsNotReadyOnly();
            
            IncomingDataHandlers.DisposeServices();
            IncomingDataHandlers.ClearIfIsNotReadyOnly();

            base.InnerUnmanagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            OutgoingDataHandlers = null;
            
            IncomingDataHandlers = null;
            
            base.InnerNullifyReferencesDispose();
        }
    }
}