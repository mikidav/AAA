﻿using Indoors.Platform.Gateway.Logic.PlatformInterface.Outgoing;
using Indoors.Services.Common;

namespace Indoors.Platform.Gateway.Logic.DeviceAdapters
{
    public class DeviceAdapterOutgoingHandler : ServiceBase, IDeviceAdapterOutgoingHandler
    {
        public IPlatformPublisher PlatformPublisher { get; private set; }

        public DeviceAdapterOutgoingHandler(IPlatformPublisher platformPublisher)
        {
            PlatformPublisher = platformPublisher;
        }
        
        protected override void InternalInitialize()
        {
            PlatformPublisher.Initialize();
        }

        protected override void InternalStart()
        {
            PlatformPublisher.Start();
        }

        protected override void InternalStop()
        {
            PlatformPublisher?.Stop();
        }

        protected override void InnerManagedDispose()
        {
            PlatformPublisher?.TryDisposeService();
            
            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            PlatformPublisher = null;
            
            base.InnerNullifyReferencesDispose();
        }
    }
}