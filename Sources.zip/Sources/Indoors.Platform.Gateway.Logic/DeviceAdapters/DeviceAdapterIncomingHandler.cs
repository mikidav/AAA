﻿using System.Collections.Generic;
using System.Linq;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Handlers;
using Indoors.Platform.Gateway.Logic.PlatformInterface.Incoming;
using Indoors.Services.Common;

namespace Indoors.Platform.Gateway.Logic.DeviceAdapters
{
    public class DeviceAdapterIncomingHandler : ServiceBase, IDeviceAdapterIncomingHandler
    {
        public IPlatformSubscriber PlatformSubscriber { get; private set; }
        public IList<IPlatformDataHandler> PlatformDataHandlers { get; private set; }

        public DeviceAdapterIncomingHandler(IPlatformSubscriber platformSubscriber, IEnumerable<IPlatformDataHandler> platformDataHandlers)
        {
            PlatformSubscriber = platformSubscriber;
            PlatformDataHandlers = platformDataHandlers?.ToList() ?? Enumerable.Empty<IPlatformDataHandler>().ToList();
        }

        protected override void InternalInitialize()
        {
            PlatformSubscriber.Initialize();

            PlatformDataHandlers.InitializeServices();
        }

        protected override void InternalStart()
        {
            PlatformSubscriber.Start();

            PlatformDataHandlers.StartServices();
        }

        protected override void InternalStop()
        {
            PlatformSubscriber?.Stop();

            PlatformDataHandlers?.StopServices();
        }

        protected override void InnerManagedDispose()
        {
            PlatformSubscriber?.TryDisposeService();

            PlatformDataHandlers?.DisposeServices();
            PlatformDataHandlers?.ClearIfIsNotReadyOnly();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            PlatformSubscriber = null;

            PlatformDataHandlers = null;

            base.InnerNullifyReferencesDispose();
        }
    }
}