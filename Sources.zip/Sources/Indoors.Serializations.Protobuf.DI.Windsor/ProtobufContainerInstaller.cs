﻿using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Indoors.Serializations.Common;

namespace Indoors.Serializations.Protobuf.DI.Windsor
{
    /// <summary>
    /// A windsor container installer that registers Google.Protobuf serializer.
    /// </summary>
    public class ProtobufContainerInstaller : IWindsorInstaller
    {
        /// <summary>
        /// Installs logic services and interfaces into the supplied container.
        /// </summary>
        /// <param name="container">The container to hold the services.</param>
        /// <param name="store"></param>
        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            RegisterSerializers(container);

            RegisterDeserializers(container);
        }

        private static void RegisterSerializers(IWindsorContainer container)
        {
            container.Register(Component
                .For<ICustomSerializer>()
                .ImplementedBy<ProtobufSerializer>()
                .Named(nameof(ProtobufSerializer))
                .LifestyleSingleton());
        }

        private static void RegisterDeserializers(IWindsorContainer container)
        {
            container.Register(Component
                .For<ICustomDeserializer>()
                .ImplementedBy<ProtobufDeserializer>()
                .Named(nameof(ProtobufDeserializer))
                .LifestyleSingleton());
        }
    }
}
