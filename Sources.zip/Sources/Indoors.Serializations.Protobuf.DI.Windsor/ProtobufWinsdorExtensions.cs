﻿using Castle.MicroKernel.Registration;
using Castle.Windsor;

namespace Indoors.Serializations.Protobuf.DI.Windsor
{
    public static class ProtobufWindsorExtensions
    {
        public static bool RegisterFileDescriptorProvider<TFileDescriptorProvider>(this IWindsorContainer container, string name = null)
            where TFileDescriptorProvider : IFileDescriptorProvider
        {
            var fileDescriptorTypeName = name ?? typeof(TFileDescriptorProvider).Name;
            var componentAlreadyRegistered = container.Kernel.HasComponent(fileDescriptorTypeName);
            if (componentAlreadyRegistered)
                return false;

            container.Register(Component
                .For<IFileDescriptorProvider>()
                .ImplementedBy<TFileDescriptorProvider>()
                .Named(fileDescriptorTypeName)
                .LifestyleSingleton());
            return true;
        }
    }
}