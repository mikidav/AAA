﻿namespace HwndExtensions.Host
{
    public interface IHwndHostManager
    {
        HwndHostGroup HwndHostGroup { get; }
    }
}
