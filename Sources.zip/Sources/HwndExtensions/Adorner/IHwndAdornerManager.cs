﻿namespace HwndExtensions.Adorner
{
    internal interface IHwndAdornerManager
    {
        HwndAdornerGroup AdornerGroup { get; }
    }
}
