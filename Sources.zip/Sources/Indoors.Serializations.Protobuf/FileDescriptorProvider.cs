﻿using System.Collections.Generic;
using Google.Protobuf.Reflection;

namespace Indoors.Serializations.Protobuf
{
    public class FileDescriptorProvider : IFileDescriptorProvider
    {
        public IEnumerable<FileDescriptor> Descriptors { get; }

        public FileDescriptorProvider(IEnumerable<FileDescriptor> fileDescriptors)
        {
            Descriptors = fileDescriptors;
        }
    }
}