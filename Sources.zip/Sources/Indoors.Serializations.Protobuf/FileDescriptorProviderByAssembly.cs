﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Google.Protobuf.Reflection;

namespace Indoors.Serializations.Protobuf
{
    public class FileDescriptorProviderByAssembly : IFileDescriptorProvider
    {
        public IEnumerable<FileDescriptor> Descriptors { get; }

        public FileDescriptorProviderByAssembly(Assembly assembly)
        {
            var fileDescriptors = assembly.GetTypes()
                .Where(type => type.IsClass && type.Name.EndsWith("Reflection"))
                .SelectMany(type => type.GetProperties())
                .Where(info => info.Name == "Descriptor")
                .Select(info => info.GetValue(null))
                .Cast<FileDescriptor>()
                .ToList();

            Descriptors = fileDescriptors;
        }
    }
}