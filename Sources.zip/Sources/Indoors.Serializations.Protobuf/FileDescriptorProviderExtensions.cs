﻿using System.Collections.Generic;
using System.Linq;
using Google.Protobuf.Reflection;

namespace Indoors.Serializations.Protobuf
{
    public static class FileDescriptorProviderExtensions
    {
        public static IFileDescriptorProvider Join(this IFileDescriptorProvider fileDescriptorProvider1,
            IFileDescriptorProvider fileDescriptorProvider2)
        {
            var list = fileDescriptorProvider1.Descriptors.ToList();
            list.AddRange(fileDescriptorProvider2.Descriptors);
            return !list.Any() ? null : new FileDescriptorProvider(list);
        }

        public static IFileDescriptorProvider Join(this IFileDescriptorProvider fileDescriptorProvider,
           IEnumerable<IFileDescriptorProvider> fileDescriptorProviderList)
        {
            var list = fileDescriptorProvider.Descriptors.ToList();
            foreach (var fileDescriptor in fileDescriptorProviderList)
                list.AddRange(fileDescriptor.Descriptors);
            return !list.Any() ? null : new FileDescriptorProvider(list);
        }

        public static IFileDescriptorProvider JoinToOneIFileDescriptorProvider(this IEnumerable<IFileDescriptorProvider> fileDescriptorProviderList)
        {
            var list = new List<FileDescriptor>();
            foreach (var fileDescriptor in fileDescriptorProviderList)
                list.AddRange(fileDescriptor.Descriptors);
            return !list.Any() ? null : new FileDescriptorProvider(list);
        }
    }
}
