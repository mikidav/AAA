﻿using System.Collections.Generic;
using Google.Protobuf.Reflection;

namespace Indoors.Serializations.Protobuf
{
    public interface IFileDescriptorProvider
    {
        IEnumerable<FileDescriptor> Descriptors { get; }
    }
}