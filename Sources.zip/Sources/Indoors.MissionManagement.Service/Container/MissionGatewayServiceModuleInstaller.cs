﻿using Autofac;
using Indoors.Commands.Common;
using Indoors.Commands.Handlers.Common;
using Indoors.Commands.Messages.Common;
using Indoors.Communications.RabbitMQ.DI.Autofac;
using Indoors.DomainIcd.Mission;
using Indoors.DomainIcd.Mission.Messages;
using Indoors.EntityFramework.Entities;
using Indoors.EntityFramework.Proxy.Modules;
using Indoors.MissionManagement.Adapters.Commands;
using Indoors.MissionManagement.Common.CommandParameters;
using Indoors.MissionManagement.Common.Commands;
using Indoors.MissionManagement.Logic.Commands;
using Indoors.Serializations.Protobuf.DI.Autofac;

namespace Indoors.MissionManagement.Service.Container
{
    public class MissionServiceModuleInstaller : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            RegisterEntities(builder);

            RegisterCommands(builder);
        }

        private static void RegisterEntities(ContainerBuilder builder)
        {
            builder.RegisterEntityType<PlatformStatus>();
        }

        private static void RegisterCommands(ContainerBuilder builder)
        {
            builder.RegisterFileDescriptorProvider<MissionDomainIcdDescriptorProvider>();

            RegisterMissionGeneralCommandHandler<MissionStartCommandParameters,
                MissionStartCommandMessage,
                MissionDomainIcdStartCommandAdapter>(builder);

            RegisterMissionGeneralCommandHandler<MissionStopCommandParameters,
                MissionStopCommandMessage,
                MissionDomainIcdStopCommandAdapter>(builder);

            RegisterMissionGeneralCommandHandler<MissionTakeOffCommandParameters,
                MissionTakeOffCommandMessage,
                MissionDomainIcdTakeOffCommandAdapter>(builder);

            RegisterMissionGeneralCommandHandler<MissionLandCommandParameters,
                MissionLandCommandMessage,
                MissionDomainIcdLandCommandAdapter>(builder);
        }
        
        private static void RegisterMissionGeneralCommandHandler
            <TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter>(ContainerBuilder builder)
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IMissionCommandParameters
        {
            RegisterMissionCommandHandler
            <MissionGeneralCommand<TCommandParameter>,
                TCommandParameter,
                TCommandDomainMessage,
                TDomainMessageAdapter>(builder);
        }

        private static void RegisterMissionCommandHandler
            <TCommand, TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter>(ContainerBuilder container)
            where TCommand : class, IMissionGeneralCommand<TCommandParameter>
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IMissionCommandParameters
        {
            RegisterCommandHandler
            <IMissionGeneralCommand<TCommandParameter>,
                TCommand,
                TCommandParameter,
                TCommandDomainMessage,
                TDomainMessageAdapter>(container);
        }

        private static void RegisterCommandHandler
        <TCommandInterface, TCommand, TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter>(ContainerBuilder builder)
            where TCommandInterface : ICommand<TCommandParameter>
            where TCommand : class, TCommandInterface
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IMissionCommandParameters
        {
            builder.RegisterType<TCommand>()
                .As<TCommandInterface>()
                .SingleInstance();

            builder.RegisterRabbitMqSubscriber<TCommandDomainMessage>();

            builder.RegisterType<TDomainMessageAdapter>()
                .As<IMissionDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>, ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage>>()
                .SingleInstance();

            builder.RegisterType<CommandMessageHandler<TCommandParameter, TCommandDomainMessage>>()
                .As<ICommandMessageHandler, ICommandNotifier<TCommandParameter>>()
                .SingleInstance();

            builder.RegisterType<CommandHandler<TCommandInterface, TCommandParameter>>()
                .As<ICommandHandler>()
                .SingleInstance();
        }
    }
}