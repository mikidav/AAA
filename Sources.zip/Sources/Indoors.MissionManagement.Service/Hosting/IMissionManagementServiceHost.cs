﻿using System;
using System.Collections.Generic;
using System.Text;
using Indoors.Services.Common;

namespace Indoors.MissionManagement.Service.Hosting
{
    public interface IMissionManagementServiceHost : IService
    {
    }
}
