﻿using System.Collections.Generic;
using System.Linq;
using Indoors.Commands.Handlers.Common;
using Indoors.Commands.Messages.Common;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.MissionManagement.Service.Hosting
{
    public class MissionManagementServiceHost : ServiceBase, IMissionManagementServiceHost
    {
        private List<ICommandHandler> _commandHandlers;
        private List<ICommandMessageHandler> _commandMessageHandlers;

        public MissionManagementServiceHost(ILogger<MissionManagementServiceHost> logger,
            IEnumerable<ICommandHandler> commandHandlers = null,
            IEnumerable<ICommandMessageHandler> commandMessageHandlers = null)
            : base(logger)
        {
            _commandHandlers = commandHandlers?.ToList() ?? Enumerable.Empty<ICommandHandler>().ToList();
            _commandMessageHandlers = commandMessageHandlers?.ToList() ?? Enumerable.Empty<ICommandMessageHandler>().ToList();
        }
        
        protected override void InternalInitialize()
        {
            _commandHandlers.InitializeServices();
            _commandMessageHandlers.InitializeServices();
        }

        protected override void InternalStart()
        {
            _commandHandlers.StartServices();
            _commandMessageHandlers.StartServices();
        }

        protected override void InternalStop()
        {
            _commandHandlers.StopServices();
            _commandMessageHandlers.StopServices();
        }

        protected override void InnerManagedDispose()
        {
            _commandMessageHandlers?.DisposeServices();
            _commandMessageHandlers?.ClearIfIsNotReadyOnly();
            _commandHandlers?.DisposeServices();
            _commandHandlers?.ClearIfIsNotReadyOnly();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            _commandMessageHandlers = null;
            _commandHandlers = null;

            base.InnerNullifyReferencesDispose();
        }
    }
}
