﻿using Google.Protobuf.Reflection;
using Indoors.DomainIcd.Entities.Messages;
using Indoors.Serializations.Protobuf;
using System.Collections.Generic;

namespace Indoors.DomainIcd.Entities
{
    public class DomainEntitiesFileDescriptor : IFileDescriptorProvider
    {
        public IEnumerable<FileDescriptor> Descriptors { get; }

        public DomainEntitiesFileDescriptor()
        {
            Descriptors = new[]
            {
                EntitiesMessagesReflection.Descriptor
            };
        }
    }
}
