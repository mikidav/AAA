﻿using Indoors.EntityFramework.Entities.Base;
using System;
using System.Collections.Generic;

namespace Indoors.EntityFramework.Common.Data
{
    //Data for handling the operations
    public class OperationData
    {
        public Guid CorrelationId { get; set; }
        public IEnumerable<IEntity> Entities { get; set; }
        public Type EntityType { get; set; }
    }
}
