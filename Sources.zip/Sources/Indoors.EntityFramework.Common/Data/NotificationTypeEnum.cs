﻿namespace Indoors.EntityFramework.Common.Data
{
    public enum NotificationTypeEnum
    {
        Added,
        Updated,
        Deleted
    }
}