﻿using Indoors.EntityFramework.Entities.Base;

namespace Indoors.EntityFramework.Common.Data
{
    //Data for handling the notifications
    public class NotificationData
    {
        public IEntity Entity { get; set; }
        public NotificationTypeEnum Type { get; set; }
    }
}
