﻿using System;
using System.Reactive;
using System.Reactive.Linq;
using System.Threading.Tasks;

namespace Indoors.EntityFramework.Common.Extensions
{
    public static class RxExtensions
    {
        public static IDisposable SubscribeAsync<TData>(this IObservable<TData> source, Func<Task> asyncAction,
            Action<Exception> handler = null)
        {
            async Task<Unit> WrappedAsyncAction(TData data)
            {
                await asyncAction();
                return Unit.Default;
            }

            return handler == null
                ? source.SelectMany(WrappedAsyncAction).Subscribe(_ => { })
                : source.SelectMany(WrappedAsyncAction).Subscribe(_ => { }, handler);
        }

        public static IDisposable SubscribeAsync<TData>(this IObservable<TData> source, Func<TData, Task> asyncAction,
            Action<Exception> handler = null)
        {
            async Task<Unit> WrappedAsyncAction(TData data)
            {
                await asyncAction(data);
                return Unit.Default;
            }

            return handler == null
                ? source.SelectMany(WrappedAsyncAction).Subscribe(_ => { })
                : source.SelectMany(WrappedAsyncAction).Subscribe(_ => { }, handler);
        }
    }
}