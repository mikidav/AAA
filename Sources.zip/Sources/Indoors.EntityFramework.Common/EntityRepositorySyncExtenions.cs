﻿using System;
using System.Collections.Generic;
using System.Threading;
using Indoors.EntityFramework.Entities.Base;

namespace Indoors.EntityFramework.Common
{
    public static class EntityRepositorySyncExtensions
    {
        public static void Add<TEntity>(this IEntityRepository entityRepository, TEntity entity, CancellationToken cancellationToken = default)
            where TEntity : class, IEntity
        {
            if (entityRepository == null)
                throw new ArgumentNullException(nameof(entityRepository));

            entityRepository.AddAsync(entity, cancellationToken).GetAwaiter().GetResult();
        }

        public static IEnumerable<TEntity> Get<TEntity>(this IEntityRepository entityRepository, CancellationToken cancellationToken = default) where TEntity : class, IEntity
        {
            if (entityRepository == null)
                throw new ArgumentNullException(nameof(entityRepository));

            var enumerable = entityRepository.GetAsync<TEntity>(cancellationToken).GetAwaiter().GetResult();
            return enumerable;
        }

        public static TEntity Get<TEntity>(this IEntityRepository entityRepository, Guid id, CancellationToken cancellationToken = default) where TEntity : class, IEntity
        {
            if (entityRepository == null)
                throw new ArgumentNullException(nameof(entityRepository));

            var result = entityRepository.GetAsync<TEntity>(id, cancellationToken).GetAwaiter().GetResult();
            return result;
        }

        public static void Update<TEntity>(this IEntityRepository entityRepository, TEntity entity, CancellationToken cancellationToken = default) where TEntity : class, IEntity
        {
            if (entityRepository == null)
                throw new ArgumentNullException(nameof(entityRepository));

            entityRepository.UpdateAsync(entity, cancellationToken).GetAwaiter().GetResult();
        }

        public static void Delete<TEntity>(this IEntityRepository entityRepository, TEntity entity, CancellationToken cancellationToken = default) where TEntity : class, IEntity
        {
            if (entityRepository == null)
                throw new ArgumentNullException(nameof(entityRepository));

            entityRepository.DeleteAsync(entity, cancellationToken).GetAwaiter().GetResult();
        }
    }
}