﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Indoors.EntityFramework.Entities.Base;

namespace Indoors.EntityFramework.Common
{
    public static class EntityIdExtensions
    {
        public static async Task<TEntity> GetEntityAsync<TEntity>(
            this EntityId<Guid> entityId,
            IEntityRepository entityRepository,
            CancellationToken cancellationToken = default)
        where TEntity : class, IEntity
        {
            if (entityId == null)
                throw new ArgumentNullException(nameof(entityId));

            if (entityRepository == null)
                throw new ArgumentNullException(nameof(entityRepository));

            var entity = await entityRepository.GetAsync<TEntity>(entityId, cancellationToken);
            return entity;
        }

        public static TEntity GetEntity<TEntity>(
            this EntityId<Guid> entityId,
            IEntityRepository entityRepository,
            CancellationToken cancellationToken = default)
            where TEntity : class, IEntity
        {
            if (entityId == null)
                throw new ArgumentNullException(nameof(entityId));

            if (entityRepository == null)
                throw new ArgumentNullException(nameof(entityRepository));

            var entity = entityRepository.Get<TEntity>(entityId, cancellationToken);
            return entity;
        }
    }
}