﻿using System;
using System.Collections.Generic;
using System.Threading;
using Indoors.EntityFramework.Common.Data;
using Indoors.EntityFramework.Common.Proxy;
using Indoors.EntityFramework.Entities.Base;

namespace Indoors.EntityFramework.Common
{
    public static class EntityRepositoryProxySyncExtensions
    {
        public static void Notify<TEntity>(this IEntityRepositoryProxy entityRepositoryProxy, NotificationData notificationData, CancellationToken cancellationToken = default)
            where TEntity : class, IEntity
        {
            if (entityRepositoryProxy == null)
                throw new ArgumentNullException(nameof(entityRepositoryProxy));

            entityRepositoryProxy.NotifyAsync<TEntity>(notificationData, cancellationToken).GetAwaiter().GetResult();
        }
    }
}