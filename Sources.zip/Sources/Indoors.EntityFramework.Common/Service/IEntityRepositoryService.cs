﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Indoors.EntityFramework.Common.Data;
using Indoors.EntityFramework.Entities.Base;
using Indoors.EntityFramework.Entities.Enums;

namespace Indoors.EntityFramework.Common.Service
{
    public interface IEntityRepositoryService : IEntityRepository
    {
        /// <summary>
        /// Register type of IEntity in the repository cache
        /// </summary>
        /// <param name="type">Type of concrete implementation of IEntity</param>
        void AddTypeToRepository(Type type);

        /// <summary>
        /// Get all the entities of TEntity that are in the cache repository
        /// </summary>
        Task FireAllAsync<TEntity>(Guid correlationId, CancellationToken cancellationToken = default) where TEntity : class, IEntity;

        /// <summary>
        /// Save the changes that arrived from the proxies
        /// </summary>
        Task HandleNotificationAsync<TEntity>(TEntity entity, NotificationTypeEnum notificationType, CancellationToken cancellationToken = default) where TEntity : class, IEntity;

        /// <summary>
        /// Get the operational data for publish it to the proxies
        /// </summary>
        IObservable<OperationData> AllEntitiesObservable { get; }
    }
}
