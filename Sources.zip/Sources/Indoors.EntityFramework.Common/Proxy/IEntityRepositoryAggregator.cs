﻿using Indoors.EntityFramework.Entities.Base;

namespace Indoors.EntityFramework.Common.Proxy
{
    public interface IEntityRepositoryAggregator : IEntityRepositoryProxy, INotificationEventAggregator
    {
    }
}
