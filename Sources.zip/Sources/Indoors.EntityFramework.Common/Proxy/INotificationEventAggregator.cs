﻿using System;
using Indoors.EntityFramework.Entities.Base;

namespace Indoors.EntityFramework.Common.Proxy
{
    public interface INotificationEventAggregator
    {
        IObservable<IEntity> AddedObservable { get; }
        IObservable<IEntity> UpdatedObservable { get; }
        IObservable<IEntity> DeletedObservable {get;}
    }
}
