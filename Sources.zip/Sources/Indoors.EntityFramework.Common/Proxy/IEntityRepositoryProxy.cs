﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Indoors.EntityFramework.Common.Data;
using Indoors.EntityFramework.Entities.Base;

namespace Indoors.EntityFramework.Common.Proxy
{
    /// <summary>
    /// IEntityRepositoryProxy serve the Proxy implementation 
    /// Consumers of proxy need to consume IEntityRepository only
    /// </summary>
    public interface IEntityRepositoryProxy : IEntityRepository
    {
        /// <summary>
        /// Register type of IEntity in the repository cache
        /// </summary>
        /// <param name="type">Type of concrete implementation of IEntity</param>
        void AddTypeToRepository(Type type);
        
        /// <summary>
        /// Load the repository in new entities that came from external source
        /// </summary>
        void Load<TEntity>(OperationData data) where TEntity : class, IEntity;

        /// <summary>
        /// Update the cache repository and notify the consumer of incoming notifications
        /// </summary>
        Task NotifyAsync<TEntity>(NotificationData data, CancellationToken cancellationToken = default) where TEntity : class, IEntity;

        /// <summary>
        /// Raise request for loading the repository from external source
        /// </summary>
        IObservable<Guid> LoadRequestObservable { get; }

        /// <summary>
        /// Notify to external source that local changes has been made
        /// </summary>
        IObservable<NotificationData> NotificationObservable { get; }
    }
}
