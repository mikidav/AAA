﻿using Indoors.EntityFramework.Entities.Base;
using Indoors.Services.Common;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Indoors.EntityFramework.Common
{
    public interface IEntityRepository : IService
    {
        Task AddAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default) where TEntity : class, IEntity;
        Task<IEnumerable<TEntity>> GetAsync<TEntity>(CancellationToken cancellationToken = default) where TEntity : class, IEntity;
        Task<TEntity> GetAsync<TEntity>(Guid id, CancellationToken cancellationToken = default) where TEntity : class, IEntity;
        Task UpdateAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default) where TEntity : class, IEntity;
        Task DeleteAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default) where TEntity : class, IEntity;
    }
}
