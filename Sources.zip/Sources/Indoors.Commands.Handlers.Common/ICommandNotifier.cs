using System;

namespace Indoors.Commands.Handlers.Common
{
    public interface ICommandNotifier<TCommandParameter>
    {
        IObservable<(string id, TCommandParameter parameter)> CommandReceived { get; }
    }
}