using Indoors.Services.Common;

namespace Indoors.Commands.Handlers.Common
{
    public interface ICommandHandler : IService
    {
        
    }
}