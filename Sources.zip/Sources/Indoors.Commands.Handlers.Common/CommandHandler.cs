using System;
using Indoors.Commands.Common;
using Indoors.Services.Common;

namespace Indoors.Commands.Handlers.Common
{
    public class CommandHandler<TCommand, TCommandParameter> : ServiceBase, ICommandHandler
        where TCommand : ICommand<TCommandParameter>
    {
        private IDisposable m_commandReceivedDisposable;

        public TCommand Command { get; }
        public ICommandNotifier<TCommandParameter> CommandReceiver { get; }

        public CommandHandler(TCommand command, ICommandNotifier<TCommandParameter> commandNotifier)
        {
            Command = command ?? throw new ArgumentNullException(nameof(command));
            CommandReceiver = commandNotifier ?? throw new ArgumentNullException(nameof(commandNotifier));
        }

        protected override void InternalInitialize()
        {

        }

        protected override void InternalStart()
        {
            m_commandReceivedDisposable = CommandReceiver.CommandReceived.Subscribe(tuple => OnCommandReceived(tuple.id, tuple.parameter));
        }

        protected override void InternalStop()
        {
            m_commandReceivedDisposable.Dispose();
            m_commandReceivedDisposable = null;
        }

        private void OnCommandReceived(string id, TCommandParameter parameter)
        {
            if (Command.CanExecute(parameter))
                Command.Execute(id, parameter);
        }
    }
}