﻿using System;
using Google.Protobuf.Reflection;
using Indoors.Serializations.Protobuf.Unit.Tests.FileDescriptors;
using Indoors.Serializations.Protobuf.Unit.Tests.Helpers;
using Indoors.Serializations.Protobuf.Unit.Tests.Types;
using Xunit;

namespace Indoors.Serializations.Protobuf.Unit.Tests
{
    public class ProtobufDeserializerTests
    {
        [Fact]
        public void ProtobufDeserializer_InstanceCreation_Initialized_Success()
        {
            // Arrange
            var testsStructsFileDescriptorProvider = new TestsStructsFileDescriptorProvider();

            // Act
            var protobufDeserializer = new ProtobufDeserializer(testsStructsFileDescriptorProvider);

            // Assert
            Assert.True(protobufDeserializer.IsInitialized);
        }

        [Fact]
        public void ProtobufDeserializer_InstanceCreation_NotInitialized_Success()
        {
            // Arrange
            var emptyFileDescriptorsArray = new FileDescriptor[0];

            // Act
            var protobufDeserializer = new ProtobufDeserializer(emptyFileDescriptorsArray);

            // Assert
            Assert.False(protobufDeserializer.IsInitialized);
        }

        [Fact]
        public void ProtobufDeserializer_InstanceCreation_SingleFileDescriptor_Success()
        {
            // Arrange
            var testsStructsFileDescriptorProvider = new TestsStructsFileDescriptorProvider();

            var expectedFileDescriptorsCount = ProtobufTestsHelper.GetCountOfMessageDescriptors(testsStructsFileDescriptorProvider);

            // Act
            var protobufDeserializer = new ProtobufDeserializer(testsStructsFileDescriptorProvider);


            // Act & Assert
            ProtobufTestsHelper.AssertInnerDictionaries(protobufDeserializer, expectedFileDescriptorsCount);
        }

        [Fact]
        public void ProtobufDeserializer_InstanceCreation_TwoFileDescriptors_Success()
        {
            // Arrange
            var testsStructsFileDescriptorProvider = new TestsStructsFileDescriptorProvider();
            var anotherTestsStructsFileDescriptorProvider = new AnotherTestsStructsFileDescriptorProvider();

            var expectedFileDescriptorsCount = ProtobufTestsHelper.GetCountOfMessageDescriptors(testsStructsFileDescriptorProvider, anotherTestsStructsFileDescriptorProvider);

            // Act
            var protobufDeserializer = new ProtobufDeserializer(testsStructsFileDescriptorProvider, anotherTestsStructsFileDescriptorProvider);

            // Assert
            ProtobufTestsHelper.AssertInnerDictionaries(protobufDeserializer, expectedFileDescriptorsCount);
        }

        [Fact]
        public void ProtobufDeserializer_InstanceCreation_DistinctFileDescriptor_Success()
        {
            // Arrange
            var testsStructsFileDescriptorProvider = new TestsStructsFileDescriptorProvider();
            var expectedFileDescriptorsCount = ProtobufTestsHelper.GetCountOfMessageDescriptors(testsStructsFileDescriptorProvider);

            // Act
            var protobufDeserializer = new ProtobufDeserializer(testsStructsFileDescriptorProvider, testsStructsFileDescriptorProvider);

            // Assert
            ProtobufTestsHelper.AssertInnerDictionaries(protobufDeserializer, expectedFileDescriptorsCount);
        }

        [Fact]
        public void ProtobufDeserializer_Deserialize_TypeNotSupported_Exception()
        {
            // Arrange
            var testsStructsFileDescriptorProvider = new TestsStructsFileDescriptorProvider();
            var protobufDeserializer = new ProtobufDeserializer(testsStructsFileDescriptorProvider);

            // Act & Assert
            Assert.Throws<ArgumentException>(() => protobufDeserializer.Deserialize(typeof(int), new byte[0], out _));
        }

        [Fact]
        public void ProtobufDeserializer_Deserialize_TypeNotExists_Exception()
        {
            // Arrange
            var testsStructsFileDescriptorProvider = new TestsStructsFileDescriptorProvider();
            var protobufDeserializer = new ProtobufDeserializer(testsStructsFileDescriptorProvider);

            // Act & Assert
            Assert.Throws<Exception>(() => protobufDeserializer.Deserialize(typeof(AnotherTestStruct), new byte[0], out _));
        }

        [Fact]
        public void ProtobufDeserializer_Deserialize_NotInitialized_Exception()
        {
            // Arrange
            var emptyFileDescriptorsArray = new FileDescriptor[0];
            var protobufDeserializer = new ProtobufDeserializer(emptyFileDescriptorsArray);

            // Act & Assert
            Assert.False(protobufDeserializer.IsInitialized);
            Assert.Throws<Exception>(() => protobufDeserializer.Deserialize(typeof(TestStruct), new byte[0], out _));
        }

    }
}
