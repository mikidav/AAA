﻿using Castle.MicroKernel.Handlers;
using Castle.MicroKernel.Resolvers.SpecializedResolvers;
using Castle.Windsor;
using Indoors.Serializations.Common;
using Indoors.Serializations.Protobuf.DI.Windsor;
using Indoors.Serializations.Protobuf.Unit.Tests.FileDescriptors;
using Indoors.Serializations.Protobuf.Unit.Tests.Helpers;
using Xunit;

namespace Indoors.Serializations.Protobuf.Unit.Tests
{
    public class ProtobufWindsorDiTests
    {
        private readonly IWindsorContainer m_container;

        public ProtobufWindsorDiTests()
        {
            m_container = new WindsorContainer();
            m_container.Kernel.Resolver.AddSubResolver(new CollectionResolver(m_container.Kernel));
        }

        [Fact]
        public void ProtobufWindsorDi_RegisterModule_IsRegistered_Success()
        {
            // Act
            m_container.Install(new ProtobufContainerInstaller());

            // Assert
            Assert.True(m_container.Kernel.HasComponent(typeof(ICustomSerializer)));

            Assert.True(m_container.Kernel.HasComponent(typeof(ICustomDeserializer)));
        }

        [Fact]
        public void ProtobufWindsorDi_RegisterModule_ResolveSerializer_Success()
        {
            // Act
            m_container.Install(new ProtobufContainerInstaller());

            var customSerializer = m_container.Resolve<ICustomSerializer>();

            // Assert
            Assert.NotNull(customSerializer);
        }

        [Fact]
        public void ProtobufWindsorDi_RegisterModule_ResolveDeserializerWithoutFileDescriptors_Success()
        {
            // Act
            m_container.Install(new ProtobufContainerInstaller());

            // Assert
            Assert.Throws<HandlerException>(() => m_container.Resolve<ICustomDeserializer>());
        }

        [Fact]
        public void ProtobufWindsorDi_RegisterModule_ResolveDeserializerWithFileDescriptors_Success()
        {
            // Act
            m_container.RegisterFileDescriptorProvider<TestsStructsFileDescriptorProvider>();
            m_container.Install(new ProtobufContainerInstaller());

            var customDeserializer = m_container.Resolve<ICustomDeserializer>();

            // Assert
            Assert.NotNull(customDeserializer);

            var protobufDeserializer = Assert.IsType<ProtobufDeserializer>(customDeserializer);
            Assert.True(protobufDeserializer.IsInitialized);
        }

        [Fact]
        public void ProtobufWindsorDi_RegisterTwiceTheSameFileDescriptorProvider_Success()
        {
            // Act
            m_container.RegisterFileDescriptorProvider<TestsStructsFileDescriptorProvider>();
            m_container.RegisterFileDescriptorProvider<TestsStructsFileDescriptorProvider>();
            m_container.Install(new ProtobufContainerInstaller());

            var customDeserializer = m_container.Resolve<ICustomDeserializer>();

            // Assert
            Assert.NotNull(customDeserializer);

            var protobufDeserializer = Assert.IsType<ProtobufDeserializer>(customDeserializer);
            Assert.True(protobufDeserializer.IsInitialized);

            var expectedFileDescriptorsCount = ProtobufTestsHelper.GetCountOfMessageDescriptors(new TestsStructsFileDescriptorProvider());
            ProtobufTestsHelper.AssertInnerDictionaries(protobufDeserializer, expectedFileDescriptorsCount);
        }
    }
}