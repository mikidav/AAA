﻿using Autofac;
using Indoors.Serializations.Common;
using Indoors.Serializations.Protobuf.DI.Autofac;
using Indoors.Serializations.Protobuf.Unit.Tests.FileDescriptors;
using Indoors.Serializations.Protobuf.Unit.Tests.Helpers;
using Xunit;

namespace Indoors.Serializations.Protobuf.Unit.Tests
{
    public class ProtobufAutofacDiTests
    {
        private readonly ContainerBuilder m_builder;

        public ProtobufAutofacDiTests()
        {
            m_builder = new ContainerBuilder();
        }

        [Fact]
        public void ProtobufAutofacDi_RegisterModule_IsRegistered_Success()
        {
            // Act
            m_builder.RegisterModule(new ProtobufModuleInstaller());
            var container = m_builder.Build();

            // Assert
            Assert.True(container.IsRegistered<ICustomSerializer>());

            Assert.True(container.IsRegistered<ICustomDeserializer>());
        }

        [Fact]
        public void ProtobufAutofacDi_RegisterModule_ResolveSerializer_Success()
        {
            // Act
            m_builder.RegisterModule(new ProtobufModuleInstaller());
            var container = m_builder.Build();

            var customSerializer = container.Resolve<ICustomSerializer>();

            // Assert
            Assert.NotNull(customSerializer);
        }

        [Fact]
        public void ProtobufAutofacDi_RegisterModule_ResolveDeserializerWithoutFileDescriptors_Success()
        {
            // Act
            m_builder.RegisterModule(new ProtobufModuleInstaller());
            var container = m_builder.Build();

            var customDeserializer = container.Resolve<ICustomDeserializer>();

            // Assert
            Assert.NotNull(customDeserializer);

            var protobufDeserializer = Assert.IsType<ProtobufDeserializer>(customDeserializer);
            Assert.False(protobufDeserializer.IsInitialized);
        }

        [Fact]
        public void ProtobufAutofacDi_RegisterModule_ResolveDeserializerWithFileDescriptors_Success()
        {
            // Act
            m_builder.RegisterModule(new ProtobufModuleInstaller());
            m_builder.RegisterFileDescriptorProvider<TestsStructsFileDescriptorProvider>();
            var container = m_builder.Build();

            var customDeserializer = container.Resolve<ICustomDeserializer>();

            // Assert
            Assert.NotNull(customDeserializer);

            var protobufDeserializer = Assert.IsType<ProtobufDeserializer>(customDeserializer);
            Assert.True(protobufDeserializer.IsInitialized);
        }

        [Fact]
        public void ProtobufAutofacDi_RegisterTwiceTheSameFileDescriptorProvider_Success()
        {
            // Act
            m_builder.RegisterModule(new ProtobufModuleInstaller());
            m_builder.RegisterFileDescriptorProvider<TestsStructsFileDescriptorProvider>();
            m_builder.RegisterFileDescriptorProvider<TestsStructsFileDescriptorProvider>();
            var container = m_builder.Build();

            var customDeserializer = container.Resolve<ICustomDeserializer>();


            // Assert
            Assert.NotNull(customDeserializer);

            var protobufDeserializer = Assert.IsType<ProtobufDeserializer>(customDeserializer);
            Assert.True(protobufDeserializer.IsInitialized);

            var expectedFileDescriptorsCount = ProtobufTestsHelper.GetCountOfMessageDescriptors(new TestsStructsFileDescriptorProvider());
            ProtobufTestsHelper.AssertInnerDictionaries(protobufDeserializer, expectedFileDescriptorsCount);
        }
    }
}