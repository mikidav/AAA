﻿using System;
using System.Collections.Generic;
using System.Linq;
using Google.Protobuf.Reflection;
using Xunit;

namespace Indoors.Serializations.Protobuf.Unit.Tests.Helpers
{
    internal static class ProtobufTestsHelper
    {
        public static void AssertInnerDictionaries(ProtobufDeserializer protobufDeserializer, int expectedFileDescriptorsCount)
        {
            // Act
            var messagesDescriptorsByType = protobufDeserializer.GetInstanceField("m_messagesDescriptorsByType")
                as IReadOnlyDictionary<Type, MessageDescriptor>;
            
            // Assert
            Assert.NotNull(messagesDescriptorsByType);
            Assert.Equal(expectedFileDescriptorsCount, messagesDescriptorsByType.Count);
        }

        public static int GetCountOfMessageDescriptors(IEnumerable<IFileDescriptorProvider> fileDescriptorProviders)
        => fileDescriptorProviders?.SelectMany(provider => provider.Descriptors).Count() ?? 0;
            

        public static int GetCountOfMessageDescriptors(params IFileDescriptorProvider[] fileDescriptorProviders)
            => fileDescriptorProviders?.SelectMany(provider => provider.Descriptors).Count() ?? 0;
    }
}