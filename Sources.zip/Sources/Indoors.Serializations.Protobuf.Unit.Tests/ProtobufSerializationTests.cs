using System;
using Indoors.Serializations.Protobuf.Unit.Tests.FileDescriptors;
using Indoors.Serializations.Protobuf.Unit.Tests.Types;
using Xunit;

namespace Indoors.Serializations.Protobuf.Unit.Tests
{
    public class ProtobufSerializationTests
    {
        [Fact]
        public void ProtobufSerialization_SerializeThenDeserializeByType_SingleType_Success()
        {
            // Arrange
            var protobufSerializer = new ProtobufSerializer();
            var protobufDeserializer = new ProtobufDeserializer(new TestsStructsFileDescriptorProvider());
            var testStruct = new TestStruct { Id = Guid.NewGuid().ToString() };

            // Act
            var bytes = protobufSerializer.Serialize(testStruct);
            protobufDeserializer.Deserialize(bytes, out TestStruct deserializedTestStruct);

            // Assert
            Assert.Equal(testStruct.Id, deserializedTestStruct.Id);
        }

        [Fact]
        public void ProtobufSerialization_SerializeThenDeserializeByType_TwoType_Success()
        {
            // Arrange
            var protobufSerializer = new ProtobufSerializer();
            var protobufDeserializer = new ProtobufDeserializer(new TestsStructsFileDescriptorProvider());
            var testStruct = new TestStruct { Id = Guid.NewGuid().ToString() };
            var anotherTestStruct = new AnotherTestStruct { Id = Guid.NewGuid().ToString() };

            // Act
            var testStructBytes = protobufSerializer.Serialize(testStruct);
            protobufDeserializer.Deserialize(testStructBytes, out TestStruct deserializedTestStruct);

            var anotherTestStructBytes = protobufSerializer.Serialize(anotherTestStruct);
            protobufDeserializer.Deserialize(anotherTestStructBytes, out TestStruct anotherDeserializedTestStruct);

            // Assert
            Assert.Equal(testStruct.Id, deserializedTestStruct.Id);
            Assert.Equal(anotherTestStruct.Id, anotherDeserializedTestStruct.Id);
        }

        [Fact]
        public void ProtobufSerialization_SerializeThenDeserializeByUnsafeType_Success()
        {
            // Arrange
            var protobufSerializer = new ProtobufSerializer();
            var protobufDeserializer = new ProtobufDeserializer(new TestsStructsFileDescriptorProvider());
            var testStruct = new TestStruct { Id = Guid.NewGuid().ToString() };

            // Act
            var bytes = protobufSerializer.Serialize(testStruct);
            protobufDeserializer.Deserialize(testStruct.GetType(), bytes, out var deserializedData);

            // Assert
            Assert.NotNull(deserializedData);
            var deserializedTestStruct = Assert.IsType<TestStruct>(deserializedData);
            Assert.Equal(testStruct.Id, deserializedTestStruct.Id);
        }
    }
}
