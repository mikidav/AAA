﻿using System.Collections.Generic;
using Google.Protobuf.Reflection;
using Indoors.Serializations.Protobuf.Unit.Tests.Types;

namespace Indoors.Serializations.Protobuf.Unit.Tests.FileDescriptors
{
    public class AnotherTestsStructsFileDescriptorProvider : IFileDescriptorProvider
    {
        public IEnumerable<FileDescriptor> Descriptors => new[]
        {
            AnotherTestsStructsReflection.Descriptor
        };
    }
}