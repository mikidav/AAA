using System;
using System.IO;
using Microsoft.Extensions.Configuration;
using Serilog;

namespace Microsoft.Extensions.Hosting
{
    public static class SerilogRegistrationExtensions
    {
        public static IHostBuilder UseSerilogByConfigurationFileFromAppSettingsKey(this IHostBuilder builder, string pathKeyInAppSettingFile = "serilog_configurations_path")
        {
            if (string.IsNullOrWhiteSpace(pathKeyInAppSettingFile))
                throw new ArgumentNullException(nameof(pathKeyInAppSettingFile));


            var appSettingsConfiguration = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false)
                .Build();

            var serilogConfigurationsPath = appSettingsConfiguration[pathKeyInAppSettingFile];
            if (string.IsNullOrWhiteSpace(serilogConfigurationsPath))
                throw new ArgumentNullException(nameof(pathKeyInAppSettingFile));

            return UseSerilogByConfigurationFile(builder, serilogConfigurationsPath);
        }

        private static IHostBuilder UseSerilogByConfigurationFile(IHostBuilder builder, string serilogConfigurationsPath)
        {
            if (!Path.IsPathRooted(serilogConfigurationsPath))
            {
                serilogConfigurationsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, serilogConfigurationsPath);
                serilogConfigurationsPath = Path.GetFullPath(serilogConfigurationsPath);
            }

            if (!File.Exists(serilogConfigurationsPath))
                throw new Exception($"Serilog json configuration file does not exists! Path: {serilogConfigurationsPath}");

            var configuration = new ConfigurationBuilder()
                .AddJsonFile(serilogConfigurationsPath)
                .Build();

            var applicationName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;

            var logger = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration)
                .Enrich.WithProperty("ApplicationName", applicationName)
                .CreateLogger();

            builder = builder.UseSerilog(logger);

            return builder;
        }
    }
}