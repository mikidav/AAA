﻿using System.Collections;
using Autofac;
using Autofac.Core;
using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Subscribers;
using Indoors.Communications.Core.Adapters;
using Indoors.Communications.Core.InProcess;
using Indoors.Communications.Core.Publish;
using Indoors.Communications.Core.Settings;
using Indoors.Communications.Core.Subscribe;
using Indoors.Communications.Core.Udp;

namespace Indoors.Communications.Core.DI.Autofac
{
    public static class CommunicationCoreAutofacExtensions
    {
        public static string RegisterAdaptingPublisher<TData, TMessage, TAdapter>(this ContainerBuilder builder, string name = null, string messagePublisherName = null)
            where TAdapter : IPublishDataMessageAdapter<TData, TMessage>
        {
            name ??= typeof(AdaptingTypedPublisher<TData, TMessage>).Name;

            if (string.IsNullOrWhiteSpace(messagePublisherName))
            {
                builder.RegisterType<AdaptingTypedPublisher<TData, TMessage>>()
                    .AsSelf()
                    .As<ITypedObjectPublisher<TData>>()
                    .Named<ITypedObjectPublisher<TData>>(name)
                    .SingleInstance();
            }
            else
            {
                builder.RegisterType<AdaptingTypedPublisher<TData, TMessage>>()
                    .AsSelf()
                    .As<ITypedObjectPublisher<TData>>()
                    .Named<ITypedObjectPublisher<TData>>(name)
                    .WithParameter(ResolvedParameter.ForNamed<ITypedObjectPublisher<TMessage>>(messagePublisherName))
                    .SingleInstance();
            }

            builder.RegisterType<TAdapter>()
                .AsSelf()
                .As<IPublishDataMessageAdapter<TData, TMessage>>()
                .Named<IPublishDataMessageAdapter<TData, TMessage>>(name)
                .SingleInstance();
            
            return name;
        }

        public static string RegisterAdaptingSubscriber<TData, TMessage, TAdapter>(this ContainerBuilder builder, string name = null, string messageSubscriberName = null)
            where TAdapter : ISubscribeDataMessageAdapter<TData, TMessage>
        {
            name ??= typeof(AdaptingTypedSubscriber<TData, TMessage>).Name;

            if (string.IsNullOrWhiteSpace(messageSubscriberName))
            {
                builder.RegisterType<AdaptingTypedSubscriber<TData, TMessage>>()
                    .AsSelf()
                    .As<ITypedObjectSubscriber<TData>>()
                    .Named<ITypedObjectSubscriber<TData>>(name)
                    .SingleInstance();
            }
            else
            {
                builder.RegisterType<AdaptingTypedSubscriber<TData, TMessage>>()
                    .AsSelf()
                    .As<ITypedObjectSubscriber<TData>>()
                    .Named<ITypedObjectSubscriber<TData>>(name)
                    .WithParameter(ResolvedParameter.ForNamed<ITypedObjectSubscriber<TMessage>>(messageSubscriberName))
                    .SingleInstance();
            }
            
            builder.RegisterType<TAdapter>()
                .AsSelf()
                .As<ISubscribeDataMessageAdapter<TData, TMessage>>()
                .Named<ISubscribeDataMessageAdapter<TData, TMessage>>(name)
                .SingleInstance();
            
            return name;
        }

        public static string RegisterUdpPublisher<TPublisher>(this ContainerBuilder builder, string networkAddressSettingsName = null, string name = null) where TPublisher : class
        {
            var udpBufferPublisherName = nameof(UdpBufferPublisher) + ':' + typeof(TPublisher).Name;

            RegisterUdpBufferPublisher(builder, networkAddressSettingsName, udpBufferPublisherName);

            name ??= typeof(CustomTypedPublisher<TPublisher>).Name;

            builder.RegisterType<CustomTypedPublisher<TPublisher>>()
                .AsSelf()
                .As<ITypedObjectPublisher<TPublisher>>()
                .Named<ITypedObjectPublisher<TPublisher>>(name)
                .WithParameter(ResolvedParameter.ForNamed<IBufferPublisher<byte[]>>(udpBufferPublisherName))
                .SingleInstance();
            return name;
        }

        public static string RegisterUdpBufferPublisher(this ContainerBuilder builder, string networkAddressSettingsName = null, string name = null)
        {
            name ??= nameof(UdpBufferPublisher);

            if (networkAddressSettingsName == null)
            {
                builder.RegisterType<UdpBufferPublisher>()
                    .AsSelf()
                    .As<IBufferPublisher<byte[]>>()
                    .Named<IBufferPublisher<byte[]>>(name)
                    .SingleInstance();
            }
            else
            {
                builder.RegisterType<UdpBufferPublisher>()
                    .AsSelf()
                    .As<IBufferPublisher<byte[]>>()
                    .Named<IBufferPublisher<byte[]>>(name)
                    .WithParameter(ResolvedParameter.ForNamed<IUdpPublisherSettings>(networkAddressSettingsName))
                    .SingleInstance();
            }

            return name;
        }


        public static string RegisterUdpSubscriber<TSubscriber>(this ContainerBuilder builder, string networkAddressSettingsName = null, string name = null) where TSubscriber : class
        {
            var udpBufferSubscriberName = nameof(UdpBufferSubscriber) + ':' + typeof(TSubscriber).Name;

            RegisterUdpBufferSubscriber(builder, networkAddressSettingsName, udpBufferSubscriberName);

            name ??= typeof(CustomTypedSubscriber<TSubscriber>).Name;

            builder.RegisterType<CustomTypedSubscriber<TSubscriber>>()
                .AsSelf()
                .As<ITypedObjectSubscriber<TSubscriber>>()
                .Named<ITypedObjectSubscriber<TSubscriber>>(name)
                .WithParameter(ResolvedParameter.ForNamed<IBufferSubscriber<byte[]>>(udpBufferSubscriberName))
                .SingleInstance();

            return name;
        }

        public static string RegisterUdpBufferSubscriber(this ContainerBuilder builder, string networkAddressSettingsName = null, string name = null)
        {
            name ??= nameof(UdpBufferSubscriber);

            if (networkAddressSettingsName == null)
            {
                builder.RegisterType<UdpBufferSubscriber>()
                    .AsSelf()
                    .As<IBufferSubscriber<byte[]>>()
                    .Named<IBufferSubscriber<byte[]>>(name)
                    .SingleInstance();
            }
            else
            {
                builder.RegisterType<UdpBufferSubscriber>()
                    .AsSelf()
                    .As<IBufferSubscriber<byte[]>>()
                    .Named<IBufferSubscriber<byte[]>>(name)
                    .WithParameter(ResolvedParameter.ForNamed<IUdpSubscriberSettings>(networkAddressSettingsName))
                    .SingleInstance();
            }

            return name;
        }

        public static string RegisterInProcessBufferCommunication<TBuffer>(this ContainerBuilder builder, string name = null) where TBuffer : IList
        {
            name ??= nameof(BufferInProcessCommunication<TBuffer>);

            builder.RegisterType<BufferInProcessCommunication<TBuffer>>()
                    .AsSelf()
                    .As<IBufferPublisher<TBuffer>, IBufferSubscriber<TBuffer>>()
                    .Named<IBufferSubscriber<TBuffer>>(name)
                    .Named<IBufferPublisher<TBuffer>>(name)
                    .IfNotRegistered(typeof(IBufferPublisher<TBuffer>))
                    .IfNotRegistered(typeof(IBufferSubscriber<TBuffer>))
                    .SingleInstance();

            return name;
        }

        public static string RegisterInProcessTypedPublishSubscribeCommunication<TData>(this ContainerBuilder builder, string name = null)
        {
            name ??= nameof(TypedPublishSubscribeInProcessCommunication<TData>);

            builder.RegisterType<TypedPublishSubscribeInProcessCommunication<TData>>()
                .AsSelf()
                .As<ITypedObjectPublisher<TData>, ITypedObjectSubscriber<TData>>()
                .Named<ITypedObjectSubscriber<TData>>(name)
                .Named<ITypedObjectPublisher<TData>>(name)
                .IfNotRegistered(typeof(ITypedObjectPublisher<TData>))
                .IfNotRegistered(typeof(ITypedObjectSubscriber<TData>))
                .SingleInstance();

            return name;
        }
    }
}