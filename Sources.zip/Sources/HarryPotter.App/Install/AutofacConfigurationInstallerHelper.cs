﻿using System;
using System.IO;
using Autofac;
using Microsoft.Extensions.Configuration;

namespace HarryPotter.App.Install
{
    public static class AutofacConfigurationInstallerHelper
    {
        public static ContainerBuilder RegisterAutofacConfigurationByJsonFile(this ContainerBuilder builder, string jsonConfigurationPath)
        {
            if (string.IsNullOrWhiteSpace(jsonConfigurationPath))
                throw new ArgumentNullException(nameof(jsonConfigurationPath));

            if (!Path.IsPathRooted(jsonConfigurationPath))
            {
                jsonConfigurationPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, jsonConfigurationPath);
                jsonConfigurationPath = Path.GetFullPath(jsonConfigurationPath);
            }

            if (!File.Exists(jsonConfigurationPath))
                throw new Exception($"Autofac Json configuration file does not exists! Path: {jsonConfigurationPath}");

            var configuration = new ConfigurationBuilder()
                .AddJsonFile(jsonConfigurationPath)
                .Build();

            var module = new Autofac.Configuration.ConfigurationModule(configuration);
            builder.RegisterModule(module);
            return builder;
        }
    }
}