﻿using System;
using System.IO;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Extensions.Hosting;
using Serilog.Extensions.Logging;

namespace HarryPotter.App.Install
{
    public static class SerilogInstallerHelper
    {
        public static ContainerBuilder RegisterSerilog(this ContainerBuilder builder)
        {
            var services = new ServiceCollection();

            services.AddLogging();

            services.AddSingleton<ILoggerFactory>(serviceProvider => new SerilogLoggerFactory());

            // Use the Populate method to register services which were registered
            // to IServiceCollection
            builder.Populate(services);

            return builder;
        }

        public static ContainerBuilder RegisterSerilog(this ContainerBuilder builder, Serilog.ILogger logger)
        {
            if (logger == null)
                throw new ArgumentNullException(nameof(logger));

            var services = new ServiceCollection();

            services.AddLogging();

            services.AddSingleton<ILoggerFactory>(serviceProvider => new SerilogLoggerFactory(logger));

            // This won't (and shouldn't) take ownership of the logger. 
            services.AddSingleton(logger);

            // Consumed by user code
            var diagnosticContext = new DiagnosticContext(logger);
            services.AddSingleton<IDiagnosticContext>(diagnosticContext);

            // Use the Populate method to register services which were registered
            // to IServiceCollection
            builder.Populate(services);

            return builder;
        }

        public static ContainerBuilder RegisterSerilog(this ContainerBuilder builder, string jsonConfigurationPath)
        {
            if (string.IsNullOrWhiteSpace(jsonConfigurationPath))
                throw new ArgumentNullException(nameof(jsonConfigurationPath));

            if (!Path.IsPathRooted(jsonConfigurationPath))
            {
                jsonConfigurationPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, jsonConfigurationPath);
                jsonConfigurationPath = Path.GetFullPath(jsonConfigurationPath);
            }

            if (!File.Exists(jsonConfigurationPath))
                throw new Exception($"Serilog json configuration file does not exists! Path: {jsonConfigurationPath}");

            var configuration = new ConfigurationBuilder()
                .AddJsonFile(jsonConfigurationPath)
                .Build();

            var applicationName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;

            var logger = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration)
                .Enrich.WithProperty("ApplicationName", applicationName)
                .CreateLogger();

            return RegisterSerilog(builder, logger);
        }
    }
}