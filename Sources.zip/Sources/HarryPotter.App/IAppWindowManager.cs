﻿namespace HarryPotter.App
{
    public interface IAppWindowManager
    {
        void DisplayDebugWindow();
    }
}