﻿using System;
using System.Collections.Generic;
using System.Drawing;
using Caliburn.Micro;
using HarryPotter.App.Logic;
using HarryPotter.App.Messages;
using HarryPotter.AtlasWrapper;
using HarryPotter.Models;
using HarryPotter.UIEntityRepository;

namespace HarryPotter.App.ViewModels
{
    public class DebugViewModel : Screen, IDebugViewModel
    {
        private List<OoiType> m_ooiTypes=new List<OoiType>();

        public DebugViewModel(IEventAggregator eventAggregator
            , IEntityRepository entityRepository
            , IAtlasContainer atlasContainer
            , IApplicationFacade applicationFacade
        )
        {
            EventAggregator = eventAggregator;
            EntityRepository = entityRepository;
            AtlasContainer = atlasContainer;
            ApplicationFacade = applicationFacade;

            foreach (var value in Enum.GetValues(typeof(OoiType)))
            {
                OoiTypes.Add((OoiType)value);
            }
        }


        public IEventAggregator EventAggregator { get; }
        public IEntityRepository EntityRepository { get; }
        public IAtlasContainer AtlasContainer { get; }
        public IApplicationFacade ApplicationFacade { get; }
        public string PointX { get; set; } = 50f.ToString();

        public string PointY { get; set; } = 50f.ToString();

        public List<OoiType> OoiTypes
        {
            get => m_ooiTypes;
            set
            {
                if (Equals(value, m_ooiTypes)) return;
                m_ooiTypes = value;
                NotifyOfPropertyChange(() => OoiTypes);
            }
        }

        public HarryPotter.Models.OoiType SelectedType { get; set; } = OoiType.People;

        public string CanTakeOff { get; set; }

        public bool CanExecuteTakeoff
        {
            get
            {
                return ApplicationFacade.PlatformFacade.TakeOffCommand.ForceCanExecute ?? false;
            }
            set
            {
                if (value == ApplicationFacade.PlatformFacade.TakeOffCommand.ForceCanExecute) return;
                ApplicationFacade.PlatformFacade.TakeOffCommand.ForceCanExecute = value;
                NotifyOfPropertyChange(() => CanExecuteTakeoff);
            }
        }

        public bool CanExecuteLand
        {
            get
            {
                var landCommandExternalCanExecute = ApplicationFacade.PlatformFacade.LandCommand.ForceCanExecute ?? false;
                return landCommandExternalCanExecute;
            }
            set
            {
                if (value == ApplicationFacade.PlatformFacade.LandCommand.ForceCanExecute) return;
                ApplicationFacade.PlatformFacade.LandCommand.ForceCanExecute = value;
                NotifyOfPropertyChange(() => CanExecuteLand);
            }
        }


        public void ChangeView()
        {
            EventAggregator.PublishOnUIThread(new ChangeViewMessage(ViewEnum.MapAndVideoView));
        }

        public void OnClose()
        {
            OnClosed();
        }

        protected virtual void OnClosed()
        {
            Closed?.Invoke(this, EventArgs.Empty);
        }

        protected override void OnDeactivate(bool close)
        {
            base.OnDeactivate(close);
            Closed.Invoke(this, EventArgs.Empty);
        }

        public event EventHandler<EventArgs> Closed;


        public void AddOoi()
        {
            AddOoi(float.Parse(PointX), float.Parse(PointY));
        }

        public void AddOoi(PointF point)
        {
            AddOoi(point.X, point.Y);
        }

        public void AddOoi(float x, float y)
        {
            Ooi ooi = new Ooi
            {
                X = float.Parse(PointX),
                Y = float.Parse(PointY),
                Z = 0,
                Ooitype = SelectedType
            };
            EntityRepository.Oois.Add(ooi);
        }

        public void ClearOois()
        {
            EntityRepository.Oois.Clear();
        }
    }
}