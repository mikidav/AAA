﻿using System.Drawing;

namespace HarryPotter.App.ViewModels
{
    public interface IDebugViewModel : INonModalWindowViewModel
    {
        void AddOoi();
        void AddOoi(PointF point);
        void AddOoi(float x, float y);
        void ClearOois();
    }
}