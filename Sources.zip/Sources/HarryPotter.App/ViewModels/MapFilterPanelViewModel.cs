﻿using System.Windows;
using Caliburn.Micro;
using HarryPotter.Models;
using HarryPotter.UIEntityRepository;

namespace HarryPotter.App.ViewModels
{
    public interface IMapFilterPanelViewModel : IScreen
    {
    }

    public class MapFilterPanelViewModel : Screen, IMapFilterPanelViewModel
    {
        private Visibility m_visibility = Visibility.Collapsed;

        public ItemsChangeObservableCollection<OoiFilterItem> Collection { get; } =
            new ItemsChangeObservableCollection<OoiFilterItem>();

        public MapFilterPanelViewModel(IEventAggregator eventAggregator, IEntityRepository entityRepository)
        {
            EventAggregator = eventAggregator;
            EntityRepository = entityRepository;
            Collection.Add(new OoiFilterItem {ItemType = OoiType.People, OoiCount = "2", Visible = true});
            Collection.Add(new OoiFilterItem { ItemType = OoiType.Weapons, OoiCount = "2", Visible = true });
            Collection.Add(new OoiFilterItem { ItemType = OoiType.Furniture, OoiCount = "6", Visible = true });
            Collection.Add(new OoiFilterItem {ItemType = OoiType.Tools, OoiCount = "6", Visible = true});
            Collection.Add(new OoiFilterItem { ItemType = OoiType.Platform, OoiCount = "4", Visible = false });
            //Collection.CollectionChanged += Collection_CollectionChanged;
        }


        public IEventAggregator EventAggregator { get; }
        public IEntityRepository EntityRepository { get; }

        public ItemsChangeObservableCollection<OoiFilterItem> OoiFiltersCollection
        {
            get { return EntityRepository.ReadOnlyOoiFiltersCollection; }
        }

        public Visibility Visibility
        {
            get => m_visibility;
            private set
            {
                if (value == m_visibility) return;
                m_visibility = value;
                NotifyOfPropertyChange(() => Visibility);
            }
        }

        public bool CanCollapseMapFilterPanel()
        {
            return true;
        }

        public void CollapseMapFilterPanel()
        {
            if (Visibility == Visibility.Visible)
                Visibility = Visibility.Collapsed;
            else
                Visibility = Visibility.Visible;
        }
    }
}