﻿using Caliburn.Micro;
using HarryPotter.Models;

namespace HarryPotter.App.ViewModels
{
    public interface IOperationalViewModel : IScreen
    {
        void ChangeView(ViewEnum changeViewMessage);
        //void OpenDebugView();
    }
}