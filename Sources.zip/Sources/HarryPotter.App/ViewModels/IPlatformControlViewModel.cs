﻿using Caliburn.Micro;

namespace HarryPotter.App.ViewModels
{
    public interface IPlatformControlViewModel : IScreen
    {
        void TakeOff();
    }
}