﻿using Caliburn.Micro;

namespace HarryPotter.App.ViewModels
{
    internal interface IMainViewModel : IScreen
    {
    }
}