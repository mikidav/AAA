﻿namespace HarryPotter.App.ViewModels
{
    public interface IModalWindowViewModel
    {
    }
}