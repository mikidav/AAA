﻿namespace HarryPotter.App.ViewModels
{
    public class ModalWindowViewModel : IModalWindowViewModel
    {
    }
}