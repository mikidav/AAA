﻿using System;

namespace HarryPotter.App.ViewModels
{
    public interface INonModalWindowViewModel
    {
        event EventHandler<EventArgs> Closed;
    }
}