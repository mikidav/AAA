﻿namespace HarryPotter.App.Behavior
{
    public enum MaskType
    {
        Any,
        Integer,
        Decimal
    }
}