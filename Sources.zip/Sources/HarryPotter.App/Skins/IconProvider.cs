﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media.Imaging;

namespace HarryPotter.App.Skins
{
    public static class IconProvider
    {
        //static IconProvider()
        //{
        //    PlatformBatteryPercentageImages = new Dictionary<float, BitmapSource>
        //    {
        //        {1, (BitmapSource) Application.Current.TryFindResource("PlatformSummaryBattery0")},
        //        {20, (BitmapSource) Application.Current.TryFindResource("PlatformSummaryBattery1")},
        //        {41, (BitmapSource) Application.Current.TryFindResource("PlatformSummaryBattery2")},
        //        {71, (BitmapSource) Application.Current.TryFindResource("PlatformSummaryBattery3")},
        //        {91, (BitmapSource) Application.Current.TryFindResource("PlatformSummaryBattery4")},
        //        {100, (BitmapSource) Application.Current.TryFindResource("PlatformSummaryBattery5")}
        //    };

        //    PlatformNetworkImages = new Dictionary<float, BitmapSource>
        //    {
        //        {1, (BitmapSource) Application.Current.TryFindResource("PlatformSummaryNetwork0")},
        //        {20, (BitmapSource) Application.Current.TryFindResource("PlatformSummaryNetwork1")},
        //        {41, (BitmapSource) Application.Current.TryFindResource("PlatformSummaryNetwork2")},
        //        {71, (BitmapSource) Application.Current.TryFindResource("PlatformSummaryNetwork3")},
        //        {91, (BitmapSource) Application.Current.TryFindResource("PlatformSummaryNetwork4")},
        //        {100, (BitmapSource) Application.Current.TryFindResource("PlatformSummaryNetwork5")}
        //    };
        //}

        //public static Dictionary<float, BitmapSource> PlatformNetworkImages { get; set; }

        //public static Dictionary<float, BitmapSource> PlatformBatteryPercentageImages { get; set; }

        //public static IEnumerable<BitmapSource> GetEnumerableIcon(Dictionary<double, BitmapSource> images, float value)
        //{
        //    foreach (var item in images)
        //    {
        //        if (item.Key > value)
        //            yield return item.Value;
        //    }
        //}

        //public static BitmapSource GetPlatformNetworkImage(float value)
        //{
        //    foreach (var item in PlatformNetworkImages)
        //    {
        //        if (item.Key > value)
        //            return item.Value;
        //    }

        //    return PlatformNetworkImages.FirstOrDefault().Value;
        //}

        //public static BitmapSource GetPlatformBatteryPercentageImages(float value)
        //{
        //    foreach (var item in PlatformBatteryPercentageImages)
        //    {
        //        if (item.Key > value)
        //            return item.Value;
        //    }

        //    return PlatformBatteryPercentageImages.FirstOrDefault().Value;
        //}
    }
}