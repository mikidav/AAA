﻿using HarryPotter.Models;

namespace HarryPotter.App.SelectionItemAggregator
{
    public class SelectedItemsAggregator : ISelectedItemsAggregator
    {
        public PlatformStatusItem SelectedPlatform { get; set; }
    }

    public interface ISelectedItemsAggregator
    {
        PlatformStatusItem SelectedPlatform { get; set; }
    }
}
