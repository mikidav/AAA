﻿namespace HarryPotter.App.Messages
{
    public enum ArmStateRequestEnum
    {
        Disable,
        Enable
    }

    public class ArmDisarmPlatformMessage
    {
        public ArmStateRequestEnum WantedArmState { get; set; }
    }
}