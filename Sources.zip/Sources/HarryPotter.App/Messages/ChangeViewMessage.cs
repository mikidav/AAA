﻿using HarryPotter.Models;

namespace HarryPotter.App.Messages
{
    public class ChangeViewMessage
    {
        public ChangeViewMessage(ViewEnum viewType)
        {
            ViewType = viewType;
        }
        public ViewEnum ViewType { get; set; }
    }
}