﻿namespace HarryPotter.App.Messages
{
    public enum NavigationModeRequestEnum
    {
        Indoors,
        Outdoors
    }

    public class SetNavigationModePlatformMessage
    {
        public NavigationModeRequestEnum WantedNavigationMode { get; set; }
    }
}