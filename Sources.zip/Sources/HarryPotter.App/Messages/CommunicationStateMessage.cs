﻿namespace HarryPotter.App.Messages
{
    public enum CommunicationStateEnum
    {
        Off,
        On
    }

    public class CommunicationStateMessage
    {
        public CommunicationStateEnum State { get; set; }
    }
}