﻿namespace HarryPotter.App.Messages
{
    public class CloseApplicationMessage
    {
      
    }
}