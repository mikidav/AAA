﻿namespace HarryPotter.App.Messages
{
    public class ToggleOperationalModeMessage
    {
    }
}
