﻿namespace HarryPotter.App.Messages
{
    public class OpenDebugViewMessage
    {
    }
}