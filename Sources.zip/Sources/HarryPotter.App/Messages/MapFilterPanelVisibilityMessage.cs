﻿namespace HarryPotter.App.Messages
{
    //visibility
    public class MapFilterPanelVisibilityMessage
    {
        public MapFilterPanelVisibilityMessage(bool isVisible= false)
        {
            IsVisible = isVisible;
        }

        public bool IsVisible { get; set; }
    }
}