﻿using System.Windows.Controls;

namespace HarryPotter.App.Views
{
    /// <summary>
    ///     Interaction logic for OperationalView.xaml
    /// </summary>
    public partial class OperationalView : UserControl
    {
        public OperationalView()
        {
            InitializeComponent();
        }
    }
}