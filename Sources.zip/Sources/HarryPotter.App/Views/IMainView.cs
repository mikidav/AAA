﻿namespace HarryPotter.App.Views
{
    public interface IMainView
    {
    }
}