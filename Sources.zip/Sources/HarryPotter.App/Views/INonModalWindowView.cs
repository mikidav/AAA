﻿namespace HarryPotter.App.Views
{
    internal interface INonModalWindowView
    {
    }
}