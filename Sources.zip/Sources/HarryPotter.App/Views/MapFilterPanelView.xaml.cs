﻿using System.Windows.Controls;

namespace HarryPotter.App.Views
{
    //Collapsed
    /// <summary>
    /// Interaction logic for MapFilterPanelView.xaml
    /// </summary>
    public partial class MapFilterPanelView : UserControl
    {
        public MapFilterPanelView()
        {
            InitializeComponent();
        }
    }
}
