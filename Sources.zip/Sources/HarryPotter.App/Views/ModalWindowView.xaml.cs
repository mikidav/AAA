﻿using System.Windows.Controls;

namespace HarryPotter.App.Views
{
    /// <summary>
    ///     Interaction logic for ModalWindowView.xaml
    /// </summary>
    public partial class ModalWindowView : UserControl
    {
        public ModalWindowView()
        {
            InitializeComponent();
        }
    }
}