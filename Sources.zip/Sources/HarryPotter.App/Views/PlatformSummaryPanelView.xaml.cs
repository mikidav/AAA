﻿using System.Windows.Controls;

namespace HarryPotter.App.Views
{
    /// <summary>
    /// Interaction logic for PlatformSummaryPanelView.xaml
    /// </summary>
    public partial class PlatformSummaryPanelView : UserControl
    {
        public PlatformSummaryPanelView()
        {
            InitializeComponent();
        }
    }
}
