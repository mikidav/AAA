﻿using System.Windows.Controls;

namespace HarryPotter.App.Views
{
    /// <summary>
    ///     Interaction logic for DebugView.xaml
    /// </summary>
    public partial class DebugView : UserControl
    {
        public DebugView()
        {
            InitializeComponent();
        }
    }
}