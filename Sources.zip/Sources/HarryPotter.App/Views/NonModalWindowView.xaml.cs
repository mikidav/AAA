﻿using System.Windows.Controls;

namespace HarryPotter.App.Views
{
    /// <summary>
    ///     Interaction logic for NonModalWindowView.xaml
    /// </summary>
    public partial class NonModalWindowView : UserControl
    {
        public NonModalWindowView()
        {
            InitializeComponent();
        }
    }
}