﻿using System.Windows.Controls;

namespace HarryPotter.App.Views
{
    /// <summary>
    ///     Interaction logic for UpperRibbonView.xaml
    /// </summary>
    public partial class UpperRibbonView : UserControl
    {
        public UpperRibbonView()
        {
            InitializeComponent();
        }
    }
}