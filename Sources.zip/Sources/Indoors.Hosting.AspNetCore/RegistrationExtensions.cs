﻿using Indoors.Hosting.AspNetCore.Controllers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;

namespace Microsoft.Extensions.Hosting
{
    public static class RegistrationExtensions
    {
        public static void ConfigureErrorRoutes(this IApplicationBuilder app, IWebHostEnvironment env)
        {
            ConfigureErrorRoutes(app, env.IsDevelopment());
            var routeError = env.IsDevelopment()
                ? ErrorController.RouteErrorDevelopment
                : ErrorController.RouteError;
            app.UseExceptionHandler(routeError);
        }

        public static void ConfigureErrorRoutes(this IApplicationBuilder app, bool isDebug)
        {
            var routeError = isDebug
                ? ErrorController.RouteErrorDevelopment
                : ErrorController.RouteError;
            app.UseExceptionHandler(routeError);
        }
    }
}