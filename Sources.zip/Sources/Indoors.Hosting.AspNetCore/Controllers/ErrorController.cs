﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Indoors.Hosting.AspNetCore.Controllers
{
    [ApiController]
    public class ErrorController : ControllerBase
    {
        public const string RouteErrorDevelopment = "/error-development";
        public const string RouteError = "/error";

        public ILogger Logger { get; }

        public ErrorController(ILogger<ErrorController> logger)
        {
            Logger = logger;
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [Route(RouteErrorDevelopment)]
        public Task<IActionResult> ErrorLocalDevelopment([FromServices] IWebHostEnvironment webHostEnvironment)
        {
            return Task.Run(() => TryGetProblemInDevelopmentMode(webHostEnvironment));
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [Route(RouteError)]
        public Task<IActionResult> Error() => Task.Run<IActionResult>(() => Problem());

        private IActionResult TryGetProblemInDevelopmentMode(IHostEnvironment webHostEnvironment)
        {
            if (!webHostEnvironment.IsDevelopment())
            {
                Logger.LogError(
                    "An attempt was made to access a development path when the application is not in development mode");
                throw new InvalidOperationException("This shouldn't be invoked in non-development environments.");
            }

            var context = HttpContext.Features.Get<IExceptionHandlerFeature>();
            var stacktrace = context?.Error?.StackTrace ?? "No error stack trace";
            var message = context?.Error?.Message ?? "No error message";
            return Problem(detail: stacktrace, title: message);
        }
    }
}
