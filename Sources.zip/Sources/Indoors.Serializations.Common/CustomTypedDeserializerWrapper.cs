﻿using System;

namespace Indoors.Serializations.Common
{
    /// <summary>
    /// An typed wrapper for <see cref="ICustomDeserializer"/>
    /// </summary>
    /// <typeparam name="TData"></typeparam>
    public class CustomTypedDeserializerWrapper<TData> : ICustomTypedDeserializer<TData>
    {
        private readonly ICustomDeserializer m_customDeserializer;

        public CustomTypedDeserializerWrapper(ICustomDeserializer customDeserializer)
        {
            m_customDeserializer = customDeserializer ?? throw new ArgumentNullException(nameof(customDeserializer));
        }

        /// <inheritdoc cref="Deserialize(byte[],ulong,ulong,out TData)"/>
        public void Deserialize(byte[] dataBuffer, ulong dataStartIndex, ulong dataLength, out TData deserializedData)
        {
            m_customDeserializer.Deserialize(dataBuffer, dataStartIndex, dataLength, out deserializedData);
        }

        /// <inheritdoc cref="Deserialize(byte[],out TData)"/>
        public void Deserialize(byte[] dataBuffer, out TData deserializedData)
        {
            m_customDeserializer.Deserialize(dataBuffer, out deserializedData);
        }
    }
}