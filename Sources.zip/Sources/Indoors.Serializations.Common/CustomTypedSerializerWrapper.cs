﻿using System;

namespace Indoors.Serializations.Common
{
    /// <summary>
    /// An typed wrapper for <see cref="ICustomSerializer"/>
    /// </summary>
    /// <typeparam name="TData"></typeparam>
    public class CustomTypedSerializerWrapper<TData> : ICustomTypedSerializer<TData>
    {
        private readonly ICustomSerializer m_customSerializer;

        public CustomTypedSerializerWrapper(ICustomSerializer customSerializer)
        {
            m_customSerializer = customSerializer ?? throw new ArgumentNullException(nameof(customSerializer));
        }

        /// <inheritdoc cref="ICustomTypedSerializer{TData}.Serialize(TData)"/>
        public byte[] Serialize(TData dataObject)
        {
            var bytes = m_customSerializer.Serialize(dataObject);
            return bytes;
        }

        /// <inheritdoc cref="ICustomTypedSerializer{TData}.Serialize(TData,ref byte[],ulong)"/>
        public void Serialize(TData dataObject, ref byte[] buffer, ulong startIndex)
        {
            m_customSerializer.Serialize(dataObject, ref buffer, startIndex);
        }
    }
}