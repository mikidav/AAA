﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Media.Imaging;
using Indoors.Video.Common.Decoders;

namespace Indoors.Video.Bitmaps.Decoders
{
    public class BitmapImageBufferDecoder : IImageBufferDecoder<byte[]>
    {
        public IReadOnlyList<string> SupportedEncodings { get; } = new[]
            {"Jpeg", "Jpg", "Png", "Bitmap", "Bmp", "Tiff", "Gif", "Icon", "Wmp"};

        public IInternalBitmapDecoderFactory BitmapDecoderFactory { get; }

        public BitmapImageBufferDecoder(IInternalBitmapDecoderFactory bitmapDecoderFactory)
        {
            BitmapDecoderFactory = bitmapDecoderFactory;
        }

        public DecodeResult DecodeToBuffer(byte[] imageBuffer, out byte[] decodedOutputBuffer)
        {
            var decodeResult = DecodeToBuffer(imageBuffer, 0, (ulong)imageBuffer.LongLength, out decodedOutputBuffer);
            return decodeResult;
        }

        public DecodeResult DecodeToBuffer(byte[] imageBuffer, ref byte[] decodedOutputBuffer, ulong decodedOutputStartIndex)
        {
            var decodeResult = DecodeToBuffer(imageBuffer, 0, (ulong)imageBuffer.LongLength, ref decodedOutputBuffer,
                decodedOutputStartIndex);
            return decodeResult;
        }

        public DecodeResult DecodeToBuffer(byte[] dataBuffer, ulong imageDataStartIndex, ulong imageDataLength, out byte[] decodedOutputBuffer)
        {
            try
            {
                using var stream = GetStream(dataBuffer, imageDataStartIndex, imageDataLength);
                var frame = DecodeStream(stream);

                var stride = GetStride(frame);
                var decodedOutputSize = GetOutputSize(stride, frame);

                decodedOutputBuffer = new byte[decodedOutputSize];

                FillOutputBuffer(decodedOutputBuffer, 0, frame);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to decode an image buffer using a Bitmap decoder! {nameof(dataBuffer)}: {dataBuffer}, {nameof(imageDataStartIndex)}: {imageDataStartIndex}, {nameof(imageDataLength)}: {imageDataLength}", ex);
            }

            return DecodeResult.Succeed;
        }

        public DecodeResult DecodeToBuffer(byte[] dataBuffer, ulong imageDataStartIndex, ulong imageDataLength, ref byte[] decodedOutputBuffer,
            ulong decodedOutputStartIndex)
        {
            try
            {
                using var stream = GetStream(dataBuffer, imageDataStartIndex, imageDataLength);

                var frame = DecodeStream(stream);
                FillOutputBuffer(decodedOutputBuffer, decodedOutputStartIndex, frame);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to decode an image buffer using a Bitmap decoder! {nameof(dataBuffer)}: {dataBuffer}, {nameof(imageDataStartIndex)}: {imageDataStartIndex}, {nameof(imageDataLength)}: {imageDataLength}, {nameof(decodedOutputBuffer)}: {decodedOutputBuffer}, {nameof(decodedOutputStartIndex)}: {decodedOutputStartIndex}", ex);
            }

            return DecodeResult.Succeed;
        }

        private static int GetOutputSize(int stride, BitmapSource frame)
        {
            return stride * frame.PixelHeight;
        }

        private static int GetStride(BitmapSource frame)
        {
            return (frame.Format.BitsPerPixel / 8) * frame.PixelWidth;
        }

        private static Stream GetStream(byte[] dataBuffer, ulong imageDataStartIndex, ulong imageDataLength)
        {
            var stream = new MemoryStream(dataBuffer, (int)imageDataStartIndex, (int)imageDataLength);
            return stream;
        }

        protected BitmapDecoder GetBitmapDecoder(Stream stream)
        {
            var bitmapDecoder = BitmapDecoderFactory.CreateBitmapDecoder(stream);
            return bitmapDecoder;
        }

        private BitmapFrame DecodeStream(Stream stream)
        {
            var decoder = GetBitmapDecoder(stream);

            var frame = decoder.Frames[0];
            return frame;
        }

        private static void FillOutputBuffer(byte[] decodedOutputBuffer, ulong decodedOutputStartIndex, BitmapFrame frame)
        {
            var stride = GetStride(frame);

            var decodedOutputSize = GetOutputSize(stride, frame);

            var outputBufferSize = (int)((ulong)decodedOutputBuffer.LongLength - decodedOutputStartIndex);
            if (decodedOutputSize < outputBufferSize)
            {
                throw new ArgumentOutOfRangeException(nameof(decodedOutputBuffer), decodedOutputBuffer, "Decoded frame data length exceeds data buffer size or size left after data start index!");
            }

            frame.CopyPixels(decodedOutputBuffer, stride, (int)decodedOutputStartIndex);
        }
    }
}