﻿using System.IO;
using System.Windows.Media.Imaging;

namespace Indoors.Video.Bitmaps.Decoders
{
    public interface IInternalBitmapDecoderFactory
    {
        BitmapDecoder CreateBitmapDecoder(Stream stream);
    }
}