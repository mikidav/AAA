﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Indoors.ConfigurationReader
{
    public interface IConfigurationReader
    {
        T GetConfiguration<T>(IConfiguration configuration, string appSettingsKey, bool isContainePath = false, 
            string sectionName = null, ILogger logger = null);
    }
}
