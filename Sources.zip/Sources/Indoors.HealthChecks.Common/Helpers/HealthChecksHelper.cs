﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Indoors.HealthChecks.Common.Types;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Newtonsoft.Json;

namespace Indoors.HealthChecks.Common.Helpers
{
    public static class HealthChecksHelper
    {
        public static IDictionary<HealthStatus, int> ResultStatusCodes;

        static HealthChecksHelper()
        {
            ResultStatusCodes = new Dictionary<HealthStatus, int>
            {
                [HealthStatus.Healthy] = StatusCodes.Status200OK,
                [HealthStatus.Degraded] = StatusCodes.Status200OK,
                [HealthStatus.Unhealthy] = StatusCodes.Status503ServiceUnavailable
            };
        }

        public static async Task WriteResponse(HttpContext context, HealthReport report)
        {
            context.Response.ContentType = "application/json";

            var response = new HealthCheckResponse
            {
                Status = report.Status.ToString(),
                HealthChecks = report.Entries.Select(x => new IndividualHealthCheckResponse
                {
                    Component = x.Key,
                    Status = x.Value.Status.ToString(),
                    Description = x.Value.Description,
                    Duration = x.Value.Duration.ToString("G"),
                    Data = x.Value.Data
                }),
                HealthCheckDuration = report.TotalDuration.ToString("G")
            };

            var responseInJsonFormat = JsonConvert.SerializeObject(response, Formatting.Indented);
            await context.Response.WriteAsync(responseInJsonFormat);
        }

        public static string BuildRoute(params string[] parts)
        {
            if (!parts.Any())
                return "/";
            var route = string.Join('/', parts).Replace("//", "/").ToLower();
            return route;
        }
    }
}