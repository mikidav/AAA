﻿using System.Collections.Generic;

namespace Indoors.HealthChecks.Common.Types
{
    internal class HealthCheckResponse
    {
        public string Status { get; set; }
        public IEnumerable<IndividualHealthCheckResponse> HealthChecks { get; set; }
        public string HealthCheckDuration { get; set; }
    }
}
