﻿using Indoors.HealthChecks.Common.Helpers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace Microsoft.Extensions.Hosting
{
    public static class RegistrationsExtensions
    {
        public static IApplicationBuilder UseIndoorsHealthChecks(this IApplicationBuilder applicationBuilder, string healthParentRoute = "/health")
        {
            return applicationBuilder.UseHealthChecks(healthParentRoute, new HealthCheckOptions
            {
                ResponseWriter = HealthChecksHelper.WriteResponse,
                ResultStatusCodes = HealthChecksHelper.ResultStatusCodes
            });
        }

        public static IMvcBuilder AddHealthController(this IServiceCollection services)
        {
            return services.AddMvc()
                .AddApplicationPart(Assembly.GetExecutingAssembly())
                .AddControllersAsServices();
        }
    }
}
