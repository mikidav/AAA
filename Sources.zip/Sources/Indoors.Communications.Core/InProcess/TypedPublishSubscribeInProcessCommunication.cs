﻿using System;
using System.Reactive.Subjects;
using Indoors.Communications.Common.Correlation;
using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Subscribers;
using Indoors.Communications.Common.Types;
using Indoors.Communications.Core.Subscribe;
using Microsoft.Extensions.Logging;

namespace Indoors.Communications.Core.InProcess
{
    public class TypedPublishSubscribeInProcessCommunication<TData> : SubscriberBase<TData>,
        ITypedObjectSubscriber<TData>, ITypedObjectPublisher<TData>
    {
        private readonly ISubject<OperationCompletedData> m_publishCompletedSubject;
        private readonly ISubject<OperationFailedData> m_publishFailedSubject;

        public ICorrelationIdGenerator CorrelationIdGenerator { get; private set; }

        public IObservable<OperationCompletedData> PublishCompleted => m_publishCompletedSubject;
        public IObservable<OperationFailedData> PublishFailed => m_publishFailedSubject;

        public IObservable<TData> DataReceived => DataSubscribedSubject;

        /// <summary>
        /// Creates a new instance of <see cref="BufferInProcessCommunication{TBuffer}"/> without initializing it.
        /// </summary>
        /// <param name="correlationIdGenerator"></param>
        /// <param name="logger">An optional logger</param>
        /// <param name="id">The id of the publisher service.</param>
        public TypedPublishSubscribeInProcessCommunication(ICorrelationIdGenerator correlationIdGenerator = null,
            ILogger<TypedPublishSubscribeInProcessCommunication<TData>> logger = null,
            string id = null) : base(logger, id)
        {
            CorrelationIdGenerator = correlationIdGenerator;

            m_publishCompletedSubject = new Subject<OperationCompletedData>();
            m_publishFailedSubject = new Subject<OperationFailedData>();
        }

        public string Publish(in TData data)
        {
            var operationId = CorrelationIdGenerator?.Generate()
                              ?? Guid.NewGuid().ToString();

            Publish(operationId, data);

            return operationId;
        }

        public void Publish(string publishId, in TData data)
        {
            ThrowIfCanNotPublish(publishId, data);

            try
            {
                ValidateIsRunning($"Error: Trying to publish when not started! PublishId: {publishId}, {ServiceDescriptionString}");

                InvokeHandlersSync(data);

                var operationCompletedData = new OperationCompletedData(publishId);
                m_publishCompletedSubject.OnNext(operationCompletedData);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed to publish a message! PublishId: {publishId}, {ServiceDescriptionString}";

                Logger.LogError(ex, errorMessage);

                var newEx = new Exception(errorMessage, ex);
                var operationFailedData = new OperationFailedData(publishId, newEx);
                m_publishFailedSubject.OnNext(operationFailedData);

                throw newEx;
            }
        }

        protected override void InternalInitialize()
        {
            // No internal logic
        }

        protected override void InternalStart()
        {
            // No internal logic
        }

        protected override void InternalStop()
        {
            // No internal logic
        }

        protected override void InnerNullifyReferencesDispose()
        {
            CorrelationIdGenerator = null;

            base.InnerNullifyReferencesDispose();
        }

        protected virtual void ThrowIfCanNotPublish(string operationId, TData data)
        {
            ValidateIsRunning($"CanPublish check failed - Service is not running. OperationId: {operationId}, MessageType: {typeof(TData).Name}, {ServiceDescriptionString}");

            if (string.IsNullOrWhiteSpace(operationId))
            {
                var error = $"CanPublish check failed - Operation ID is null. MessageType: {typeof(TData).Name}, {ServiceDescriptionString}";

                Logger.LogWarning(error);
                throw new ArgumentNullException(nameof(operationId), error);
            }

            if (data == null)
            {
                var error = $"CanPublish check failed - Data is null. OperationId: {operationId}, MessageType: {typeof(TData).Name}, {ServiceDescriptionString}";

                Logger.LogWarning(error);
                throw new ArgumentNullException(nameof(data), error);
            }
        }
    }
}