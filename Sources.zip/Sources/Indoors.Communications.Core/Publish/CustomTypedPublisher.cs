﻿using System;
using Indoors.Communications.Common.Correlation;
using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Types;
using Indoors.Serializations.Common;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Communications.Core.Publish
{
    public class CustomTypedPublisher<TData> : ServiceBase, ITypedObjectPublisher<TData>
    {
        public IObservable<OperationCompletedData> PublishCompleted => m_bufferPublisher.PublishCompleted;
        public IObservable<OperationFailedData> PublishFailed => m_bufferPublisher.PublishFailed;

        private IBufferPublisher<byte[]> m_bufferPublisher;

        private ICustomSerializer m_serializer;

        private ICorrelationIdGenerator m_correlationIdGenerator;

        public CustomTypedPublisher(IBufferPublisher<byte[]> bufferPublisher,
            ICustomSerializer serializer,
            ICorrelationIdGenerator correlationIdGenerator = null,
            ILogger<CustomTypedPublisher<TData>> logger = null,
            string id = null)
            : base(logger, id)
        {
            m_bufferPublisher = bufferPublisher ?? throw new ArgumentException(nameof(bufferPublisher));
            m_serializer = serializer ?? throw new ArgumentException(nameof(serializer));

            m_correlationIdGenerator = correlationIdGenerator;
        }


        public string Publish(in TData data)
        {
            var operationId = m_correlationIdGenerator?.Generate()
                              ?? Guid.NewGuid().ToString();

            Publish(operationId, data);

            return operationId;
        }

        public void Publish(string publishId, in TData data)
        {
            ThrowIfCanNotPublish(publishId, data);

            try
            {
                var localData = data;

                var serializedBuffer = m_serializer.Serialize(localData);

                var bufferData = new BufferData<byte[]>(serializedBuffer);

                m_bufferPublisher.Publish(bufferData);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to publish data! PublishId: {publishId}, DataType: {typeof(TData).Name}, Data: {data}, {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }
        }

        protected override void InternalInitialize()
        {
            m_bufferPublisher.Initialize();
        }

        protected override void InternalStart()
        {
            m_bufferPublisher.Start();
        }

        protected override void InternalStop()
        {
            m_bufferPublisher?.Stop();
        }

        protected override void InnerManagedDispose()
        {
            m_bufferPublisher?.TryDisposeService();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            m_bufferPublisher = null;
            m_serializer = null;
            m_correlationIdGenerator = null;

            base.InnerNullifyReferencesDispose();
        }

        /// <summary>
        /// Throws an exception if not all conditions exist for publishing a message using the given publisher.
        /// </summary>
        /// <param name="operationId">Publish operation ID.</param>
        /// <param name="data">Checked data.</param>
        /// <exception cref="ArgumentNullException">When <see cref="operationId"/> is null.</exception>
        /// <exception cref="ArgumentNullException">When <see cref="data"/> is null.</exception>
        /// <exception cref="Exception">When not connected.</exception>
        private void ThrowIfCanNotPublish(string operationId, TData data)
        {
            ValidateIsRunning($"CanPublish check failed - Service is not running. OperationId: {operationId}, DataType: {typeof(TData).Name}, Data: {data.ToString() ?? string.Empty}, {ServiceDescriptionString}");

            if (string.IsNullOrWhiteSpace(operationId))
            {
                var error = $"CanPublish check failed - Operation ID is null. DataType: {typeof(TData).Name}, {ServiceDescriptionString}";

                Logger.LogWarning(error);
                throw new ArgumentNullException(nameof(operationId), error);
            }

            if (data == null)
            {
                var error = $"CanPublish check failed - Message is null. OperationId: {operationId}, DataType: {typeof(TData).Name}, {ServiceDescriptionString}";

                Logger.LogWarning(error);
                throw new ArgumentNullException(nameof(data), error);
            }
        }
    }
}
