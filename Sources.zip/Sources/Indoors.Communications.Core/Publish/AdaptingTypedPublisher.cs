﻿using System;
using Indoors.Communications.Common.Correlation;
using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Types;
using Indoors.Communications.Core.Adapters;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Communications.Core.Publish
{
    public class AdaptingTypedPublisher<TData, TMessage> : ServiceBase, ITypedObjectPublisher<TData>
    {
        public IObservable<OperationCompletedData> PublishCompleted => Publisher.PublishCompleted;
        public IObservable<OperationFailedData> PublishFailed => Publisher.PublishFailed;

        public ITypedObjectPublisher<TMessage> Publisher { get; private set; }

        public IPublishDataMessageAdapter<TData, TMessage> Adapter { get; private set; }

        public ICorrelationIdGenerator CorrelationIdGenerator { get; private set; }

        public AdaptingTypedPublisher(ITypedObjectPublisher<TMessage> messagePublisher,
            IPublishDataMessageAdapter<TData, TMessage> adapter,
            ICorrelationIdGenerator correlationIdGenerator = null,
            ILogger<AdaptingTypedPublisher<TData, TMessage>> logger = null,
            string id = null)
            : base(logger, id)
        {
            Publisher = messagePublisher ?? throw new ArgumentException(nameof(messagePublisher));
            Adapter = adapter ?? throw new ArgumentException(nameof(adapter));

            CorrelationIdGenerator = correlationIdGenerator;
        }


        public string Publish(in TData data)
        {
            var operationId = CorrelationIdGenerator?.Generate()
                              ?? Guid.NewGuid().ToString();

            Publish(operationId, data);

            return operationId;
        }

        public void Publish(string publishId, in TData data)
        {
            ThrowIfCanNotPublish(publishId, data);

            try
            {
                var localData = data;

                var message = Adapter.ToMessage(publishId, localData);

                Publisher.Publish(publishId, message);
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed on try to publish data! PublishId: {publishId}, DataType: {typeof(TData).Name}, Data: {data}, {ServiceDescriptionString}";
                Logger.LogError(ex, errorMessage);
                throw new Exception(errorMessage, ex);
            }
        }

        protected override void InternalInitialize()
        {
            Publisher.Initialize();
        }

        protected override void InternalStart()
        {
            Publisher.Start();
        }

        protected override void InternalStop()
        {
            Publisher?.Stop();
        }

        protected override void InnerManagedDispose()
        {
            Publisher?.TryDisposeService();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Publisher = null;
            Adapter = null;
            CorrelationIdGenerator = null;

            base.InnerNullifyReferencesDispose();
        }

        /// <summary>
        /// Throws an exception if not all conditions exist for publishing a message using the given publisher.
        /// </summary>
        /// <param name="operationId">Publish operation ID.</param>
        /// <param name="data">Checked data.</param>
        /// <exception cref="ArgumentNullException">When <see cref="operationId"/> is null.</exception>
        /// <exception cref="ArgumentNullException">When <see cref="data"/> is null.</exception>
        /// <exception cref="Exception">When not connected.</exception>
        private void ThrowIfCanNotPublish(string operationId, TData data)
        {
            ValidateIsRunning($"CanPublish check failed - Service is not running. OperationId: {operationId}, DataType: {typeof(TData).Name}, Data: {data.ToString() ?? string.Empty}, {ServiceDescriptionString}");

            if (string.IsNullOrWhiteSpace(operationId))
            {
                var error = $"CanPublish check failed - Operation ID is null. DataType: {typeof(TData).Name}, {ServiceDescriptionString}";

                Logger.LogWarning(error);
                throw new ArgumentNullException(nameof(operationId), error);
            }

            if (data == null)
            {
                var error = $"CanPublish check failed - Message is null. OperationId: {operationId}, DataType: {typeof(TData).Name}, {ServiceDescriptionString}";

                Logger.LogWarning(error);
                throw new ArgumentNullException(nameof(data), error);
            }
        }
    }
}
