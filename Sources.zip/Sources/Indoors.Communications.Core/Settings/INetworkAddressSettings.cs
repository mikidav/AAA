﻿using System.Net;

namespace Indoors.Communications.Core.Settings
{
    public interface INetworkAddressSettings
    {
        IPEndPoint EndPoint { get; }

        IPAddress NetworkInterfaceAddress { get; }

        bool IsMulticast { get; }

        bool ReuseAddress { get; }
    }
}