﻿using System.Net;
using Indoors.Communications.Core.Helpers;

namespace Indoors.Communications.Core.Settings
{
    public class NetworkAddressSettings : INetworkAddressSettings
    {
        public IPEndPoint EndPoint { get; set; }
        public IPAddress NetworkInterfaceAddress { get; set; }

        public bool IsMulticast => NetworkConfigurationHelper.IsMulticastAddress(EndPoint.Address);
        public bool ReuseAddress { get; set; } = true;

        public override string ToString()
        {
            return $"{nameof(EndPoint)}: {EndPoint}, {nameof(NetworkInterfaceAddress)}: {NetworkInterfaceAddress}, {nameof(ReuseAddress)}: {ReuseAddress}";
        }
    }
}