namespace Indoors.Communications.Core.Settings
{
    public class UdpPublisherSettings : IUdpPublisherSettings
    {
        public INetworkAddressSettings AddressSettings { get; set; }
        public uint SendTimeout { get; set; } = 1000;
        public uint MulticastTimeToLive { get; set; } = 200;

        public override string ToString()
        {
            return $"{nameof(AddressSettings)}: [{AddressSettings}], {nameof(SendTimeout)}: {SendTimeout}, {nameof(MulticastTimeToLive)}: {MulticastTimeToLive}";
        }
    }
}