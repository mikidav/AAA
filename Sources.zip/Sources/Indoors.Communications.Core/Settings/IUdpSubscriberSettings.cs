namespace Indoors.Communications.Core.Settings
{
    public interface IUdpSubscriberSettings
    {
        INetworkAddressSettings AddressSettings { get; }

        uint HandlerErrorRecoveryTimeMilliseconds { get; }
        uint StoppingTimeoutMilliseconds { get; }
    }
}