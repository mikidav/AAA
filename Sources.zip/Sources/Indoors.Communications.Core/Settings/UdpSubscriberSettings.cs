namespace Indoors.Communications.Core.Settings
{
    public class UdpSubscriberSettings : IUdpSubscriberSettings
    {
        public INetworkAddressSettings AddressSettings { get; set; }
        public uint HandlerErrorRecoveryTimeMilliseconds { get; set; } = 10;
        public uint StoppingTimeoutMilliseconds { get; set; } = 2000;

        public override string ToString()
        {
            return $"{nameof(AddressSettings)}: [{AddressSettings}], {nameof(HandlerErrorRecoveryTimeMilliseconds)}: {HandlerErrorRecoveryTimeMilliseconds}, {nameof(StoppingTimeoutMilliseconds)}: {StoppingTimeoutMilliseconds}";
        }
    }
}