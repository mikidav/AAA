﻿using System.Net;
using Indoors.Communications.Core.Helpers;

namespace Indoors.Communications.Core.Settings
{
    public class NetworkAddressStringSettings : INetworkAddressSettings
    {
        private string m_endPointAddress;
        private int m_endPointPort;
        private string m_networkInterfaceAddressString;

        public string EndPointAddress
        {
            get => m_endPointAddress;
            set
            {
                m_endPointAddress = value;
                EndPoint = NetworkConfigurationHelper.GetIpEndPoint(m_endPointAddress, EndPointPort);
            }
        }

        public int EndPointPort
        {
            get => m_endPointPort;
            set
            {
                m_endPointPort = value;
                EndPoint = NetworkConfigurationHelper.GetIpEndPoint(EndPointAddress, m_endPointPort);
            }
        }

        public string NetworkInterfaceAddressString
        {
            get => m_networkInterfaceAddressString;
            set
            {
                m_networkInterfaceAddressString = value;
                NetworkInterfaceAddress = NetworkConfigurationHelper.GetIpAddress(m_networkInterfaceAddressString);
            }
        }

        public IPEndPoint EndPoint { get; private set; }
        public IPAddress NetworkInterfaceAddress { get; private set; }
        public bool IsMulticast => NetworkConfigurationHelper.IsMulticastAddress(EndPoint.Address);
        public bool ReuseAddress { get; set; } = true;

        public override string ToString()
        {
            return $"{nameof(EndPoint)}: {EndPoint}, {nameof(NetworkInterfaceAddress)}: {NetworkInterfaceAddress}, {nameof(IsMulticast)}: {IsMulticast}, {nameof(ReuseAddress)}: {ReuseAddress}";
        }

    }
}