namespace Indoors.Communications.Core.Settings
{
    public interface IUdpPublisherSettings
    {
        INetworkAddressSettings AddressSettings { get; }

        uint SendTimeout { get; }

        uint MulticastTimeToLive { get; }
    }
}