namespace Indoors.Communications.Core.Adapters
{
    public interface ISubscribeDataMessageAdapter<TData, in TMessage>
    {
        (string operationId, TData) ToData(TMessage message);
    }
}