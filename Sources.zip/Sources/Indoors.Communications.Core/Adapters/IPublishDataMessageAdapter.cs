namespace Indoors.Communications.Core.Adapters
{
    public interface IPublishDataMessageAdapter<in TData, out TMessage>
    {
        TMessage ToMessage(string operationId, TData data);
    }
}