﻿using System;
using System.Reactive.Linq;
using Indoors.Communications.Common.Subscribers;
using Indoors.Communications.Core.Adapters;
using Microsoft.Extensions.Logging;

namespace Indoors.Communications.Core.Subscribe
{
    public class AdaptingTypedSubscriber<TData, TMessage> : SubscriberBase<TData>, ITypedObjectSubscriber<TData>
    {
        private IDisposable m_subscriptionDisposable;

        public ITypedObjectSubscriber<TMessage> Subscriber { get; private set; }
        public ISubscribeDataMessageAdapter<TData, TMessage> Adapter { get; private set; }

        public IObservable<TData> DataReceived => DataSubscribedSubject;

        public AdaptingTypedSubscriber(ITypedObjectSubscriber<TMessage> messageSubscriber,
            ISubscribeDataMessageAdapter<TData, TMessage> adapter,
            ILogger<AdaptingTypedSubscriber<TData, TMessage>> logger = null,
            string id = null) : base(logger, id)
        {
            Subscriber = messageSubscriber ?? throw new ArgumentNullException(nameof(messageSubscriber));
            Adapter = adapter ?? throw new ArgumentNullException(nameof(adapter));
        }

        protected override void InternalInitialize()
        {
            Subscriber.Initialize();
        }

        protected override void InternalStart()
        {
            m_subscriptionDisposable = Subscriber.DataReceived.Where(_ => IsRunning).Subscribe(OnMessageReceived);

            Subscriber.Start();
        }

        protected override void InternalStop()
        {
            Subscriber.Stop();

            StopBufferSubscription();
        }

        private void StopBufferSubscription()
        {
            if (m_subscriptionDisposable == null)
            {
                Logger.LogInformation("Buffer subscription already stopped! Skipping operation...");
                return;
            }

            try
            {
                m_subscriptionDisposable.Dispose();
                m_subscriptionDisposable = null;

                Logger.LogInformation($"Successfully stopped subscription. {ServiceDescriptionString}");
            }
            catch (Exception ex)
            {
                var error = $"Failed to stop a subscription. {ServiceDescriptionString}";

                Logger.LogError(ex, error);
                throw new Exception(error, ex);
            }
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Adapter = null;
            Subscriber = null;

            base.InnerNullifyReferencesDispose();
        }

        private void OnMessageReceived(TMessage bufferData)
        {
            // ReSharper disable once NotAccessedVariable
            string operationId = null;

            TData data;
            try
            {
                // ReSharper disable once RedundantAssignment
                (operationId, data) = Adapter.ToData(bufferData);
            }
            catch (Exception ex)
            {
                Logger.LogWarning(ex, "Failed on try to handler received message!");
                return;
            }

            InvokeHandlersSync(data);

        }

    }
}