using System;
using System.Reactive.Subjects;
using System.Threading.Tasks;
using Indoors.Communications.Common.Subscribers;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Communications.Core.Subscribe
{
    /// <summary>
    /// A base class for subscribers.
    /// </summary>
    /// <typeparam name="TData">The subscribed data type.</typeparam>
    public abstract class SubscriberBase<TData> : ServiceBase, ISubscriber
    {
        protected ISubject<TData> DataSubscribedSubject { get; }

        protected SubscriberBase(ILogger logger = null, string id = null) : base(logger, id)
        {
            DataSubscribedSubject = new Subject<TData>();
        }

        /// <summary>
        /// Invokes data handlers synchronously and safely handles exceptions that may occur during handler execution.
        /// </summary>
        /// <param name="data">The received data.</param>
        protected void InvokeHandlersSync(TData data)
        {
            try
            {
                DataSubscribedSubject.OnNext(data);
            }
            catch (Exception ex)
            {
                HandleDataHandlerException(ex);
            }
        }
        /// <summary>
        /// Invokes data handlers asynchronously in a task and safely handles exceptions that may occur during handler async execution.
        /// All handlers are invoked on the same task one after another, and are async only to the data consuming task.
        /// </summary>
        /// <param name="data">The received data.</param>
        /// <returns>The <see cref="Task"/> that runs the handlers.</returns>
        protected Task InvokeHandlersAsync(TData data)
        {
            var task = Task.Run(() => DataSubscribedSubject.OnNext(data));

            task.ContinueWith(handlerTask => HandleDataHandlerException(handlerTask.Exception),
                TaskContinuationOptions.OnlyOnFaulted);

            return task;
        }

        /// <summary>
        /// Handles exceptions that are raised from handlers.
        /// </summary>
        /// <param name="ex">The exception raised from the handler.</param>
        private void HandleDataHandlerException(Exception ex)
        {
            var error = $"Error while handling received data! DataType:{typeof(TData).Name}, {ServiceDescriptionString}";
            Logger.LogDebug(ex, error);

            throw new Exception(error, ex);
        }
    }
}