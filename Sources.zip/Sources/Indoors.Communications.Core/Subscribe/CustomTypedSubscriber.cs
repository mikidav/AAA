﻿using System;
using System.Reactive.Linq;
using Indoors.Communications.Common.Subscribers;
using Indoors.Communications.Common.Types;
using Indoors.Serializations.Common;
using Microsoft.Extensions.Logging;

namespace Indoors.Communications.Core.Subscribe
{
    public class CustomTypedSubscriber<TData> : SubscriberBase<TData>, ITypedObjectSubscriber<TData>
    {
        private IDisposable m_subscriptionDisposable;

        public IBufferSubscriber<byte[]> BufferSubscriber { get; private set; }
        public ICustomDeserializer Deserializer { get; private set; }

        public IObservable<TData> DataReceived => DataSubscribedSubject;

        public CustomTypedSubscriber(IBufferSubscriber<byte[]> bufferSubscriber,
            ICustomDeserializer deserializer,
            ILogger<CustomTypedSubscriber<TData>> logger = null,
            string id = null) : base(logger, id)
        {
            BufferSubscriber = bufferSubscriber ?? throw new ArgumentNullException(nameof(bufferSubscriber));
            Deserializer = deserializer ?? throw new ArgumentNullException(nameof(deserializer));
        }

        protected override void InternalInitialize()
        {
            BufferSubscriber.Initialize();
        }

        protected override void InternalStart()
        {
            m_subscriptionDisposable = BufferSubscriber.BufferReceived.Where(_ => IsRunning).Subscribe(OnBufferDataReceived);

            BufferSubscriber.Start();
        }

        protected override void InternalStop()
        {
            BufferSubscriber.Stop();

            StopBufferSubscription();
        }

        private void StopBufferSubscription()
        {
            if (m_subscriptionDisposable == null)
            {
                Logger.LogInformation("Buffer subscription already stopped! Skipping operation...");
                return;
            }

            try
            {
                m_subscriptionDisposable.Dispose();
                m_subscriptionDisposable = null;

                Logger.LogInformation($"Successfully stopped subscription. {ServiceDescriptionString}");
            }
            catch (Exception ex)
            {
                var error = $"Failed to stop a subscription. {ServiceDescriptionString}";

                Logger.LogError(ex, error);
                throw new Exception(error, ex);
            }
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Deserializer = null;
            BufferSubscriber = null;

            base.InnerNullifyReferencesDispose();
        }

        private void OnBufferDataReceived(BufferData<byte[]> bufferData)
        {
            try
            {
                bufferData.ThrowIfIsNotValid();

                Deserializer.Deserialize(bufferData.Buffer, bufferData.DataStartIndex, bufferData.DataLength, out TData dataObject);

                InvokeHandlersSync(dataObject);
            }
            catch (Exception ex)
            {
                Logger.LogWarning(ex, "Failed on try to handler received buffer data!");
            }
        }

    }
}