﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;

namespace Indoors.Communications.Core.Helpers
{
    public static class NetworkConfigurationHelper
    {
        public const string LocalHostInterfaceName = "LOCALHOST";
        public const string MulticastLowAddressString = "224.0.0.0";
        public const string MulticastHighAddressString = "239.255.255.255";

        public static readonly IPAddress MulticastLowAddress = IPAddress.Parse(MulticastLowAddressString);
        public static readonly IPAddress MulticastHighAddress = IPAddress.Parse(MulticastHighAddressString);

        public static readonly uint MulticastLowAddressValue = GetIpAddressNumericValue(MulticastLowAddress);
        public static readonly uint MulticastHighAddressValue = GetIpAddressNumericValue(MulticastHighAddress);

        /// <summary>
        /// Gets the end point defined by the given address and port.
        /// </summary>
        public static IPEndPoint GetIpEndPoint(string addressString, int port)
        {
            var address = GetIpAddress(addressString);

            var endPoint = new IPEndPoint(address, port);

            return endPoint;
        }

        /// <summary>
        /// Gets an IP address from a string, considering reserved words ("localhost", ...).
        /// </summary>
        /// <param name="addressString"></param>
        public static IPAddress GetIpAddress(string addressString)
        {
            var address = addressString.ToUpper() == LocalHostInterfaceName
                ? IPAddress.Loopback
                : IPAddress.Parse(addressString);

            return address;
        }

        private static bool IsValidIpV4Address(IPAddressInformation address)
        {
            try
            {
                var isValidIpV4Address = address.Address.AddressFamily == AddressFamily.InterNetwork;
                return isValidIpV4Address;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Checks if an IP address represents a 'Multicast' address.
        /// </summary>
        /// <param name="address">The address to check</param>
        /// <returns>True if the address represents a 'Multicast' address, False otherwise.</returns>
        public static bool IsMulticastAddress(IPAddress address)
        {
            var isMulticast = address.IsIPv6Multicast;
            
            if (!isMulticast)
            {
                var addressValue = GetIpAddressNumericValue(address);
                isMulticast = addressValue >= MulticastLowAddressValue 
                              && addressValue < MulticastHighAddressValue;
            }

            return isMulticast;
        }

        private static uint GetIpAddressNumericValue(IPAddress address)
        {
            var addressBytes = address.GetAddressBytes();
            var reversedAddressBytes = addressBytes.Reverse().ToArray();

            var addressValue = BitConverter.ToUInt32(reversedAddressBytes, 0);
            return addressValue;
        }

        /// <summary>
        /// Gets the address of a network interface by its name.
        /// </summary>
        public static IPAddress GetNetworkInterfaceAddressFromInterfaceName(string interfaceName)
        {
            IPAddress address = null;

            var upperInterfaceName = interfaceName.ToUpper();

            try
            {
                var adapters = NetworkInterface.GetAllNetworkInterfaces();

                foreach (var adapter in adapters)
                {
                    Trace.WriteLine($"Inspecting {adapter.Name}");

                    if (!adapter.Supports(NetworkInterfaceComponent.IPv4))
                        continue;

                    foreach (var adapterAddress in adapter.GetIPProperties().UnicastAddresses)
                    {
                        var adapterName = adapter.Name.ToUpper();
                        var isValidIpV4Address = IsValidIpV4Address(adapterAddress);

                        if (adapterName == upperInterfaceName && isValidIpV4Address)
                        {
                            address = IPAddress.Parse(adapterAddress.Address.ToString());
                            break;
                        }
                    }

                    if (address != null)
                        break;
                }
            }
            catch (Exception ex)
            {
                var message = $"Network interface not found! Interface name: {interfaceName}";
                throw new Exception(message, ex);
            }

            return address;
        }
    }
}