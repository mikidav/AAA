﻿using Indoors.Services.Common;

namespace Indoors.EntityFramework.Service.IFC
{
    public interface IEntityServiceOperationHandler : IService
    {
    }
}
