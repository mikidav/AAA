﻿using System;
using Indoors.Services.Common;

namespace Indoors.EntityFramework.Service.IFC
{
    public interface IEntityServiceNotificationHandler : IService
    {
        Type GetEntityConcreteType();
    }
}
