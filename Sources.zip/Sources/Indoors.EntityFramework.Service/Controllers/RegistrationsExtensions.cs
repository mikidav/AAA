﻿using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace Indoors.EntityFramework.Service.Controllers
{
    public static class RegistrationsExtensions
    {
        public static IMvcBuilder AddRepositoryController(this IServiceCollection services)
        {
            return services.AddMvc()
                .AddApplicationPart(Assembly.GetExecutingAssembly())
                .AddControllersAsServices();
        }
    }
}
