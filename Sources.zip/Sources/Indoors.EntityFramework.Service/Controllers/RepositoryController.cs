﻿using Indoors.EntityFramework.Entities;
using Indoors.EntityFramework.Entities.Base;
using Indoors.EntityFramework.Entities.Enums;
using Indoors.EntityFramework.Entities.Types;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Indoors.EntityFramework.Common.Service;
using Indoors.Services.Common;

namespace Indoors.EntityFramework.Service.Controllers
{
    [ApiController]
    public class RepositoryController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IEntityRepositoryService _entityRepository;

        public RepositoryController(IEntityRepositoryService entityRepository,
            ILogger logger = null)
        {
            _logger = logger ?? DummyLogger.Instance;
            _entityRepository = entityRepository;
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Getting all Entities of the requested type", Description = "Types: Ooi, PlatformStatus")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success")]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Fail")]
        [Route("/GetEntities")]
        public async Task<ActionResult> GetEntities(string type)
        {
            try
            {
                IEnumerable<IEntity> entities;

                switch (type.ToLower())
                {
                    case "ooi":
                        entities = await _entityRepository.GetAsync<Ooi>();
                        break;
                    case "platformstatus":
                        entities = await _entityRepository.GetAsync<PlatformStatus>();
                        break;
                    default:
                        var message = $"RepositoryController: Unknown type: {type}";
                        _logger.LogError($"{message}");
                        return NotFound(message);
                }

                return Ok(entities);
            }
            catch (Exception ex)
            {
                _logger.LogError($"{ex.Message}");
                return NotFound(ex.Message);
            }
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Getting all the ooi of the requested typd", Description = "Types: (Case sensitive) - People, Weapons, Furniture, Platform")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success")]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Fail")]
        [Route("/GetAllOoisType")]
        public async Task<ActionResult> GetAllOoisType(string type)
        {
            try
            {
                var res = Enum.TryParse(type, out OoiTypeEnum ooiType);

                if (!res)
                {
                    var message = $"RepositoryController: Unknown Ooi type: {type}";
                    _logger.LogError($"{message}");
                    return NotFound(message);
                }

                var oois = await _entityRepository.GetAsync<Ooi>();
                var ooiTypes = oois.ToList().FindAll(e => e.Type == ooiType);

                return Ok(ooiTypes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"{ex.Message}");
                return NotFound(ex.Message);
            }
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Generate Ooi of requested type", Description = "Types: (Case sensitive) - People, Weaponsm Furniture, Platform")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success")]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Fail")]
        [Route("/GenerateOoi")]
        public async Task<ActionResult> GenerateOoi(string type)
        {
            try
            {
                var rand = new Random();

                var res = Enum.TryParse(type, out OoiTypeEnum ooiType);

                if (!res)
                {
                    var message = $"RepositoryController: Unknown Ooi type: {type}";
                    _logger.LogError(message);
                    return NotFound(message);
                }

                var location = new GeoPoint3D(rand.NextDouble(), rand.NextDouble());

                var id = Guid.NewGuid();

                var ooi = new Ooi(id)
                {
                    Type = ooiType,
                    Location = location
                };

                await _entityRepository.AddAsync(ooi);

                return Ok(ooi);
            }
            catch (Exception ex)
            {
                _logger.LogError($"{ex.Message}");
                return NotFound(ex.Message);
            }
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Generate Random Ooi")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success")]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Fail")]
        [Route("/GenerateRandomOoi")]
        public async Task<ActionResult> GenerateRandomOoi()
        {
            try
            {
                var rand = new Random();
                var values = Enum.GetValues(typeof(OoiTypeEnum)).OfType<OoiTypeEnum>().ToList();

                var ooiType = values[rand.Next(0, values.Count - 1)];
                var location = new GeoPoint3D(rand.NextDouble(), rand.NextDouble());

                var id = Guid.NewGuid();
                var ooi = new Ooi(id)
                {
                    Type = ooiType,
                    Location = location
                };

                await _entityRepository.AddAsync(ooi);

                return Ok(ooi);
            }
            catch (Exception ex)
            {
                _logger.LogError($"{ex.Message}");
                return NotFound(ex.Message);
            }
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Update Random Ooi")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success")]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Fail")]
        [Route("/UpdateOoi")]
        public async Task<ActionResult> UpdateOoi()
        {
            try
            {
                var ooi = (await _entityRepository.GetAsync<Ooi>()).ToList().FirstOrDefault();

                if (ooi == null)
                {
                    _logger.LogInformation($"There is no Ooi to update");
                    return NotFound();
                }


                var newOoi = ooi with { Version = Guid.NewGuid().ToString(), UpdatedBy = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name };

                await _entityRepository.UpdateAsync(newOoi);

                return Ok($"OldOoi: {ooi}, NewOoi: {newOoi}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"{ex.Message}");
                return NotFound(ex.Message);
            }
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Delete Random Ooi")]
        [SwaggerResponse(StatusCodes.Status200OK, "Success")]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Fail")]
        [Route("/DeleteOoi")]
        public async Task<ActionResult> DeleteOoi()
        {
            try
            {
                var ooi = (await _entityRepository.GetAsync<Ooi>()).ToList().FirstOrDefault();

                if (ooi == null)
                {
                    _logger.LogInformation($"There is no Ooi to update");
                    return NotFound();
                }

                await _entityRepository.DeleteAsync(ooi);

                return Ok($"Ooi: {ooi} has been deleted.");
            }
            catch (Exception ex)
            {
                _logger.LogError($"{ex.Message}");
                return NotFound(ex.Message);
            }
        }
    }
}
