﻿using Indoors.Services.Common;

namespace Indoors.EntityFramework.Service.Hosting
{
    public interface IEntityFrameworkServiceHost : IService
    {
    }
}
