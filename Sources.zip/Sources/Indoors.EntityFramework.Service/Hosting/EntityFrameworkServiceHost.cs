﻿using Indoors.EntityFramework.Logic.Service;
using Indoors.EntityFramework.Service.IFC;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;
using Indoors.EntityFramework.Common.Service;

namespace Indoors.EntityFramework.Service.Hosting
{
    public class EntityFrameworkServiceHost : ServiceBase, IEntityFrameworkServiceHost
    {
        private readonly IEntityRepositoryService _entityRepositoryService;
        private readonly List<IEntityServiceNotificationHandler> _notificationHandlers;
        private readonly List<IEntityServiceOperationHandler> _operationHandlers;

        public EntityFrameworkServiceHost(IEntityRepositoryService entityRepositoryService,
            IEnumerable<IEntityServiceNotificationHandler> notificationHandlers,
            IEnumerable<IEntityServiceOperationHandler> operationHandlers,
            ILogger<EntityFrameworkServiceHost> logger = null) 
            : base(logger, nameof(EntityFrameworkServiceHost))
        {
            _entityRepositoryService = entityRepositoryService;
            _notificationHandlers = notificationHandlers.ToList();
            _operationHandlers = operationHandlers.ToList();
        }

        protected override void InternalInitialize()
        {
            _notificationHandlers.ForEach(h => h.Initialize());
            _operationHandlers.ForEach(h => h.Initialize());

            _entityRepositoryService.Initialize();
        }

        protected override void InternalStart()
        {
            _notificationHandlers.ForEach(h =>
            {
                h.Start();
                _entityRepositoryService.AddTypeToRepository(h.GetEntityConcreteType());
            });

            _operationHandlers.ForEach(h => h.Start());

            _entityRepositoryService.Start();
        }

        protected override void InternalStop()
        {
            _entityRepositoryService.Stop();

            _notificationHandlers.ForEach(h => h.Stop());
            _operationHandlers.ForEach(h => h.Stop());
        }
    }
}
