﻿using System;
using Autofac;
using Autofac.Core;
using Google.Protobuf;
using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Subscribers;
using Indoors.Communications.RabbitMQ.Configuration;
using Indoors.Communications.RabbitMQ.Publish;
using Indoors.Communications.RabbitMQ.Subscribe;
using Indoors.DomainIcd.Entities;
using Indoors.DomainIcd.Entities.Adapters;
using Indoors.DomainIcd.Entities.Messages;
using Indoors.EntityFramework.Common.Service;
using Indoors.EntityFramework.Entities;
using Indoors.EntityFramework.Entities.Base;
using Indoors.EntityFramework.Logic.Service.InMemoryDictionary;
using Indoors.EntityFramework.Service.IFC;
using Indoors.EntityFramework.Service.NotificationHandlers;
using Indoors.EntityFramework.Service.OperationHandlers;
using Indoors.Serializations.Protobuf.DI.Autofac;
using Indoors.Services.Common;
using Indoors.Utilities;

namespace Indoors.EntityFramework.Service.Modules
{
    public class EntityFrameworkServiceModuleInstaller : Module
    {
        public EntityFrameworkServiceModuleInstaller()
        {

        }

        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            builder.RegisterFileDescriptorProvider<DomainEntitiesFileDescriptor>();

            RegisterLogic(builder);
            
            RegisterHandlers(builder);
        }

        private static void RegisterLogic(ContainerBuilder builder)
        {
            //Register repository
            builder.RegisterType<EntityRepositoryService>()
                .As<IEntityRepositoryService, IService>()
                .SingleInstance();
        }


        private static void RegisterHandlers(ContainerBuilder builder)
        {
            RegisterEntity<Ooi, OoiStruct, EntityMessageAdapterByReflection<Ooi, OoiStruct>>(builder);
            RegisterEntity<PlatformStatus, PlatformStatusStruct, EntityMessageAdapterByReflection<PlatformStatus, PlatformStatusStruct>>(builder);
            RegisterEntity<VideoStream, VideoStreamStruct, EntityMessageAdapterByReflection<VideoStream, VideoStreamStruct>>(builder);
        }
        
        private static void RegisterEntity<TEntity, TEntityMessage, TAdapter>(ContainerBuilder builder)
            where TEntity : class, IEntity
            where TEntityMessage : class, IMessage, new()
            where TAdapter : IEntityMessageAdapter<TEntity, TEntityMessage>
        {
            builder.RegisterType<TAdapter>()
                .AsSelf()
                .As<IEntityMessageAdapter<TEntity, TEntityMessage>>()
                .SingleInstance();

            var entityFullName = typeof(TEntity).FullName;

            var entityNotificationMessageSubscriber = RegisterRabbitMqSubscriber<TEntity, EntityNotificationMessage>(builder, entityFullName);

            var getAllEntitiesOfTypeRequestMessagePublisher = RegisterRabbitMqPublisher<TEntity, GetAllEntitiesOfTypeRespondMessage>(builder, entityFullName);
            var getAllEntitiesOfTypeRespondMessageSubscriber = RegisterRabbitMqSubscriber<TEntity, GetAllEntitiesOfTypeRequestMessage>(builder, entityFullName);

            //Register notification handler
            builder.RegisterType<GeneralEntityServiceNotificationHandler<TEntity, TEntityMessage>>()
                .AsSelf()
                .As<IEntityServiceNotificationHandler>()
                .WithParameter(ResolvedParameter.ForNamed<ITypedObjectSubscriber<EntityNotificationMessage>>(entityNotificationMessageSubscriber))
                .Named<IEntityServiceNotificationHandler>(typeof(GeneralEntityServiceNotificationHandler<TEntity, TEntityMessage>).Name)
                .SingleInstance();

            //Register operation handler 
            builder.RegisterType<GeneralEntityServiceOperationHandler<TEntity, TEntityMessage>>()
                .AsSelf()
                .As<IEntityServiceOperationHandler>()
                .WithParameter(ResolvedParameter.ForNamed<ITypedObjectPublisher<GetAllEntitiesOfTypeRespondMessage>>(getAllEntitiesOfTypeRequestMessagePublisher))
                .WithParameter(ResolvedParameter.ForNamed<ITypedObjectSubscriber<GetAllEntitiesOfTypeRequestMessage>>(getAllEntitiesOfTypeRespondMessageSubscriber))
                .Named<IEntityServiceOperationHandler>(typeof(GeneralEntityServiceOperationHandler<TEntity, TEntityMessage>).Name)
                .SingleInstance();

        }

        public static string RegisterRabbitMqPublisher<TEntity, TMessage>(ContainerBuilder builder, string publishTopic) where TMessage : class
        {
            if (string.IsNullOrWhiteSpace(publishTopic))
                throw new ArgumentNullException(nameof(publishTopic));

            var publisherName = $"{typeof(ITypedObjectPublisher<TMessage>).Name}:{typeof(TEntity).FullName}";
            builder.RegisterType<TypedPublisher<TMessage>>()
                .As<ITypedObjectPublisher<TMessage>>()
                .AsSelf()
                .Named<ITypedObjectPublisher<TMessage>>(publisherName)
                .WithParameter(ResolvedPublisherConfigurationParameter<TMessage>(publishTopic))
                .FindConstructorsWithParameterOfType(typeof(IPublisherConfiguration<TMessage>))
                .SingleInstance();
            return publisherName;
        }

        public static string RegisterRabbitMqSubscriber<TEntity, TMessage>(ContainerBuilder builder, string subscribeTopic) where TMessage : class
        {
            if (string.IsNullOrWhiteSpace(subscribeTopic))
                throw new ArgumentNullException(nameof(subscribeTopic));

            var subscriberName = $"{typeof(ITypedObjectSubscriber<TMessage>).Name}:{typeof(TEntity).FullName}";
            builder.RegisterType<TypedSubscriber<TMessage>>()
                .As<ITypedObjectSubscriber<TMessage>>()
                .AsSelf()
                .Named<ITypedObjectSubscriber<TMessage>>(subscriberName)
                .WithParameter(ResolvedSubscriberParameter<TMessage>(subscribeTopic))
                .FindConstructorsWithParameterOfType(typeof(ISubscriberConfiguration<TMessage>))
                .SingleInstance();
            return subscriberName;
        }

        public static ResolvedParameter ResolvedPublisherConfigurationParameter<TMessage>(string topic) 
            where TMessage : class
        {
            return new(
                (pi, _) => pi.ParameterType == typeof(IPublisherConfiguration<TMessage>),
                (_, ctx) =>
                {
                    var publisherConfiguration = ctx.ResolveOptional<IPublisherConfiguration<TMessage>>()
                                                 ?? ctx.Resolve<IPublisherConfiguration>();

                    var typedPublisherConfiguration = new PublisherConfiguration<TMessage>
                    {
                        AsAsync = publisherConfiguration.AsAsync,
                        WithPriority = publisherConfiguration.WithPriority,
                        WithExpiresMilliseconds = publisherConfiguration.WithExpiresMilliseconds,
                        WithTopic = string.IsNullOrWhiteSpace(publisherConfiguration.WithTopic)
                            ? topic
                            : publisherConfiguration.WithTopic
                    };

                    return typedPublisherConfiguration;
                });
        }

        public static ResolvedParameter ResolvedSubscriberParameter<TMessage>(string topic) 
            where TMessage : class
        {
            return new(
                (pi, _) => pi.ParameterType == typeof(ISubscriberConfiguration<TMessage>),
                (_, ctx) =>
                {
                    var subscriberConfiguration = ctx.ResolveOptional<ISubscriberConfiguration<TMessage>>()
                                                  ?? ctx.Resolve<ISubscriberConfiguration>();

                    var typedSubscriberConfiguration = new SubscriberConfiguration<TMessage>
                    {
                        AsAsync = subscriberConfiguration.AsAsync,
                        WithPriority = subscriberConfiguration.WithPriority,
                        WithExpiresMilliseconds = subscriberConfiguration.WithExpiresMilliseconds,
                        WithTopic = string.IsNullOrWhiteSpace(subscriberConfiguration.WithTopic)
                            ? topic
                            : subscriberConfiguration.WithTopic
                    };

                    return typedSubscriberConfiguration;
                });
        }
    }
}
