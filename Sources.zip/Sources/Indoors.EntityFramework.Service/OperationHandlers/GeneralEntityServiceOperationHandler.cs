﻿using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Subscribers;
using Indoors.EntityFramework.Entities.Base;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Threading.Tasks;
using Google.Protobuf;
using Google.Protobuf.WellKnownTypes;
using Indoors.DomainIcd.Entities.Adapters;
using Indoors.DomainIcd.Entities.Messages;
using Indoors.EntityFramework.Common.Data;
using Indoors.EntityFramework.Common.Extensions;
using Indoors.EntityFramework.Common.Service;
using Indoors.EntityFramework.Service.IFC;
using Indoors.Services.Common;
using Type = System.Type;

namespace Indoors.EntityFramework.Service.OperationHandlers
{
    public class GeneralEntityServiceOperationHandler<TEntity, TEntityMessage> : ServiceBase, IEntityServiceOperationHandler
        where TEntity : class, IEntity
        where TEntityMessage : class, IMessage, new()
    {
        private IDisposable _subscriptionsDisposable;

        public IEntityRepositoryService EntityRepositoryService { get; private set; }
        public ITypedObjectSubscriber<GetAllEntitiesOfTypeRequestMessage> Subscriber { get; private set; }
        public ITypedObjectPublisher<GetAllEntitiesOfTypeRespondMessage> Publisher { get; private set; }
        public IEntityMessageAdapter<TEntity, TEntityMessage> EntityMessageAdapter { get; private set; }


        public Type EntityType { get; }
        public Type EntityMessageType { get; }
        public string TypesDescriptionString => $"{nameof(EntityType)}: {EntityType}, {nameof(EntityMessageType)}: {EntityMessageType}";

        public GeneralEntityServiceOperationHandler(
            IEntityRepositoryService entityRepositoryService,
            ITypedObjectSubscriber<GetAllEntitiesOfTypeRequestMessage> subscriber,
            ITypedObjectPublisher<GetAllEntitiesOfTypeRespondMessage> publisher,
            IEntityMessageAdapter<TEntity, TEntityMessage> entityMessageAdapter,
            ILogger<GeneralEntityServiceOperationHandler<TEntity, TEntityMessage>> logger = null,
            string id = null)
            : base(logger, id)
        {
            EntityRepositoryService = entityRepositoryService;
            Subscriber = subscriber;
            Publisher = publisher;
            EntityMessageAdapter = entityMessageAdapter;

            EntityType = typeof(TEntity);
            EntityMessageType = typeof(TEntityMessage);
        }

        protected override void InternalInitialize()
        {
            Subscriber.Initialize();
            Publisher.Initialize();
        }

        protected override void InternalStart()
        {
            Publisher.Start();
            Subscriber.Start();

            CompositeDisposable compositeDisposable = new();

            compositeDisposable.Add(Subscriber.DataReceived
                .Where(_ => IsRunning)
                .SubscribeAsync(OnGetAllEntitiesOfTypeRequestMessageReceived));

            compositeDisposable.Add(EntityRepositoryService.AllEntitiesObservable
                .Where(data => data != null && data.EntityType == EntityType)
                .Where(_ => IsRunning).SubscribeAsync(OnGetAllEntitiesOfTypeRespondMessageReceived));

            _subscriptionsDisposable = compositeDisposable;
        }

        protected override void InternalStop()
        {
            _subscriptionsDisposable?.Dispose();
            _subscriptionsDisposable = null;

            Subscriber?.Stop();
            Publisher?.Stop();
        }

        protected override void Dispose(bool disposing)
        {
            Subscriber?.TryDisposeService();
            Publisher?.TryDisposeService();

            base.Dispose(disposing);
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Subscriber = null;
            Publisher = null;
            EntityRepositoryService = null;
            EntityMessageAdapter = null;

            base.InnerNullifyReferencesDispose();
        }

        private async Task OnGetAllEntitiesOfTypeRequestMessageReceived(GetAllEntitiesOfTypeRequestMessage message)
        {
            try
            {
                await EntityRepositoryService.FireAllAsync<TEntity>(Guid.Parse(message.CorrelationId));
            }
            catch (Exception ex)
            {
                Logger.LogError($"Invalid Correlation Id: {message.CorrelationId}, {ex.Message}. {TypesDescriptionString}, {ServiceDescriptionString}");
            }
        }

        private async Task OnGetAllEntitiesOfTypeRespondMessageReceived(OperationData data)
        {
            await Task.Run(() =>
            {
                var entitiesAnyPack = data.Entities.Cast<TEntity>()
                    .Select(EntityMessageAdapter.ToMessage)
                    .Select(Any.Pack)
                    .ToList();

                GetAllEntitiesOfTypeRespondMessage operationMessage = new()
                {
                    CorrelationId = data.CorrelationId.ToString(),
                    Entities = { entitiesAnyPack },
                    Type = EntityType.ToMessage()
                };

                operationMessage.Header = operationMessage.GetHeader();

                Publisher.Publish(operationMessage);
            });
        }
    }
}
