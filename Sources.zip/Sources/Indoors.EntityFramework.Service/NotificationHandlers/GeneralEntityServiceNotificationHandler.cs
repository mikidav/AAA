﻿using System;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Threading.Tasks;
using Google.Protobuf;
using Indoors.Communications.Common.Subscribers;
using Indoors.DomainIcd.Entities.Adapters;
using Indoors.DomainIcd.Entities.Messages;
using Indoors.EntityFramework.Common.Extensions;
using Indoors.EntityFramework.Common.Service;
using Indoors.EntityFramework.Entities.Base;
using Indoors.EntityFramework.Service.IFC;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;
using Type = System.Type;

namespace Indoors.EntityFramework.Service.NotificationHandlers
{
    public class GeneralEntityServiceNotificationHandler<TEntity, TEntityMessage> : ServiceBase, IEntityServiceNotificationHandler
        where TEntityMessage : class, IMessage, new()
        where TEntity : class, IEntity
    {
        private IDisposable _subscriptionsDisposable;

        public IEntityRepositoryService EntityRepositoryService { get; private set; }
        public ITypedObjectSubscriber<EntityNotificationMessage> Subscriber { get; private set; }
        public IEntityMessageAdapter<TEntity, TEntityMessage> EntityMessageAdapter { get; private set; }

        public Type EntityType { get; }
        public Type EntityMessageType { get; }
        public string TypesDescriptionString => $"{nameof(EntityType)}: {EntityType}, {nameof(EntityMessageType)}: {EntityMessageType}";

        public GeneralEntityServiceNotificationHandler(
            IEntityRepositoryService entityRepositoryService,
            ITypedObjectSubscriber<EntityNotificationMessage> subscriber,
            IEntityMessageAdapter<TEntity, TEntityMessage> entityMessageAdapter,
            ILogger<GeneralEntityServiceNotificationHandler<TEntity, TEntityMessage>> logger = null,
            string id = null) : base(logger, id)
        {
            EntityRepositoryService = entityRepositoryService;
            Subscriber = subscriber;
            EntityMessageAdapter = entityMessageAdapter;

            EntityType = typeof(TEntity);
            EntityMessageType = typeof(TEntityMessage);
        }

        protected override void InternalInitialize()
        {
            Subscriber.Initialize();
        }

        protected override void InternalStart()
        {
            Subscriber.Start();

            CompositeDisposable compositeDisposable = new();

            compositeDisposable.Add(Subscriber.DataReceived
                .Where(_ => IsRunning).SubscribeAsync(OnNotificationMessageReceived));

            _subscriptionsDisposable = compositeDisposable;
        }

        protected override void InternalStop()
        {
            _subscriptionsDisposable?.Dispose();
            _subscriptionsDisposable = null;

            Subscriber?.Stop();
        }

        protected override void Dispose(bool disposing)
        {
            Subscriber?.TryDisposeService();

            base.Dispose(disposing);
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Subscriber = null;
            EntityRepositoryService = null;
            EntityMessageAdapter = null;
            
            base.InnerNullifyReferencesDispose();
        }

        private async Task OnNotificationMessageReceived(EntityNotificationMessage message)
        {
            var notificationMessageSourceId = message?.SourceId;
            if (string.IsNullOrWhiteSpace(notificationMessageSourceId))
            {
                Logger.LogWarning($"Skipping notification message due to null or empty source ID! Message: {message}, {TypesDescriptionString}, {ServiceDescriptionString}");
                return;
            }

            //Ignore self notifications
            if (notificationMessageSourceId.Equals(Id))
                return;

            if (message.Entity == null)
            {
                Logger.LogWarning($"Skipping notification message due to null entity! Message: {message}, {TypesDescriptionString}, {ServiceDescriptionString}");
                return;
            }

            var unpacked = message.Entity.TryUnpack<TEntityMessage>(out var entityMessage);
            if (unpacked)
            {
                var notificationType = message.Type.ToEntityType();
                var entity = EntityMessageAdapter.ToEntity(entityMessage);
                
                if (entity == null)
                {
                    Logger.LogWarning(
                        $"Message adapter returned null entity! Message: {message}, {TypesDescriptionString}, {ServiceDescriptionString}");
                    return;
                }

                await EntityRepositoryService.HandleNotificationAsync(entity, notificationType);
            }
        }
        public Type GetEntityConcreteType()
        {
            return typeof(TEntity);
        }
    }
}