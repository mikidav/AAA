﻿using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Subscribers;
using Indoors.EntityFramework.Entities.Base;
using Indoors.EntityFramework.Proxy.IFC;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Threading.Tasks;
using Google.Protobuf;
using Indoors.DomainIcd.Entities.Adapters;
using Indoors.DomainIcd.Entities.Messages;
using Indoors.EntityFramework.Common.Data;
using Indoors.EntityFramework.Common.Extensions;
using Indoors.EntityFramework.Common.Proxy;
using Indoors.Services.Common;

namespace Indoors.EntityFramework.Proxy.OperationHandlers
{
    public class GeneralEntityProxyOperationHandler<TEntity, TEntityMessage> : ServiceBase, IEntityProxyOperationHandler
        where TEntity : class, IEntity
        where TEntityMessage : class, IMessage, new()
    {
        private IDisposable _subscriptionsDisposable;

        public IEntityRepositoryProxy EntityRepositoryProxy { get; private set; }
        public ITypedObjectSubscriber<GetAllEntitiesOfTypeRespondMessage> Subscriber { get; private set; }
        public ITypedObjectPublisher<GetAllEntitiesOfTypeRequestMessage> Publisher { get; private set; }
        public IEntityMessageAdapter<TEntity, TEntityMessage> EntityMessageAdapter { get; private set; }


        public Type EntityType { get; }
        public Type EntityMessageType { get; }
        public string TypesDescriptionString => $"{nameof(EntityType)}: {EntityType}, {nameof(EntityMessageType)}: {EntityMessageType}";

        public GeneralEntityProxyOperationHandler(
            IEntityRepositoryProxy entityRepositoryProxy,
            ITypedObjectSubscriber<GetAllEntitiesOfTypeRespondMessage> subscriber,
            ITypedObjectPublisher<GetAllEntitiesOfTypeRequestMessage> publisher,
            IEntityMessageAdapter<TEntity, TEntityMessage> entityMessageAdapter,
            ILogger<GeneralEntityProxyOperationHandler<TEntity, TEntityMessage>> logger = null,
            string id = null)
            : base(logger, id)
        {
            EntityRepositoryProxy = entityRepositoryProxy;
            Subscriber = subscriber;
            Publisher = publisher;
            EntityMessageAdapter = entityMessageAdapter;

            EntityType = typeof(TEntity);
            EntityMessageType = typeof(TEntityMessage);
        }

        protected override void InternalInitialize()
        {
            Subscriber.Initialize();
            Publisher.Initialize();
        }

        protected override void InternalStart()
        {
            Publisher.Start();
            Subscriber.Start();

            CompositeDisposable compositeDisposable = new();

            compositeDisposable.Add(EntityRepositoryProxy.LoadRequestObservable
                .Where(_ => IsRunning).SubscribeAsync(OnLoadRequestReceived));

            _subscriptionsDisposable = compositeDisposable;
        }

        protected override void InternalStop()
        {
            _subscriptionsDisposable?.Dispose();
            _subscriptionsDisposable = null;

            Subscriber?.Stop();
            Publisher?.Stop();
        }

        protected override void Dispose(bool disposing)
        {
            Subscriber?.TryDisposeService();
            Publisher?.TryDisposeService();

            base.Dispose(disposing);
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Subscriber = null;
            Publisher = null;
            EntityRepositoryProxy = null;
            EntityMessageAdapter = null;

            base.InnerNullifyReferencesDispose();
        }

        private async Task OnLoadRequestReceived(Guid correlationId)
        {
            var correlationIdString = correlationId.ToString();

            GetAllEntitiesOfTypeRequestMessage message = new()
            {
                CorrelationId = correlationIdString,
                Type = EntityType.ToMessage()
            };

            message.Header = message.GetHeader();

            var subscriptionDisposable = Subscriber.DataReceived
                .Where(respondMessage => correlationIdString == respondMessage?.CorrelationId)
                .Take(1)
                .Subscribe(respondMessage => OnGetAllEntitiesOfTypeRespondMessageReceived(correlationId, respondMessage));

            try
            {
                await Task.Run(() => Publisher.Publish(message));
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, $"Failed on try to publish message! Message: {message}, {TypesDescriptionString}, {ServiceDescriptionString}");
                subscriptionDisposable.Dispose();
            }
        }

        private void OnGetAllEntitiesOfTypeRespondMessageReceived(Guid correlationId, GetAllEntitiesOfTypeRespondMessage message)
        {
            if (message == null)
            {
                Logger.LogWarning($"Received null message!  MessageType: {nameof(GetAllEntitiesOfTypeRespondMessage)}, {TypesDescriptionString}, {ServiceDescriptionString}");
                return;
            }

            var type = message.Type?.ToType();
            if (type == null)
            {
                Logger.LogWarning($"Received message of unknown type! An attempt to unpack will be made...  Message: {message}, {TypesDescriptionString}, {ServiceDescriptionString}");
                return;
            }

            if (type != EntityType)
                return;

            var entities = new List<TEntity>();
            foreach (var entityAny in message.Entities)
            {
                var unpacked = entityAny.TryUnpack<TEntityMessage>(out var entityMessage);
                if (!unpacked)
                    return;

                var entity = EntityMessageAdapter.ToEntity(entityMessage);
                if (entity == null)
                {
                    Logger.LogWarning($"Message adapter returned null entity! Message: {message}, {TypesDescriptionString}, {ServiceDescriptionString}");
                    return;
                }

                entities.Add(entity);
            }

            OperationData operationData = new()
            {
                CorrelationId = correlationId,
                Entities = entities,
                EntityType = typeof(TEntity)
            };

            EntityRepositoryProxy.Load<TEntity>(operationData);
        }
    }
}
