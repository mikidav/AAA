﻿using System;
using Indoors.Services.Common;

namespace Indoors.EntityFramework.Proxy.IFC
{
    public interface IEntityProxyNotificationHandler : IService
    {
        Type GetEntityConcreteType();
    }
}
