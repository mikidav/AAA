﻿using Indoors.Services.Common;

namespace Indoors.EntityFramework.Proxy.IFC
{
    public interface IEntityProxyOperationHandler : IService
    {
    }
}
