﻿using System;
using Autofac;
using Autofac.Core;
using Indoors.DomainIcd.Entities.Messages;
using Indoors.EntityFramework.Entities;
using Indoors.EntityFramework.Entities.Base;
using Indoors.EntityFramework.Proxy.IFC;
using Indoors.EntityFramework.Proxy.NotificationHandlers;
using Indoors.EntityFramework.Proxy.OperationHandlers;
using Google.Protobuf;
using Indoors.Communications.Common.Publishers;
using Indoors.Communications.Common.Subscribers;
using Indoors.Communications.RabbitMQ.Configuration;
using Indoors.Communications.RabbitMQ.Publish;
using Indoors.Communications.RabbitMQ.Subscribe;
using Indoors.DomainIcd.Entities.Adapters;
using Indoors.Utilities;

namespace Indoors.EntityFramework.Proxy.Modules
{
    public static class EntityFrameworkRegistrationExtensions
    {
        public static bool RegisterEntityType<TEntity>(this ContainerBuilder builder)
            where TEntity : class, IEntity
        {

            switch (typeof(TEntity))
            {
                case { } t when t == typeof(Ooi):
                    RegisterEntity<Ooi, OoiStruct, EntityMessageAdapterByReflection<Ooi, OoiStruct>>(builder);
                    break;
                case { } t when t == typeof(PlatformStatus):
                    RegisterEntity<PlatformStatus, PlatformStatusStruct, EntityMessageAdapterByReflection<PlatformStatus, PlatformStatusStruct>>(builder);
                    break;
                case { } t when t == typeof(VideoStream):
                    RegisterEntity<VideoStream, VideoStreamStruct, EntityMessageAdapterByReflection<VideoStream, VideoStreamStruct>>(builder);
                    break;
                case { } t when t == typeof(Navigation):
                    RegisterEntity<Navigation, NavigationStruct, EntityMessageAdapterByReflection<Navigation, NavigationStruct>>(builder);
                    break;
                default:
                    return false;
            }

            return true;
        }

        private static void RegisterEntity<TEntity, TEntityMessage, TAdapter>(this ContainerBuilder builder)
            where TEntity : class, IEntity
            where TEntityMessage : class, IMessage, new()
            where TAdapter : IEntityMessageAdapter<TEntity, TEntityMessage>
        {
            builder.RegisterType<TAdapter>()
                .AsSelf()
                .As<IEntityMessageAdapter<TEntity, TEntityMessage>>()
                .SingleInstance();
            
            var entityFullName = typeof(TEntity).FullName;

            var entityNotificationMessagePublisher = RegisterRabbitMqPublisher<TEntity, EntityNotificationMessage>(builder, entityFullName);
            var entityNotificationMessageSubscriber = RegisterRabbitMqSubscriber<TEntity, EntityNotificationMessage>(builder, entityFullName);

            var getAllEntitiesOfTypeRequestMessagePublisher =  RegisterRabbitMqPublisher<TEntity, GetAllEntitiesOfTypeRequestMessage>(builder, entityFullName);
            var getAllEntitiesOfTypeRespondMessageSubscriber = RegisterRabbitMqSubscriber<TEntity, GetAllEntitiesOfTypeRespondMessage>(builder, entityFullName);
            
            //Register notification handler
            builder.RegisterType<GeneralEntityProxyNotificationHandler<TEntity, TEntityMessage>>()
                .AsSelf()
                .As<IEntityProxyNotificationHandler>()
                .WithParameter(ResolvedParameter.ForNamed<ITypedObjectPublisher<EntityNotificationMessage>>(entityNotificationMessagePublisher))
                .WithParameter(ResolvedParameter.ForNamed<ITypedObjectSubscriber<EntityNotificationMessage>>(entityNotificationMessageSubscriber))
                .Named<IEntityProxyNotificationHandler>(typeof(GeneralEntityProxyNotificationHandler<TEntity, TEntityMessage>).Name)
                .SingleInstance();

            //Register operation handler 
            builder.RegisterType<GeneralEntityProxyOperationHandler<TEntity, TEntityMessage>>()
                .AsSelf()
                .As<IEntityProxyOperationHandler>()
                .WithParameter(ResolvedParameter.ForNamed<ITypedObjectPublisher<GetAllEntitiesOfTypeRequestMessage>>(getAllEntitiesOfTypeRequestMessagePublisher))
                .WithParameter(ResolvedParameter.ForNamed<ITypedObjectSubscriber<GetAllEntitiesOfTypeRespondMessage>>(getAllEntitiesOfTypeRespondMessageSubscriber))
                .Named<IEntityProxyOperationHandler>(typeof(GeneralEntityProxyOperationHandler<TEntity, TEntityMessage>).Name)
                .SingleInstance();

        }

        public static string RegisterRabbitMqPublisher<TEntity, TMessage>(ContainerBuilder builder, string publishTopic) where TMessage : class
        {
            if (string.IsNullOrWhiteSpace(publishTopic))
                throw new ArgumentNullException(nameof(publishTopic));

            var publisherName = $"{typeof(ITypedObjectPublisher<TMessage>).Name}:{typeof(TEntity).FullName}";
            builder.RegisterType<TypedPublisher<TMessage>>()
                .As<ITypedObjectPublisher<TMessage>>()
                .AsSelf()
                .Named<ITypedObjectPublisher<TMessage>>(publisherName)
                .WithParameter(ResolvedPublisherConfigurationParameter<TMessage>(publishTopic))
                .FindConstructorsWithParameterOfType(typeof(IPublisherConfiguration<TMessage>))
                .SingleInstance();
            return publisherName;
        }

        public static string RegisterRabbitMqSubscriber<TEntity, TMessage>(ContainerBuilder builder, string subscribeTopic) where TMessage : class
        {
            if (string.IsNullOrWhiteSpace(subscribeTopic))
                throw new ArgumentNullException(nameof(subscribeTopic));

            var subscriberName = $"{typeof(ITypedObjectSubscriber<TMessage>).Name}:{typeof(TEntity).FullName}";
            builder.RegisterType<TypedSubscriber<TMessage>>()
                .As<ITypedObjectSubscriber<TMessage>>()
                .AsSelf()
                .Named<ITypedObjectSubscriber<TMessage>>(subscriberName)
                .WithParameter(ResolvedSubscriberParameter<TMessage>(subscribeTopic))
                .FindConstructorsWithParameterOfType(typeof(ISubscriberConfiguration<TMessage>))
                .SingleInstance();
            return subscriberName;
        }

        public static ResolvedParameter ResolvedPublisherConfigurationParameter<TPublisher>(string topic) where TPublisher : class
        {
            return new(
                (pi, _) => pi.ParameterType == typeof(IPublisherConfiguration<TPublisher>),
                (_, ctx) =>
                {
                    var publisherConfiguration = ctx.ResolveOptional<IPublisherConfiguration<TPublisher>>()
                                                 ?? ctx.Resolve<IPublisherConfiguration>();

                    var typedPublisherConfiguration = new PublisherConfiguration<TPublisher>
                    {
                        AsAsync = publisherConfiguration.AsAsync,
                        WithPriority = publisherConfiguration.WithPriority,
                        WithExpiresMilliseconds = publisherConfiguration.WithExpiresMilliseconds,
                        WithTopic = string.IsNullOrWhiteSpace(publisherConfiguration.WithTopic)
                            ? topic
                            : publisherConfiguration.WithTopic
                    };

                    return typedPublisherConfiguration;
                });
        }

        public static ResolvedParameter ResolvedSubscriberParameter<TSubscriber>(string topic) where TSubscriber : class
        {
            return new(
                (pi, _) => pi.ParameterType == typeof(ISubscriberConfiguration<TSubscriber>),
                (_, ctx) =>
                {
                    var subscriberConfiguration = ctx.ResolveOptional<ISubscriberConfiguration<TSubscriber>>()
                                                  ?? ctx.Resolve<ISubscriberConfiguration>();

                    var typedSubscriberConfiguration = new SubscriberConfiguration<TSubscriber>
                    {
                        AsAsync = subscriberConfiguration.AsAsync,
                        WithPriority = subscriberConfiguration.WithPriority,
                        WithExpiresMilliseconds = subscriberConfiguration.WithExpiresMilliseconds,
                        WithTopic = string.IsNullOrWhiteSpace(subscriberConfiguration.WithTopic)
                            ? topic
                            : subscriberConfiguration.WithTopic
                    };

                    return typedSubscriberConfiguration;
                });
        }
    }
}
