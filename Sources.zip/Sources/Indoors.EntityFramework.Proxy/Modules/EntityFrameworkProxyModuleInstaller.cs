﻿using Autofac;
using Indoors.DomainIcd.Entities;
using Indoors.EntityFramework.Common;
using Indoors.EntityFramework.Common.Proxy;
using Indoors.EntityFramework.Logic.Proxy;
using Indoors.EntityFramework.Proxy.Hosting;
using Indoors.Serializations.Protobuf.DI.Autofac;
using Indoors.Services.Common;
using Indoors.Services.Hosting;
using Microsoft.Extensions.Hosting;

namespace Indoors.EntityFramework.Proxy.Modules
{
    public class EntityFrameworkProxyModuleInstaller : Module
    {
        public EntityFrameworkProxyModuleInstaller()
        {

        }

        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            builder.RegisterFileDescriptorProvider<DomainEntitiesFileDescriptor>();

            RegisterLogic(builder);
            RegisterHost(builder);
        }

        private static void RegisterLogic(ContainerBuilder builder)
        {
            //Register repository
            builder.RegisterType<EntityRepositoryProxy>()
                .As<IEntityRepository>()
                .As<IEntityRepositoryProxy, INotificationEventAggregator, IEntityRepositoryAggregator>()
                .SingleInstance();
        }

        private static void RegisterHost(ContainerBuilder builder)
        {
            builder.RegisterType<EntityFrameworkProxyHost>()
                .As<IEntityFrameworkProxyHost, IService>()
                .SingleInstance();

            builder.RegisterType<ServicesHostedService<IEntityFrameworkProxyHost>>()
                .As<IHostedService>();
        }
    }
}
