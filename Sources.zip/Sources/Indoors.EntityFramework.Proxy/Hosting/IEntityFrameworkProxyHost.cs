﻿using Indoors.Services.Common;

namespace Indoors.EntityFramework.Proxy.Hosting
{
    public interface IEntityFrameworkProxyHost : IService
    {
    }
}
