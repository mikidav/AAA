﻿using Indoors.EntityFramework.Proxy.IFC;
using Indoors.Services.Common;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;
using Indoors.EntityFramework.Common.Proxy;

namespace Indoors.EntityFramework.Proxy.Hosting
{
    public class EntityFrameworkProxyHost : ServiceBase, IEntityFrameworkProxyHost
    {
        public IEntityRepositoryProxy EntityRepositoryProxy { get; private set; }
        public List<IEntityProxyNotificationHandler> NotificationHandlers { get; private set; }
        public List<IEntityProxyOperationHandler> OperationHandlers { get; private set; }

        public EntityFrameworkProxyHost(IEntityRepositoryProxy entityRepositoryProxy,
            IEnumerable<IEntityProxyNotificationHandler> notificationHandlers = null,
            IEnumerable<IEntityProxyOperationHandler> operationHandlers = null,
            ILogger<EntityFrameworkProxyHost> logger = null,
            string id = null) : base(logger, id)
        {
            EntityRepositoryProxy = entityRepositoryProxy;
            NotificationHandlers = notificationHandlers?.ToList() ?? Enumerable.Empty<IEntityProxyNotificationHandler>().ToList();
            OperationHandlers = operationHandlers?.ToList() ?? Enumerable.Empty<IEntityProxyOperationHandler>().ToList();
        }

        protected override void InternalInitialize()
        {
            NotificationHandlers.ForEach(h => h.Initialize());
            OperationHandlers.ForEach(h => h.Initialize());

            EntityRepositoryProxy.Initialize();
        }

        protected override void InternalStart()
        {
            NotificationHandlers.ForEach(handler =>
            {
                handler.Start();
                EntityRepositoryProxy.AddTypeToRepository(handler.GetEntityConcreteType());
            });

            OperationHandlers.StartServices();

            EntityRepositoryProxy.Start();
        }

        protected override void InternalStop()
        {
            EntityRepositoryProxy?.Stop();

            NotificationHandlers?.StopServices();
            OperationHandlers?.StopServices();
        }

        protected override void InnerManagedDispose()
        {
            EntityRepositoryProxy?.TryDisposeService();

            NotificationHandlers.DisposeServices();
            NotificationHandlers.ClearIfIsNotReadyOnly();

            OperationHandlers.DisposeServices();
            OperationHandlers.ClearIfIsNotReadyOnly();

            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            EntityRepositoryProxy = null;

            NotificationHandlers = null;
            OperationHandlers = null;

            base.InnerNullifyReferencesDispose();
        }
    }
}
