﻿using System.Collections.Generic;
using Google.Protobuf.Reflection;
using Indoors.Serializations.Protobuf;

namespace Indoors.DomainIcd.DeviceSensors
{
    public class DeviceSensorsDomainIcdDescriptorProvider : IFileDescriptorProvider
    {
        public IEnumerable<FileDescriptor> Descriptors => new[] { DeviceSensorsMessagesReflection.Descriptor };
    }
}