﻿using System;
using Indoors.EntityFramework.Entities.Base;
using Indoors.EntityFramework.Entities.Types;

namespace Indoors.EntityFramework.Entities
{
    public record Navigation : EntityBase
    {
        public Route Route { get; init; }

        public Frontier Frontier { get; init; }

        public Navigation(Guid id, string version = null, string createdBy = null, DateTime createdTimeUtc = default)
            : base(id, version, createdBy, createdTimeUtc)
        {
        }
    }
}