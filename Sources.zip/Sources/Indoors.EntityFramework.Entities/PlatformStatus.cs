﻿using System;
using Indoors.EntityFramework.Entities.Base;
using Indoors.EntityFramework.Entities.Enums;
using Indoors.EntityFramework.Entities.Types;

namespace Indoors.EntityFramework.Entities
{
    public record PlatformStatus : EntityBase
    {
        public GeoPoint3D Location { get; init; }

        public Orientation Orientation { get; init; }

        public PlatformStateEnum State { get; init; }

        public float BatteryCapacity { get; init; }

        public float NetworkSignalQuality { get; init; }

        public float SensorQuality { get; init; }

        public EntityId<Guid> VideoStreamEntityId { get; init; }
        
        public EntityId<Guid> NavigationEntityId { get; init; }

        public PlatformStatus(Guid id, string version = null, string createdBy = null, DateTime createdTimeUtc = default)
            : base(id, version, createdBy, createdTimeUtc)
        {
        }
    }
}
