﻿namespace Indoors.EntityFramework.Entities.Types
{
    public record RouteStep(GeoPoint3D Location, Orientation Orientation = null)
    {
    }
}