﻿using System;

namespace Indoors.EntityFramework.Entities.Types
{
    public record Orientation(double X = 0, double Y = 0, double Z = 0, double W = 0)
    {
        public bool IsDefault() => IsDefault(this);

        public Orientation Offset(double offsetX, double offsetY, double offsetZ, double offsetW)
        {

            return Offset(this, offsetX, offsetY, offsetZ, offsetW);
        }

        public static bool IsDefault(Orientation orientation)
        {
            if (orientation == null)
                throw new ArgumentNullException(nameof(orientation));

            return orientation.X == 0 && orientation.Y == 0 && orientation.Z == 0;
        }

        public static Orientation Offset(Orientation orientation, double offsetX, double offsetY, double offsetZ, double offsetW)
        {
            if (orientation == null)
                throw new ArgumentNullException(nameof(orientation));

            return orientation with { X = orientation.X + offsetX, Y = orientation.Y + offsetY, Z = orientation.Z + offsetZ, W = orientation.W + offsetW };
        }
    }
}