﻿using System.Collections.Generic;
using System.Linq;

namespace Indoors.EntityFramework.Entities.Types
{
    public record Frontier
    {
        public IReadOnlyList<GeoPoint3D> Points { get; init; }


        public Frontier(IEnumerable<GeoPoint3D> points)
        {
            Points = points?.ToList() ?? Enumerable.Empty<GeoPoint3D>().ToList();
        }
    }
}