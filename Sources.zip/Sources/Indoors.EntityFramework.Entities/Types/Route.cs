﻿using System.Collections.Generic;
using System.Linq;

namespace Indoors.EntityFramework.Entities.Types
{
    public record Route
    {
        public IReadOnlyList<RouteStep> Steps { get; init; }


        public Route(IEnumerable<RouteStep> steps)
        {
            Steps = steps?.ToList() ?? Enumerable.Empty<RouteStep>().ToList();
        }
    }
}