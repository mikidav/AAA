﻿using System;

namespace Indoors.EntityFramework.Entities.Types
{
    public record GeoPoint3D(double X = 0, double Y = 0, double Z = 0)
    {
        public bool IsDefault() => IsDefault(this);

        public GeoPoint3D Offset(double offsetX, double offsetY, double offsetZ)
        {

            return Offset(this, offsetX, offsetY, offsetZ);
        }

        public static bool IsDefault(GeoPoint3D geoPoint3D)
        {
            if (geoPoint3D == null)
                throw new ArgumentNullException(nameof(geoPoint3D));

            return geoPoint3D.X == 0 && geoPoint3D.Y == 0 && geoPoint3D.Z == 0;
        }
        
        public static GeoPoint3D Offset(GeoPoint3D geoPoint3D, double offsetX, double offsetY, double offsetZ)
        {
            if (geoPoint3D == null)
                throw new ArgumentNullException(nameof(geoPoint3D));

            return geoPoint3D with { X = geoPoint3D.X + offsetX, Y = geoPoint3D.Y + offsetY, Z = geoPoint3D.Z + offsetZ };
        }
    }
}
