﻿using System;

namespace Indoors.EntityFramework.Entities.Types
{
    public record Pixel(double X = 0, double Y = 0)
    {
        //public bool IsDefault() => IsDefault(this);

        public Pixel Offset(double offsetX, double offsetY)
        {
            return Offset(this, offsetX, offsetY);
        }

        //public static bool IsDefault(Pixel pixel)
        //{
        //    if (pixel == null)
        //        throw new ArgumentNullException(nameof(pixel));
           
        // // TODO: Add tolerance for double comparison.
        //    return pixel.X == 0 && pixel.Y == 0;
        //}

        public static Pixel Offset(Pixel pixel, double offsetX, double offsetY)
        {
            if (pixel == null)
                throw new ArgumentNullException(nameof(pixel));

            return pixel with { X = pixel.X + offsetX, Y = pixel.Y + offsetY };
        }
    }
}
