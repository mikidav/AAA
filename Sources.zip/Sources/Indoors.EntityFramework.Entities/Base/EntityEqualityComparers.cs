﻿using System.Collections.Generic;

namespace Indoors.EntityFramework.Entities.Base
{
    public static class EntityEqualityComparers
    {
        #region IdEqualityComparer

        private sealed class IdEqualityComparer : IEqualityComparer<IEntity>
        {
            public bool Equals(IEntity leftEntity, IEntity rightEntity)
            {
                if (ReferenceEquals(leftEntity, rightEntity)) return true;
                if (ReferenceEquals(leftEntity, null)) return false;
                if (ReferenceEquals(rightEntity, null)) return false;
                if (leftEntity.GetType() != rightEntity.GetType()) return false;
                return Equals(leftEntity.Id, rightEntity.Id);
            }

            public int GetHashCode(IEntity entity)
            {
                return (entity.Id != null ? entity.Id.GetHashCode() : 0);
            }
        }

        public static IEqualityComparer<IEntity> IdComparer { get; } = new IdEqualityComparer();

        #endregion

        #region IdAndVersionEqualityComparer

        private sealed class IdAndVersionEqualityComparer : IEqualityComparer<IEntity>
        {
            public bool Equals(IEntity leftEntity, IEntity rightEntity)
            {
                if (ReferenceEquals(leftEntity, rightEntity)) return true;
                if (ReferenceEquals(leftEntity, null)) return false;
                if (ReferenceEquals(rightEntity, null)) return false;
                if (leftEntity.GetType() != rightEntity.GetType()) return false;
                return Equals(leftEntity.Id, rightEntity.Id) && leftEntity.Version == rightEntity.Version;
            }

            public int GetHashCode(IEntity entity)
            {
                unchecked
                {
                    return ((entity.Id != null ? entity.Id.GetHashCode() : 0) * 397) ^ (entity.Version != null ? entity.Version.GetHashCode() : 0);
                }
            }
        }

        public static IEqualityComparer<IEntity> IdAndVersionComparer { get; } = new IdEqualityComparer();

        #endregion
    }
}