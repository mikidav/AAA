﻿namespace Indoors.EntityFramework.Entities.Base
{
    public record EntityId<TId>
    {
        public TId Value { get; init; }

        public static implicit operator TId(EntityId<TId> entityId) => entityId.Value;

        public static implicit operator EntityId<TId>(TId entityIdValue) => new() { Value = entityIdValue };

        public static bool operator ==(TId entityIdValue, EntityId<TId> entityId)
        {
            if (ReferenceEquals(entityId, null)) return false;
            if (ReferenceEquals(entityId.Value, entityIdValue)) return true;
            if (ReferenceEquals(entityId.Value, null)) return false;
            if (ReferenceEquals(entityIdValue, null)) return false;

            return entityId.Value.Equals(entityIdValue);
        }
        
        public static bool operator !=(TId entityIdValue, EntityId<TId> entityId)
        {
            return !(entityId == entityIdValue);
        }

        public static bool operator ==(EntityId<TId> entityId, TId entityIdValue)
        {
            if (ReferenceEquals(entityId, null)) return false;
            if (ReferenceEquals(entityId.Value, entityIdValue)) return true;
            if (ReferenceEquals(entityId.Value, null)) return false;
            if (ReferenceEquals(entityIdValue, null)) return false;

            return entityId.Value.Equals(entityIdValue);
        }

        public static bool operator !=(EntityId<TId> entityId, TId entityIdValue)
        {
            return !(entityId == entityIdValue);
        }

        public override string ToString()
        {
            return Value?.ToString() ?? "Null";
        }
    }
}