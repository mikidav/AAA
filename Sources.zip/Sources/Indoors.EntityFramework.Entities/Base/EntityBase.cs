﻿using System;

namespace Indoors.EntityFramework.Entities.Base
{
    public abstract record EntityBase : IEntity
    {
        public EntityId<Guid> Id { get; }

        public string Version { get; init; }

        public string CreatedBy { get; }

        public DateTime CreatedTimeUtc { get; }

        public DateTime CreatedTimeLocal => CreatedTimeUtc.ToLocalTime();

        public string UpdatedBy { get; init; }

        public DateTime UpdatedTimeUtc { get; init; }

        public DateTime UpdatedTimeLocal => UpdatedTimeUtc.ToLocalTime();

        protected EntityBase(Guid id, string version = null, string createdBy = null, DateTime createdTimeUtc = default)
        {
            Id = id;

            Version = version ?? Guid.NewGuid().ToString();

            CreatedBy = createdBy ?? System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
            UpdatedBy = CreatedBy;

            CreatedTimeUtc = createdTimeUtc == default ? DateTime.UtcNow : createdTimeUtc;
            if (CreatedTimeUtc.Kind != DateTimeKind.Utc)
                CreatedTimeUtc = CreatedTimeUtc.ToUniversalTime();

            UpdatedTimeUtc = CreatedTimeUtc;
        }

        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(Version)}: {Version}, {nameof(CreatedBy)}: {CreatedBy}, {nameof(CreatedTimeUtc)}: {CreatedTimeUtc:O}, {nameof(UpdatedBy)}: {UpdatedBy}, {nameof(UpdatedTimeUtc)}: {UpdatedTimeUtc:O}";
        }
    }
}
