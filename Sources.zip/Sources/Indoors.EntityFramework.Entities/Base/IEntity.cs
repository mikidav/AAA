﻿using System;

namespace Indoors.EntityFramework.Entities.Base
{
    public interface IEntity
    {
        EntityId<Guid> Id { get; }

        string Version { get; }

        string CreatedBy { get; }

        DateTime CreatedTimeUtc { get; }

        DateTime CreatedTimeLocal { get; }

        string UpdatedBy { get; }

        DateTime UpdatedTimeUtc { get; }

        DateTime UpdatedTimeLocal { get; }
    }
}
