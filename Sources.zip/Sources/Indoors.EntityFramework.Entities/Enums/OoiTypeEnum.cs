﻿namespace Indoors.EntityFramework.Entities.Enums
{
    public enum OoiTypeEnum
    {
        People,
        Weapons,
        Furniture,
        Platform
    }
}