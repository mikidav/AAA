﻿namespace Indoors.EntityFramework.Entities.Enums
{
    public enum PlatformStateEnum
    {
        /// <summary>
        /// Default state, not reported by the platform.
        /// </summary>
        Unknown,

        /// <summary>
        /// Default when value from platform can not be parsed.
        /// </summary>
        Unrecognized,

        /// <summary>
        /// The platform is landed and disarmed
        /// </summary>
        Disarmed,

        /// <summary>
        /// The platform is landed and armed
        /// </summary>
        InGround,

        /// <summary>
        /// The platform is taking off
        /// </summary>
        TakingOff,

        /// <summary>
        /// The platform is hovering while keeping the current position
        /// </summary>
        HoldingPosition,

        /// <summary>
        /// The platform is in autonomous exploring state
        /// </summary>
        Exploring,

        /// <summary>
        /// The platform is ready to receive commands from an operator (controlling position) 
        /// </summary>
        Manual,

        /// <summary>
        /// The platform is going to existing node (for example HOME) in topological map
        /// </summary>
        GoToNode,

        /// <summary>
        /// The platform is landing
        /// </summary>
        Landing,

        /// <summary>
        /// The platform is fault state – can't takeoff.
        /// Entering this state due time of operation will cause emergency landing 
        /// </summary>
        Fail,        
    }
}
