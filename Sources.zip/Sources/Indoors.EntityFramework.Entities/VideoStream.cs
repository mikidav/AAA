﻿using System;
using Indoors.EntityFramework.Entities.Base;

namespace Indoors.EntityFramework.Entities
{
    public record VideoStream : EntityBase
    {
        public string EncodingFormat { get; init; }
        
        public uint Width { get; init; }
        
        public uint Height { get; init; }
        
        public VideoStream(Guid id, string version = null, string createdBy = null, DateTime createdTimeUtc = default)
            : base(id, version, createdBy, createdTimeUtc)
        {
        }
    }
}
