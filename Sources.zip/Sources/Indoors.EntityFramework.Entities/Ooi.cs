﻿using Indoors.EntityFramework.Entities.Base;
using Indoors.EntityFramework.Entities.Enums;
using Indoors.EntityFramework.Entities.Types;
using System;

namespace Indoors.EntityFramework.Entities
{
    public record Ooi : EntityBase
    {
        public string Name { get; init; }

        public OoiTypeEnum Type { get; init; }

        public GeoPoint3D Location { get; init; }

        public Ooi(Guid id, string version = null, string createdBy = null, DateTime createdTimeUtc = default)
            : base(id, version, createdBy, createdTimeUtc)
        {
            Name = $"{nameof(Ooi)}-{id}";
        }
    }
}
