﻿using Indoors.Services.Common;

namespace Indoors.Platform.Gateway.Proxy
{
    public interface IPlatformCommandProxy : IService
    {

    }
}