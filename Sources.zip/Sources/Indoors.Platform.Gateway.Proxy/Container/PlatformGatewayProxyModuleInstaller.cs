﻿using Autofac;
using Indoors.Commands.Common;
using Indoors.Platform.Gateway.Common.Commands;
using Indoors.Communications.RabbitMQ.DI.Autofac;
using Indoors.DomainIcd.Platform;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.DomainIcd.Platform.Messages;
using Indoors.Platform.Gateway.Adapter.Commands;
using Indoors.Platform.Gateway.Common;
using Indoors.Serializations.Protobuf.DI.Autofac;
using Indoors.Services.Hosting;
using Microsoft.Extensions.Hosting;

namespace Indoors.Platform.Gateway.Proxy.Container
{
    public class PlatformGatewayProxyModuleInstaller : Module
    {
        public bool RegisterHostedService { get; }

        public PlatformGatewayProxyModuleInstaller(bool registerHostedService = true)
        {
            RegisterHostedService = registerHostedService;
        }

        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterFileDescriptorProvider<PlatformDomainIcdDescriptorProvider>();

            RegisterPlatformGeneralCommandProxy<PlatformSystemBootCommandParameters, PlatformSystemBootCommandMessage, PlatformDomainIcdSystemBootCommandAdapter>(builder);
            RegisterPlatformGeneralCommandProxy<PlatformRecoverCommandParameters, PlatformRecoverCommandMessage, PlatformDomainIcdRecoverCommandAdapter>(builder);
            RegisterPlatformGeneralCommandProxy<PlatformSetNavigationModeCommandParameters, PlatformSetNavigationModeCommandMessage, PlatformDomainIcdSetNavigationModeCommandAdapter>(builder);
            RegisterPlatformGeneralCommandProxy<PlatformLandCommandParameters, PlatformLandCommandMessage, PlatformDomainIcdLandCommandAdapter>(builder);
            RegisterPlatformGeneralCommandProxy<PlatformTakeOffCommandParameters, PlatformTakeoffCommandMessage, PlatformDomainIcdTakeOffCommandAdapter>(builder);
            RegisterPlatformGeneralCommandProxy<PlatformMoveCommandParameters, PlatformMoveCommandMessage, PlatformDomainIcdMoveCommandAdapter>(builder);
            RegisterPlatformGeneralCommandProxy<PlatformArmCommandParameters, PlatformArmCommandMessage, PlatformDomainIcdArmCommandAdapter>(builder);
            RegisterPlatformGeneralCommandProxy<PlatformDisarmCommandParameters, PlatformDisarmCommandMessage, PlatformDomainIcdDisarmCommandAdapter>(builder);
            RegisterPlatformGeneralCommandProxy<PlatformReturnHomeCommandParameters, PlatformReturnHomeCommandMessage, PlatformDomainIcdReturnHomeCommandAdapter>(builder);
            RegisterPlatformGeneralCommandProxy<PlatformSetOperationalModeCommandParameters, PlatformSetOperationalModeCommandMessage, PlatformDomainIcdSetOperationalModeCommandAdapter>(builder);
            RegisterPlatformGeneralCommandProxy<PlatformGoToCommandParameters, PlatformGoToCommandMessage, PlatformDomainIcdGoToCommandAdapter>(builder);
            RegisterPlatformGeneralCommandProxy<PlatformGoToMapPixelCommandParameters, PlatformGoToMapPixelCommandMessage, PlatformDomainIcdGoToMapPixelCommandAdapter>(builder);
            RegisterPlatformGeneralCommandProxy<PlatformGoToVideoPixelCommandParameters, PlatformGoToVideoPixelCommandMessage, PlatformDomainIcdGoToVideoPixelCommandAdapter>(builder);

            builder.RegisterType<PlatformFacade>()
                .AsSelf()
                .As<IPlatformFacade>()
                .SingleInstance();

            if (RegisterHostedService)
            {
                builder.RegisterType<ServicesHostedService<IPlatformCommandProxy>>()
                    .As<IHostedService>()
                    .WithParameter(new NamedParameter("id", "PlatformCommandProxyHost"))
                    .SingleInstance();
            }
        }

        private static void RegisterPlatformGeneralCommandProxy
            <TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter>(ContainerBuilder builder)
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IPlatformCommandParameter
        {
            RegisterPlatformCommandProxy
            <PlatformGeneralCommandProxy<TCommandParameter, TCommandDomainMessage>,
                TCommandParameter,
                TCommandDomainMessage,
                TDomainMessageAdapter>(builder);
        }

        private static void RegisterPlatformCommandProxy
            <TCommand, TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter>(ContainerBuilder container)
            where TCommand : class, IPlatformGeneralCommand<TCommandParameter>, IPlatformCommandProxy
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IPlatformCommandParameter
        {
            RegisterCommandProxy
            <IPlatformGeneralCommand<TCommandParameter>,
                TCommand,
                TCommandParameter,
                TCommandDomainMessage,
                TDomainMessageAdapter>(container);
        }

        private static void RegisterCommandProxy
        <TCommandInterface, TCommand, TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter>(ContainerBuilder builder)
            where TCommandInterface : ICommand<TCommandParameter>
            where TCommand : class, TCommandInterface, IPlatformCommandProxy
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IPlatformCommandParameter
        {
            builder.RegisterType<TCommand>()
                .AsSelf()
                .As<TCommandInterface, IPlatformCommandProxy>()
                .SingleInstance();

            builder.RegisterRabbitMqPublisher<TCommandDomainMessage>();

            builder.RegisterType<TDomainMessageAdapter>()
                .AsSelf()
                .As<IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage>>()
                .SingleInstance();
        }
    }
}