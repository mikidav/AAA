﻿using Indoors.Commands.Common;
using Indoors.Platform.Gateway.Common.Commands;
using Indoors.Services.Common;
using Indoors.Communications.Common.Publishers;
using Indoors.Platform.Gateway.Adapter.Commands;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Microsoft.Extensions.Logging;

namespace Indoors.Platform.Gateway.Proxy
{
    public class PlatformGeneralCommandProxy<TCommandParameter, TCommandDomainMessage> : CommandProxyBase<TCommandParameter>,
        IPlatformCommandProxy,
        IPlatformGeneralCommand<TCommandParameter> 
        where TCommandParameter : IPlatformCommandParameter 
        where TCommandDomainMessage : class
    {
        public ITypedObjectPublisher<TCommandDomainMessage> Publisher { get; private set; }
        public IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage> MessageAdapter { get; private set; }

        public PlatformGeneralCommandProxy(ITypedObjectPublisher<TCommandDomainMessage> publisher,
            IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage> messageAdapter,
            ICommandConfig<TCommandParameter> commandConfig,
            ILogger<PlatformGeneralCommandProxy<TCommandParameter, TCommandDomainMessage>> logger = null,
            string id = null)
            : base(commandConfig, logger, id)
        {
            Publisher = publisher;
            MessageAdapter = messageAdapter;
        }

        public PlatformGeneralCommandProxy(ITypedObjectPublisher<TCommandDomainMessage> publisher,
            IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage> messageAdapter,
            ICommandConfig commandConfig,
            ILogger<PlatformGeneralCommandProxy<TCommandParameter, TCommandDomainMessage>> logger = null,
            string id = null)
            : base(commandConfig, logger, id)
        {
            Publisher = publisher;
            MessageAdapter = messageAdapter;
        }

        public PlatformGeneralCommandProxy(ITypedObjectPublisher<TCommandDomainMessage> publisher,
            IPlatformDomainIcdCommandMessageAdapter<TCommandParameter, TCommandDomainMessage> messageAdapter,
            bool disableExecutionLog = true,
            ILogger<PlatformGeneralCommandProxy<TCommandParameter, TCommandDomainMessage>> logger = null,
            string id = null)
            : base(disableExecutionLog, logger, id)
        {
            Publisher = publisher;
            MessageAdapter = messageAdapter;
        }

        protected override void InternalInitialize()
        {
            Publisher.Initialize();
        }

        protected override void InternalStart()
        {
            Publisher.Start();
        }

        protected override void InternalStop()
        {
            Publisher?.Stop();
        }

        protected override void InternalExecute(string id, TCommandParameter parameter = default)
        {
            var message = MessageAdapter.ToMessage(id, parameter);
            Publisher.Publish(message);
        }

        protected override bool InternalCanExecute(TCommandParameter parameter = default)
        {
            var isProxyRunning = IsRunning;
            var isPublisherRunning = Publisher?.IsRunning == true;
            var canExecute = isProxyRunning && isPublisherRunning;

            return canExecute;
        }

        protected override void InnerManagedDispose()
        {
            Publisher?.TryDisposeService();
            base.InnerManagedDispose();
        }

        protected override void InnerNullifyReferencesDispose()
        {
            Publisher = null;
            MessageAdapter = null;
            base.InnerNullifyReferencesDispose();
        }
    }
}
