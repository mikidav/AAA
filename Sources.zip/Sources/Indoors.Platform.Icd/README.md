﻿# Platform ICD

## Topics Mapping

| Topic ID  | Topic Name                        | Protocol             |
|-----------|-----------------------------------|----------------------|
| 0         | UNDEFINED                         |                      |
| 1         | MAVROS_LOCAL_POSE_POSE            | Normal - Deprecated  |
| 2         | COMMAND                           | Critical             |
| 3         | WAYPOINT_IN_SET_DELTA             | Critical             |
| 4         | SM_WP_COMMAND                     | Critical             |
| 5         | MOVE_BASE_SIMPLE_GOAL             | Critical             |
| 6         | BIT_AGGREGATOR                    | Normal               |
| 7         | FA_IN_SET_POSITION_STATE          | Critical             |
| 8         | FA_OUT_SET_POSITION_STATE         | Normal               |
| 9         | MCU_STATE                         | Normal               |
| 10        | COMMUNICATION_MANAGER_MODE        | Normal               |
| 11        | MAVROS_ALTITUDE                   | Normal               |
| 12        | PATH_PLANNER_COVERAGE_PERCENTAGE  | Normal               |
| 13        | PATH_PLANNER_DIST_FROM_HOME       | Normal               |
| 14        | LOCALIZATION_MAP                  | Normal - Deprecated  |
| 15        | DEBUG_STRUCTURE_IMAGE             | Normal - Deprecated  |
| 16        | LOCALIZATION_MAP_DELTAS           | Normal - Deprecated  |
| 17        | DEBUG_VISIBLE_IMAGE_THEORA        | Normal - Deprecated  |
| 18        | FFK_CURRENT_SITE                  | Normal               |
| 19        | LOCALIZATION_MAP_ORIGIN           | ??? TBD              |
| 20        | LOCALIZATION_OUT_POSE             | Normal               |
| 21        | POINT_AND_GO_TRACKED_PIXEL        | ??? TBD              |
| 22        | MAP_QUARTER_0                     | Normal               |
| 23        | MAP_QUARTER_1                     | Normal               |
| 24        | MAP_QUARTER_2                     | Normal               |
| 25        | MAP_QUARTER_3                     | Normal               |
| 26        | PATH_PLANNER_WP_HANDLER_ROUTE     | Normal               |
| 27        | PUB_FRONTIERS                     | Normal               |
| 28        | IMAGE_FEED                        | Normal               |