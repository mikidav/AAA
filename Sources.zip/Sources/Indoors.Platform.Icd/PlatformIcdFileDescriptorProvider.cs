﻿using Indoors.Serializations.Protobuf;

namespace Indoors.Platform.Icd
{
    public class PlatformIcdFileDescriptorProvider : FileDescriptorProviderByAssembly
    {
        public PlatformIcdFileDescriptorProvider()
            : base(typeof(PlatformIcdFileDescriptorProvider).Assembly)
        {
        }
    }
}