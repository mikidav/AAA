﻿using Indoors.Services.Common;

namespace Indoors.EntityFramework.Tester.Hosting
{
    public interface IEntityFrameworkTesterHost : IService
    {
    }
}
