﻿using Indoors.EntityFramework.Tester.Logic;
using Indoors.Services.Common;

namespace Indoors.EntityFramework.Tester.Hosting
{
    public class EntityFrameworkTesterHost : ServiceBase, IEntityFrameworkTesterHost
    {
        private EntityRepositoryTester _entityRepositoryTester;

        public EntityFrameworkTesterHost(EntityRepositoryTester entityRepositoryTester)
        {
            _entityRepositoryTester = entityRepositoryTester;
        }

        protected override void InternalInitialize()
        {
            _entityRepositoryTester.Initialize();
        }

        protected override void InternalStart()
        {
            _entityRepositoryTester.Start();
        }

        protected override void InternalStop()
        {
            _entityRepositoryTester.Stop();
        }
    }
}
