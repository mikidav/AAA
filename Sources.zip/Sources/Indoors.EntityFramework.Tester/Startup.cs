using Autofac;
using Indoors.Communications.RabbitMQ.Connection;
using Indoors.EntityFramework.Entities;
using Indoors.EntityFramework.Proxy.Modules;
using Indoors.EntityFramework.Tester.Hosting;
using Indoors.EntityFramework.Tester.Logic;
using Indoors.Services.Common;
using Indoors.Services.Hosting;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Indoors.EntityFramework.Tester
{
    public class Startup
    {
        public IWebHostEnvironment WebHostEnvironment { get; }
        public IConfiguration Configurations { get; }

        public Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
        {
            Configurations = configuration;
            WebHostEnvironment = webHostEnvironment;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddOptions();

            services.AddControllers();
        }

        public void ConfigureContainer(ContainerBuilder builder)
        {
            //Register the EntityFramework proxy by module -- see appsettings.json
            var module = new Autofac.Configuration.ConfigurationModule(Configurations);
            builder.RegisterModule(module);

            //Register the types that the proxy consume
            builder.RegisterEntityType<Ooi>();
            builder.RegisterEntityType<PlatformStatus>();
            builder.RegisterEntityType<VideoStream>();

            builder.RegisterType<EntityRepositoryTester>()
                .SingleInstance();

            builder.RegisterType<EntityFrameworkTesterHost>()
                .As<IEntityFrameworkTesterHost, IService>();

            builder.RegisterType<ServicesHostedService<IEntityFrameworkTesterHost>>()
                .As<IHostedService>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IRabbitMqConnectionService rabbitMqConnection)
        {
            // If, for some reason, you need a reference to the built container, you
            // can use the convenience extension method GetAutofacRoot.
            // var autofacContainer = app.ApplicationServices.GetAutofacRoot();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            rabbitMqConnection.Initialize();
            rabbitMqConnection.Start();
        }
    }
}
