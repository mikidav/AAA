﻿using Autofac;

namespace Indoors.InstallerUtils
{
    public static class RegisterCommandAutofacExtensions
    {
        public static void RegisterCommand<TCommand, TCommandInterface>(this ContainerBuilder builder)
            where TCommandInterface : class
            where TCommand : class, TCommandInterface
        {
            builder.RegisterType<TCommand>()
                .AsSelf()
                .As<TCommandInterface>()
                .InstancePerDependency();
        }
    }
}