﻿using System;
using Autofac;
using Indoors.Commands.Common;
using Indoors.Commands.Messages.Common;
using Indoors.Communications.RabbitMQ.DI.Autofac;
using Indoors.Platform.Gateway.Common.CommandParameters;
using Indoors.Platform.Gateway.Common.Commands;

namespace Indoors.InstallerUtils
{
    public static class PlatformCommandProxyAutofacExtensions
    {
        public static void RegisterGeneralPlatformCommandProxy
            <TCommand, TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter>(this ContainerBuilder container)
            where TCommand : class, IPlatformGeneralCommand<TCommandParameter>
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
            where TCommandParameter : IPlatformCommandParameter
        {
            RegisterPlatformCommandProxy
            <IPlatformGeneralCommand<TCommandParameter>,
                TCommand,
                TCommandParameter,
                TCommandDomainMessage,
                TDomainMessageAdapter>(container);
        }

        public static void RegisterPlatformCommandProxy
            <TCommandInterface
                , TCommand
                , TCommandParameter
                , TCommandDomainMessage
                , TDomainMessageAdapter>(
                this ContainerBuilder builder)
            where TCommandInterface : class, ICommand<TCommandParameter>
            where TCommand : class, TCommandInterface
            where TCommandDomainMessage : class
            where TDomainMessageAdapter : ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
        {

            Console.WriteLine(typeof(TCommandInterface));
            Console.WriteLine(typeof(TCommand));
            Console.WriteLine(typeof(TCommandDomainMessage));
            Console.WriteLine(typeof(TDomainMessageAdapter));


            builder.RegisterCommand<TCommand, TCommandInterface>();
            builder.RegisterRabbitMqPublisher<TCommandDomainMessage>();
            builder.RegisterType<TDomainMessageAdapter>()
                .AsSelf()
                .As<ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage>>()
                .InstancePerDependency();

        }
    }
}


