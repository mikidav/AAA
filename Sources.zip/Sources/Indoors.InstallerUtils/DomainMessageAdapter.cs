﻿/*
using Autofac;
using Indoors.Commands.Messages.Common;

namespace Indoors.InstallerUtils
{
    public static class DomainMessageAdapterAutofacExtensions
    {
        public static void RegisterDomainMessageAdapter
            <TCommandParameter, TCommandDomainMessage, TDomainMessageAdapter>(this ContainerBuilder builder)

            where TCommandDomainMessage : class
            where TDomainMessageAdapter : ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage>
        {
            builder.RegisterType<TDomainMessageAdapter>()
                .AsSelf()
                .As<ICommandMessageAdapter<TCommandParameter, TCommandDomainMessage>>()
                .InstancePerDependency();
        }
    }
}
*/
