﻿using Indoors.Services.HealthChecks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Indoors.HealthChecks.Common.Helpers;

namespace Microsoft.Extensions.Hosting
{
    public static class RegistrationsExtensions
    {
        /// <summary>
        /// Register <see cref="ServicesHealthCheck"/> for checking the services state.
        /// </summary>
        /// <param name="healthChecksBuilder"></param>
        /// <returns></returns>
        public static IHealthChecksBuilder AddServicesHealthChecks(this IHealthChecksBuilder healthChecksBuilder)
        {
            return healthChecksBuilder.AddCheck<ServicesHealthCheck>(
                ServicesHealthCheck.Tag,
                HealthStatus.Unhealthy,
                new[] { ServicesHealthCheck.Tag });
        }

        /// <summary>
        /// Mapping services health check with it own route: <paramref name="healthParentRoute"/>/<see cref="ServicesHealthCheck.Route"/>
        /// 
        /// </summary>
        /// <param name="healthChecksBuilder"></param>
        /// <param name="healthParentRoute"></param>
        /// <returns></returns>
        public static IEndpointConventionBuilder MapServicesHealthChecks(this IEndpointRouteBuilder healthChecksBuilder, string healthParentRoute = "/health")
        {
            var servicesHealthCheckRoute = HealthChecksHelper.BuildRoute(healthParentRoute, ServicesHealthCheck.Route);

            // The readiness check uses all registered checks with the ReadinessTag.
            return healthChecksBuilder.MapHealthChecks(servicesHealthCheckRoute, new HealthCheckOptions
            {
                Predicate = check => check.Tags.Contains(ServicesHealthCheck.Tag),
                ResultStatusCodes = HealthChecksHelper.ResultStatusCodes,
                ResponseWriter = HealthChecksHelper.WriteResponse
            });
        }
    }
}
